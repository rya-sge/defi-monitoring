# Overview

> Source: https://docs.ethena.fi/backing-assets

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/overview.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Overview

Every unit of USDe is backed - subject to the discussion in the [Risks](https://docs.ethena.fi/protocol-overview/risks) section - by a portfolio of assets held by the protocol. While there is no guarantee, the objective is to preserve a stable dollar value of backing per USDe in most market conditions while generating sustainable revenue across a range of market conditions.

The protocol seeks to achieve this in one of two ways for any given asset. Volatile assets, such as spot crypto and tokenised commodities, are paired with a corresponding short derivatives position so that the combined position is delta-neutral and its dollar value remains relatively stable.

Assets that already hold a stable dollar value, such as liquid stablecoins and short-duration real-world assets, are held directly and do not require hedging.

For most of the protocol's history, backing has been concentrated in spot crypto assets hedged with short perpetual futures, alongside a buffer of liquid stablecoins. While this model has proven resilient through multiple market cycles, concentration in a single strategy means protocol revenue and risk are closely tied to one set of market dynamics.

Ethena is therefore diversifying the backing portfolio across several categories of asset and strategy, each selected to extend the existing delta-neutral and reward-bearing approach into markets with different drivers and lower correlation to crypto-native cycles.

The categories of backing assets are described in the pages that follow:

- **Non-Crypto Basis Trades** - extending the delta-neutral basis trade into commodities and other non-crypto markets.
- **DeFi Lending** - supplying backing assets into overcollateralised on-chain lending markets.
- **Institutional Lending** - overcollateralised lending to institutional counterparties.
- **Real World Assets** - tokenised real-world assets, including short-duration government debt and high-liquidity credit.
- **Liquid Stablecoins** - fiat-referenced stablecoins held to support redemptions and hedging efficiency.

New backing assets and strategies are introduced subject to governance and review by Ethena's Risk Committee, which sets exposure limits, eligibility criteria, and risk parameters for each category. The allocation across categories is dynamic and is published on the [Transparency dashboard](https://app.ethena.fi/dashboards/transparency).

Last updated 3 months ago

Was this helpful?