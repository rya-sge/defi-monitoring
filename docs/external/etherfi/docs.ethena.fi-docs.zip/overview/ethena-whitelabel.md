# Ethena Whitelabel

> Source: https://docs.ethena.fi/overview/ethena-whitelabel

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/ethena-whitelabel.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# Ethena Whitelabel

Ethena Whitelabel is a stablecoin-as-a-service offering that lets partners launch and operate their own branded stablecoins on top of Ethena's infrastructure. The partner designs the product, controls distribution, and captures the economics within their own ecosystem. Ethena provides the issuance, backing operations, custody, reserve management, and integrations.

The opportunity for partners is significant. Stablecoins have become one of the clearest examples of product–market fit in crypto, and every major ecosystem - exchanges, chains, applications, and institutions - increasingly has reason to capture the value flowing through its own dollar-denominated economy. Ethena Whitelabel allows a partner to do this in weeks rather than years, without building issuance infrastructure, onboarding custodians, negotiating exchange integrations, or assembling a reserve management operation from scratch.

### What partners receive:[](#what-partners-receive)

#### Access to the Ethena Ecosystem [](#access-to-the-ethena-ecosystem)

From day one, a partner stablecoin sits inside one of the largest dollar networks in CeFi and DeFi, with established distribution into leading exchanges, custodians, and on-chain venues. Partners inherit Ethena's existing relationships rather than negotiating each integration individually.

#### Issuance from a trusted operator[](#issuance-from-a-trusted-operator)

Partners launch with the team behind one of the largest dollar assets in crypto and a multi-billion-dollar issuance track record. The same operational discipline that has supported Ethena's own issuance is applied to partner stablecoins.

#### Dynamic backing asset allocation[](#dynamic-backing-asset-allocation)

Partner stablecoins can be backed by USDe or USDtb - a stablecoin issued by Anchorage Digital Bank in a GENIUS-compliant manner and backed by fiat USD and BlackRock's BUIDL - and other approved stablecoins. The mix can be tailored to the partner's risk preferences, target reward profile, and regulatory requirements, and the allocation can be adjusted dynamically as conditions evolve.

#### Tailored deployment[](#tailored-deployment)

Partners can launch quickly from a templated offering, or customise the product to fit specific ecosystem mechanics and use cases - for example, embedding the stablecoin into transaction-fee subsidies, margin systems, or treasury operations within their network.

#### Unified liquidity[](#unified-liquidity)

Partner stablecoins benefit from deep secondary liquidity through USDe, allowing onboarded users to enter and exit the partner asset against one of the most liquid dollar-denominated assets on chain.

#### Client dashboard[](#client-dashboard)

Partners retain real-time visibility and control over their stablecoin through a dedicated client dashboard, covering supply, backing composition, reserve activity, and operational status.

### Live deployments[](#live-deployments)

Several partner stablecoins are already in production on Ethena Whitelabel:

- jupUSD - a Solana-native stablecoin launched with Jupiter, backed by USDtb and USDC at launch and integrated across the Jupiter ecosystem.
- USDm - launched by MegaETH, backed by USDtb and USDC at launch, and designed to subsidise sequencer fees and stabilise transaction costs across the MegaETH network.
- suiUSDe - launched on Sui, backed by USDe and USDC, created to power Sui's DeFi ecosystem.

### Security and transparency[](#security-and-transparency)

Whitelabel deployments use the same audited contracts and operational infrastructure as Ethena's own products. The protocol's smart contracts have been audited by Zellic, Quantstamp, Spearbit, and Cantina, and have been the subject of public audit through Code4rena. Backing assets are held under the same institutional custody and reserve verification arrangements described in the [Off-Exchange Custody](https://docs.ethena.fi/overview/off-exchange-custody) section.

Partners interested in launching a stablecoin on Ethena Whitelabel can request a demo at [whitelabel.ethena.fi](https://whitelabel.ethena.fi).

Last updated 2 months ago

Was this helpful?