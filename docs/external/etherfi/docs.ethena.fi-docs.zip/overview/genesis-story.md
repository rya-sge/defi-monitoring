# Genesis Story

> Source: https://docs.ethena.fi/overview/genesis-story

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/genesis-story.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# Genesis Story

In March 2023 Arthur Hayes published his piece ["Dust on Crust"](https://blog.bitmex.com/dust-on-crust/) which outlined his vision for the largest opportunity in crypto - creating a synthetic dollar using crypto collateral and derivatives.

The most important financial instrument on Earth to save and preserve wealth is simply a reward-bearing dollar. It sounds simple, but the demand for this product is several orders of magnitude larger than the entire crypto market combined, including Bitcoin.

Ethena was built to provide this product and in doing so, force the convergence of capital and interest rates across DeFi, CeFi and TradFi via USDe.

Last updated 1 year ago

Was this helpful?