# How USDe Works

> Source: https://docs.ethena.fi/overview/how-usde-works

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/how-usde-works.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# How USDe Works

A crypto-native synthetic dollar utilizing spot assets as backing, onchain custody, and centralized liquidity venues

### How USDe Maintains Its Intended Peg[](#how-usde-maintains-its-intended-peg)

USDe derives its relative peg stability from holding a diversified portfolio of backing assets and hedging the price-change risk of any volatile holdings. Volatile assets, such as spot crypto, tokenized equities, and tokenised commodities, are paired with corresponding short futures positions in approximately the same notional size, so that movements in the value of the spot asset are generally offset by movements in the value of the hedge.

Stable assets held within the portfolio - liquid stablecoins and short-duration real-world assets - already hold a stable dollar value and require no hedge. The combined position is a delta-neutral backing whose synthetic dollar value remains relatively stable across most market conditions.

This delta-neutral construction is what allows USDe to be backed by productive assets while maintaining a relatively stable value with reference to the dollar.

### sUSDe[](#susde)

sUSDe is the staked form of USDe and the protocol's dollar savings asset. By staking USDe, holders are eligible to receive incentive reward distributions. As rewards accrue to the staking contract, the USDe value of sUSDe increases over time, with no further action required by the holder. sUSDe accrues only positive or flat rewards - periods of negative protocol revenue are absorbed by the Reserve Fund, during which period no incentive rewards would typically be paid.

### **Minting Example**[](#minting-example)

1. A whitelisted user provides ~$100 of *USDT *and receives ~100 newly-minted *USDe *atomically in return less the gas & execution costs to execute the hedge.
2. Slippage & execution fees are included in the price when **minting** & **redeeming**. Ethena earns no profit from the **minting **or **redeeming of ***USDe*.
3. The protocol opens a corresponding short perpetual position for the approximate same notional dollar value on a derivatives exchange.
4. The backing assets are transferred directly to an "Off Exchange Settlement" solution. Backing assets remain onchain and custodied by off exchange service providers to minimize counterparty risk.
5. Ethena delegates, but never transfers custody of, backing assets to derivatives exchanges to margin the short perpetual hedging positions.

Last updated 2 months ago

Was this helpful?