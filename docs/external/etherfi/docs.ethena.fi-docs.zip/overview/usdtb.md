# USDtb

> Source: https://docs.ethena.fi/overview/usdtb

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/usdtb.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# USDtb

USDtb is a digital dollar, otherwise known as a USD stablecoin. USDtb can be used the same way a holder would use any other dollar, whether to send and receive payments, acquire and trade assets, or to simply hold dollars.

Unlike actual dollars, USDtb is a blockchain-based token, which enables faster and cheaper spending than the traditional fiat banking system. As of October 2025, USDtb is issued by Anchorage Digital Bank.

For more detailed information about USDtb, please visit the [USDtb docs](https://docs.usdtb.money/).

Last updated 3 months ago

Was this helpful?