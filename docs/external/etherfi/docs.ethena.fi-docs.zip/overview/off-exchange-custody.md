# Off Exchange Custody

> Source: https://docs.ethena.fi/overview/off-exchange-custody

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/off-exchange-custody.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# Off Exchange Custody

The single largest historical risk to a synthetic-dollar protocol is the custody of its backing assets. The collapse of FTX in 2022 demonstrated, at scale, that holding assets on a centralised derivatives exchange exposes those assets to the operational, solvency, and legal risk of the exchange itself.

A protocol that places backing directly on exchange wallets - even with the best counterparties - accepts that any exchange-level failure could lock or impair those assets and, with them, the backing of the protocol's liabilities.

Ethena's hedging operations depend on access to centralised derivatives venues, which provide the deepest and most liquid markets for the perpetual and deliverable futures used to hedge USDe backing. The protocol's custody architecture is designed to allow this access without taking on the exchange-level custody risk that has historically accompanied it.

### Off-Exchange Settlement[](#off-exchange-settlement)

Ethena holds its backing assets with a small set of regulated, institutional-grade custody providers - Copper, Ceffu, Kraken and Anchorage Digital - through arrangements collectively referred to as **Off-Exchange Settlement (OES)**.

The defining mechanic of OES is the separation of custody from margining. Backing assets remain in custody with the OES provider at all times. To support a hedging position at a centralised exchange, the OES provider delegates - but does not transfer - a notional value of those assets to the exchange as margin collateral.

The exchange recognises the delegated value for margining purposes but cannot withdraw the underlying assets. Settlement of profit and loss between exchange and custodian occurs on frequent cycles - and any payments owed by the exchange to the protocol are settled into custody at each cycle.

This architecture produces a set of properties that materially change the protocol's exposure to centralised exchanges.

### Benefits when accessing centralised exchanges[](#benefits-when-accessing-centralised-exchanges)

#### **Bankruptcy remoteness from the exchange**[](#bankruptcy-remoteness-from-the-exchange)

Backing assets are never held on, or owned by, the exchange. In the event of an exchange failure, the protocol's backing is not part of the exchange's estate, is not subject to its bankruptcy proceedings, and is not expected to be locked alongside other user funds. The protocol retains control of the underlying assets and is positioned to continue supporting mint and redeem activity for USDe.

#### Exchange-posted collateral at the custodian[](#exchange-posted-collateral-at-the-custodian)

Under OES arrangements, the exchange is required to post collateral with the custodian to support each settlement cycle. This collateral, together with the delegation structure, is designed so that PnL owed to the protocol can be settled into custody without depending on a unilateral payment from the exchange. The protocol's claim does not rest on the exchange's willingness or operational ability to send funds.

#### Short and bounded exposure windows[](#short-and-bounded-exposure-windows)

PnL settlement on frequent - generally daily - cycles bounds the value at risk to the exchange to the amount accumulated since the last settlement. Long, open-ended credit exposure to exchanges is replaced with a series of short, settled positions.

#### Separation of incentives[](#separation-of-incentives)

Custody and execution are performed by separate institutions with separate ownership, regulation, and commercial incentives. An exchange cannot redirect, restrict, or rehypothecate backing assets, because it does not hold them. A custodian is not permitted to use protocol assets for any purpose other than the agreed custodial function. The protocol benefits from each party's specialisation in its own role.

#### Protocol-controlled deposits and withdrawals[](#protocol-controlled-deposits-and-withdrawals)

Ethena, not the exchange, controls the instructions to deposit assets into and withdraw assets from the OES arrangement. The protocol's internal system can scale hedging exposure up or down, move assets between custodians and exchanges, or recall assets to the minting contract to support redemption activity.

#### Custodian redundancy[](#custodian-redundancy)

The protocol uses multiple OES providers in parallel rather than concentrating on a single custodian. Redundancy across custodians limits the impact of any single-provider operational issue and supports the protocol's ability to continue operating across stress events

#### On-chain verifiability and attestations[](#on-chain-verifiability-and-attestations)

Where supported by the custodian, OES wallets can be exposed on-chain so that the existence and control of backing assets can be independently verified. Where assets are held in omnibus arrangements that preclude direct on-chain visibility, the custodial partners publish periodic attestations - at minimum monthly - confirming the value of backing held within their solutions. Together these enable users to verify, on an ongoing basis, that the backing of USDe exists and is under the protocol's control.

### How OES supports a diversified backing portfolio[](#how-oes-supports-a-diversified-backing-portfolio)

The same custody architecture supports the protocol's broader backing strategy as it diversifies across crypto basis trades, non-crypto basis trades, on-chain and institutional lending, and real-world assets.

For any strategy involving delegation of assets to a third-party venue - whether a centralised crypto exchange, or an institutional lending counterparty - the same principles apply: assets remain in segregated custody, delegation is structured to preserve the protocol's claim, and exposure to any single venue is bounded by settlement cycles and posted collateral.

OES is the foundation that allows the protocol to operate hedging and strategies at scale across the deepest available venues while keeping the backing of USDe outside the operational and solvency perimeter of any single counterparty.

Current custodial attestations and addresses for in-scope backing assets are published in the [Custodian Attestations](https://docs.ethena.fi/resources/custodian-attestations) section.

Last updated 3 months ago

Was this helpful?