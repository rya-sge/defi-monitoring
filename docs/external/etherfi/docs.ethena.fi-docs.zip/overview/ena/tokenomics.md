# Tokenomics

> Source: https://docs.ethena.fi/overview/ena/tokenomics

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/ena/tokenomics.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)
2. [ENA](https://docs.ethena.fi/overview/ena)

# Tokenomics

## Vesting Schedule[](#vesting-schedule)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FN8d8VhlzO1hen2JaW43p%252Fimage.png%3Falt%3Dmedia%26token%3D3ee63e3a-62b6-44ea-84fc-4b069f27af8c&width=768&dpr=3&quality=100&sign=e0324b561f8c7a175de4c8edb75a9c7f&sv=3)
## Allocation[](#allocation)

***Core Contributors***

This portion of the ENA allocation (30%) represents the distribution to the Ethena Labs team and advisors who have worked on the protocol to bring USDe to market. All core contributors are locked on a 1 year 25% cliff, with 3 year linear monthly vesting thereafter. No core contributor tokens are unlocked prior to the 1yr cliff.

***Investors***

The investor allocation represents token rights obtained by investors backing the Ethena protocol’s development, to bootstrap both the protocol and the Reserve Fund to support Ethena’s launch. All investors are locked on a 1 year 25% cliff, with 3 year linear monthly vesting thereafter. No investor tokens are unlocked prior to the 1yr cliff.

***Foundation***

The Foundation allocation will be used to further initiatives that serve to widen the reach of USDe, reducing crypto’s reliance on traditional banking rails and fiat-backed centralized stablecoins. This ENA will be used to fund further development, risk assessments, audits and much more.

***Ecosystem Development and Airdrops***

30% of ENA is allocated to developing the Ethena ecosystem, including the Rewards Campaigns, as well as various cross chain initiatives, exchange partnerships and much more.

Unlock schedules for Core Contributors and Investors started on ENA TGE at March 5th 2024.

Last updated 2 months ago

Was this helpful?