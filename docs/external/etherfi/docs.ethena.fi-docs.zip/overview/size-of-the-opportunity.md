# Size of the Opportunity

> Source: https://docs.ethena.fi/overview/size-of-the-opportunity

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/size-of-the-opportunity.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# Size of the Opportunity

Providing a crypto-native synthetic dollar and the first "internet bond" is not only the largest challenge in the space but the largest opportunity.

The reward-bearing digital dollar sector currently accounts for approximately 5-6% of the total stablecoin market capitalization.

With various forecasts predicting a compound annual growth rate (CAGR) of over 50% for stablecoin supply during the next decade, the total market is projected to exceed $2 trillion by 2032.

> *"I believe that stablecoin legislation backed by U.S. treasuries or T-bills will create a market that will expand U.S. dollar usage via these stablecoins all around the world. I think that  $2 trillion is a very reasonable number, and I could see it greatly exceeding that." *
> 
> *- Scott Bessent, U.S Treasury Secretary*

Last updated 2 months ago

Was this helpful?