# ENA

> Source: https://docs.ethena.fi/overview/ena

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/ena.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# ENA

ENA is the governance token of the Ethena protocol. ENA is used to govern parameters of the protocol, including the composition of USDe backing, the introduction of new backing strategies, the future allocation of protocol revenue, and the membership and remit of the Risk Committee. ENA is available across Ethereum and a number of supported chains through LayerZero, with governance accessible wherever ENA is held.

### sENA[](#sena)

sENA is the staked form of ENA. Holders deposit ENA into the staking contract and receive sENA, an ERC-20 token representing their position. The contract is implemented as an ERC-4626 wrapper, and unstaking is subject to a cooldown period before ENA can be withdrawn. Staking ENA into sENA signals long-term alignment with the protocol and is a route through which ENA holders participate in governance.

### Governance[](#governance)

Ethena governance operates through the Ethena governance forum and on-chain voting, with proposals subject to discussion, Risk Committee review where relevant, and a vote of ENA holders. The Risk Committee is a standing body responsible for setting risk parameters across the protocol - including eligibility of backing assets, exposure limits, counterparty limits, and the activation conditions for mechanisms such as the Fee Switch - and its membership is itself subject to governance.

The combination of token-holder voting, an active Risk Committee, and implementation of approved parameters allows the protocol to operate a diversified and dynamic backing portfolio while keeping decision-making transparent and subject to ENA holder oversight.

[https://gov.ethenafoundation.com/](https://gov.ethenafoundation.com/)

Last updated 2 months ago

Was this helpful?