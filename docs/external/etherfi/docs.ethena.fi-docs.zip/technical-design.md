# Overview

> Source: https://docs.ethena.fi/technical-design

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/overview.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Overview

Ethena's solution has both **Onchain** and **Offchain **composite components & services.

The **Onchain **components include the smart contracts that enable the minting, redeeming, staking, and unstaking of *USDe*.

The **Offchain** components include services that manage the delta hedging positions with respect to deposited backing assets.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FuVAV5EN5BufxVzHdQ7o1%252FMechanics%2520of%2520Creating%2520USDe.png%3Falt%3Dmedia%26token%3D27ca116e-61cd-4471-8e3d-a7edf35b7110&width=768&dpr=3&quality=100&sign=be8381387ab0f3f8011cd917d763b0fa&sv=3)In order to access the centralized liquidity, explicit trade-offs need to be made for onchain trust assumptions which are detailed in this section.

## Ethena Labs Github[](#ethena-labs-github)

[![Logo](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fgithub.com%2Ffluidicon.png&width=20&dpr=3&quality=100&sign=53aa60032b1430c07d36166bd980e18f&sv=3)ethena-labsGitHub](https://github.com/ethena-labs)You can read more in the following sections:

- [Minting USDe](https://docs.ethena.fi/technical-design/minting-usde)
- [Staking USDe](https://docs.ethena.fi/technical-design/staking-usde)
- [Backing Asset Custody](https://docs.ethena.fi/backing-custody-and-security/backing-asset-custody)
- [Hedging System](https://docs.ethena.fi/technical-design/hedging-system)

Last updated 1 year ago

Was this helpful?