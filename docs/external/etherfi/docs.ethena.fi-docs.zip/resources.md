# Custodian Attestations

> Source: https://docs.ethena.fi/resources

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/custodian-attestations.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Custodian Attestations

Monthly attestations are completed with the custodians to validate the existence, control, and value of the backing assets of *USDe*.

These attestations continue to demonstrate that NONE of the backing assets of USDe reside directly on any of our exchange partners.

- [August 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-august-3)
- [July 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-july-3)
- [June 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-june-3)
- [May 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-may-3)
- [April 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-april-2)
- [March 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-march-2)
- [February 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-february-3)
- [January 2026](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-january-2)
- [December 2025](https://ethena.fi/blog/custodian-attestations-of-assets-backing-usde-december-2)
- [November 2025](https://paragraph.com/@ethena-labs/custodian-attestations-of-assets-backing-usde-november-1)
- [October 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/baymLlfUc7YCA3mdeOW_tc-NaLJDWWkdnybxLQwld3c)
- [September 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/yrSiyb8fSutBC-8wULe62APuFbwXk4LqUGVNb3qRXHI)
- [August 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/0m4-yiSkoN6XlanyofLr-eJd8XHo2w2VUL1PL_vFsa4)
- [July 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/Hs8AVDEe7Qnks3AJ5Ka-QBc3CLGZDqhq5DBW-cr7yh0)
- [June 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/lQanXaRa4s5mHGu7yIjjT-KF22URVZcghYHrQYqfQa8)
- [May 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/8Cx2nU-1TwGo5OsnyCi_HCWju2wNXEpO9HlzWJLPQ6U)
- [April 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/7xYiJceDTzwBvkTUshezD9WisRiwWjXPGMtslr6N3mE)
- [March 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/EiNBer-fEbBJHKrmLTI168pWk6Eu-B6Gv_oRDp3euR0)
- [February 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/DaWy1xbpUfx69axYuEFgF0Scd4saF5bf_ryLRrOnAkM)
- [January 2025](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/6w5TREuNAwdHal6u6FVxN5GWFWef69aSWZjHWcEhYVM)
- [December 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/FHX-LgNXz7JUZLzKzmipz0TVvC3MaxeFlDkKxgRyJOw)
- [November 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/cUa8Y-LHi6eZYa08xOib5kl0af4ifez9F6b5UFbPOdQ)
- [October 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/XucATKA9brR_ghjIrbLFYeL-VvQlhL4nB3f7PZpBJas)
- [September 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/Btc0b_F4vGPVqTM4Mzr7dGun6durii-0IwzFlCQP11I)
- [August 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/sjs9mUohKwyx2x9pDm3fZIUpESjcPuamtL1cR4vSiQw)
- [July 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/yurfQ7faJekhsa8AFfX8EER6H4hng2deKrO_bhbLrlE)
- [June 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/xbvUJqbZFWwrXTVDM3rTQ1NT6BrPZvkFWNA1zBKbxVY)
- [May 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/bwzBngcOk-n9XB0venIjS1OPiSx3-39GDcqUaOABpgM)
- [April 2024](https://mirror.xyz/0xF99d0E4E3435cc9C9868D1C6274DfaB3e2721341/lQ4dluLMR9o97eyohmrkZsQuZr9L73uYoCnjbck2UTI)

The [Transparency](https://app.ethena.fi/dashboards/transparency) section of the Ethena dashboards contain all monthly attestations to date.

Last updated 1 month ago

Was this helpful?