# Copper Clearloop Case Study

> Source: https://docs.ethena.fi/backing-custody-and-security/overview/copper-clearloop-case-study

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-custody-and-security/overview/copper-clearloop-case-study.md).CopyOn this page
1. [Backing Custody & Security](https://docs.ethena.fi/backing-custody-and-security)
2. [Overview](https://docs.ethena.fi/backing-custody-and-security/overview)

# Copper Clearloop Case Study

Ethena initially launched using [Copper’s Clearloop](https://copper.co/products/clearloop) solution before onboarding additional OES providers. Copper is a UK-based custodian that has been the bedrock of institutional digital asset trading since 2018.

### Key Points[](#key-points)

1. Copper has never been hacked or lost users’ funds in contrast to the $7bn lost in DeFi.
2. Copper users’ funds were wholly available within days of Coinflex’s (exchange) failure.
3. Copper users’ funds are held within a bankruptcy-remote trust, meaning in the event of Copper’s failure, users’ funds are not expected to be part of Copper's estate.
4. Exchanges are also required to post collateral with Copper as to ensure frictionless settlement with each two or four hour cycle.
5. Ethena retains the ability to dispute erroneous exchange settlement requests.

Here is a deck that provides even more detail about Copper's specific solution for Ethena:

[Ethena_Copper.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fe04Uu0CKjyFU4KgpGotd%2FEthena_Copper.pdf?alt=media&token=a44037f0-43ea-4a40-885a-c09a7198cb37)PDF · 5MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fe04Uu0CKjyFU4KgpGotd%2FEthena_Copper.pdf?alt=media&token=a44037f0-43ea-4a40-885a-c09a7198cb37)Last updated 1 year ago

Was this helpful?