# Off-Exchange Settlement in detail

> Source: https://docs.ethena.fi/backing-custody-and-security/overview/off-exchange-settlement-in-detail

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-custody-and-security/overview/off-exchange-settlement-in-detail.md).CopyOn this page
1. [Backing Custody & Security](https://docs.ethena.fi/backing-custody-and-security)
2. [Overview](https://docs.ethena.fi/backing-custody-and-security/overview)

# Off-Exchange Settlement in detail

Secured asset custody

Ethena uses multiple "Off-Exchange Settlement" providers such as [Copper](https://copper.co/products/clearloop), [Ceffu](https://www.ceffu.com/), and [Fireblocks](https://www.fireblocks.com/).

These are three separate, non-US based & owned, well-regarded & institutionally focused organizations with the sole focus of holding digital assets in custody.

Protocol assets are never held in control or beneficially owned by the "Off-Exchange Settlement" provider at any point.

### Management of Risks[](#management-of-risks)

There are two principal risks that are front of mind when using "Off-Exchange Settlement" providers:

1. *Accessibility and Availability*-Ethena’s ability to deposit, withdraw, and delegate to and from exchanges. Any of these abilities being unavailable or degraded would impede the trading workflows & availability of the **mint**/**redeem** *USDe *functionality.

  - It is important to note that if there was a degradation of the availability of this functionality it should NOT affect the value of *USDe's *backing.
  - Ethena actively monitors and engages with partners. The system also uses multiple "Off-Exchange Settlement" providers to mitigate the potential impact of service degradation of one.
2. *Performance of Operational Duties* - In the event of an exchange failure, the protocol is reliant upon the cooperation and legal behavior of our "Off-Exchange Settlement" provider partners to facilitate the expedient transfer of any PnL at risk with an exchange.

  - It is important to note that exchanges typically post collateral with "Off-Exchange Settlement" providers to ensure the "Off-Exchange Settlement" provider is able to settle without delay given the typical rolling 4-hour settlement cycle frequency.

Ethena uses multiple "Off-Exchange Settlement" providers with the same exchange as a further step to help mitigate the aforementioned risks.

### Additional Benefits[](#additional-benefits)

"Off-Exchange Settlement" providers also enable Ethena to connect to more than just centralized exchanges as pools of liquidity. With our "Off-Exchange Settlement" partners, Ethena is able to connect to decentralized exchanges as well as OTC markets without hassle. This enables Ethena to diversify counterparty risk, among other risks, by holding hedging positions with a greater number of counterparties (CeFi Exchanges, DeFi Exchanges, OTC Counterparties).

"Off-Exchange Settlement" providers also enable Ethena to offer on-demand **mint/redeem** *USDe *workflows in a timely and cost-effective manner. There is no delay or additional cost when delegating/undelegated backing assets to/from exchanges.

Last updated 1 year ago

Was this helpful?