# Backing Asset Custody

> Source: https://docs.ethena.fi/backing-custody-and-security/backing-asset-custody

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-custody-and-security/backing-asset-custody.md).CopyOn this page
1. [Backing Custody & Security](https://docs.ethena.fi/backing-custody-and-security)

# Backing Asset Custody

Following on from [Collateral Custody & Security](https://docs.ethena.fi/backing-custody-and-security/overview), both Ethena's onchain and offchain composite services interact & engage with "Off-Exchange Settlement" providers in a number of ways.

Ethena uses "Off-Exchange Settlement" providers such as, but not limited to, [Copper](https://copper.co/) and [Ceffu](https://www.ceffu.com/).

### Overview[](#overview)

Given the peg stability mechanism of *USDe*, Ethena's "Treasury Management" system increases and decreases the sizes of delta hedging derivatives positions as users **mint **and **redeem ***USDe*. As the supply of *USDe *increases, the delta will change and more short derivative positions are entered into to eliminate backing asset price exposure, and vice versa when USDe supply shrinks.

In the process of **minting **& **redeeming ***USDe*, users transfer & request backing assets in exchange for/from *USDe*. In addition, given *USDe's *peg stability mechanism, Ethena needs to be able to:

- Safely & securely custody protocol backing assets.
- Transfer backing assets between smart contracts & users.
- Delegate/Undelegate backing assets between "Off-Exchange Settlement" providers and centralized exchanges.

Ethena also needs to be able to transfer rewards to the Staking Smart Contract & the "Off-Exchange Settlement" provider plays a role.

### Example Internal Workflows[](#example-internal-workflows)

Some workflow examples to highlight how different components of the system interact with "Off-Exchange Settlement" providers:

- Upon a user successfully **minting ***USDe*, the transferred asset is transferred by the Minting smart contract directly to the "Off-Exchange Settlement" provider.
- Upon a user successfully **minting ***USDe*, the internal hedging system needs to open an additional short derivatives position to hedge the increased delta exposure of the newly transferred asset from the user. As such, the "Off-Exchange Settlement" provider is instructed to delegate funds to the exchange.
- Upon a user successfully **redeeming** *USDe*, the user receives protocol backing assets from the Minting smart contract in exchange for the redeemed USDe. The minting smart contract needs to be actively monitored and refilled with protocol backing assets from an "Off-Exchange Settlement" provider.
- Upon a user successfully **redeeming ***USDe*, the internal hedging system needs to close the corresponding short derivatives position as the protocol no longer needs to hedge the delta exposure of the assets transferred to the redeeming user.
- Upon the protocol earning revenue, the funds are undelegated from the "Off-Exchange Settlement" provider and used to **mint ***USDe*.

### "Off-Exchange Settlement" Provider Benefits[](#off-exchange-settlement-provider-benefits)

"Off-Exchange Settlement" providers provide unique benefits critical to many aspects of the user experience:

1. **Ethena is able to prove the existence and control of protocol funds onchain.**

  - Protocol backing assets remain onchain with solutions provided by regulated and trusted parties. These entities are non-US based.
  - This enables users to enjoy the benefits of the ability to verify the existence and control of assets onchain, while also enjoying the benefits of high governance & security protections used by institutional participants.
2. **Ethena mitigates the risks of CeFi Exchange failure.**

  - "Off-Exchange Settlement" providers require exchanges to post collateral with the provider to ensure each settlement cycle can occur without friction. This combined with frequent PnL settlement cycles, Copper is daily, enables Ethena to enjoy the benefits of CeFi liquidity without risking protocol backing assets with an obscure entity.
3. **Ethena controls the "deposits" and "withdrawals" of funds.**

  - Each CeFi Exchange has varying deposit & withdrawal processes and speeds of operation. This can leave users waiting hours or days to be able to withdraw their assets.
  - "Off-Exchange Settlement" providers enable Ethena to, in all market conditions, delegate & undelegate assets to margin derivatives positions without having to wait for the exchange or an onchain transaction. Delegation/undelegation operations typically take seconds and are at no cost to the protocol.
  - This enables Ethena to offer on-demand **mint**/**redeem ***USDe *requests to eliminate the friction of users being able to on & off-ramp from *USDe*.
4. **Ethena remains agnostic to providers through each step of the workflow.**

  - Optimally, the system would use as many high-quality providers as possible for each step of the workflow. This enables Ethena to mitigate many risks as well as encourages an ecosystem that benefits users & the protocol.
  - It is the intention to onboard with as many "Off-Exchange Settlement" providers as reasonable and to champion transparency & independent verification of assets features across the space.

---

### Custody FAQ[](#custody-faq)

[Notion FAQ Link](https://ethena.notion.site/Ethena-FAQs-3ccc1437e13343f8b74c0d005e4f5128)

Last updated 2 months ago

Was this helpful?