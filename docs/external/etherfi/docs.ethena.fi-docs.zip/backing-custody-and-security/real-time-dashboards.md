# Real-Time Dashboards

> Source: https://docs.ethena.fi/backing-custody-and-security/real-time-dashboards

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-custody-and-security/real-time-dashboards.md).CopyOn this page
1. [Backing Custody & Security](https://docs.ethena.fi/backing-custody-and-security)

# Real-Time Dashboards

Below is the main Ethena dashboard highlighting Ethena's positions across different exchanges and assets.

[Positions Dashboard](https://app.ethena.fi/dashboards/positions)

Copper & Ceffu operate omnibus solutions with hot/warm/cold wallets wherein all of their users' funds are co-mingled. This does not break or compromise the protocol's ownership or claim on the backing in either solution.

As a result, the Copper omnibus & Ceffu deposit addresses don't represent the value of assets held by the protocol, but show the initial deposit upon direct mints of USDe with the protocol.

Last updated 3 months ago

Was this helpful?