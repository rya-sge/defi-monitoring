# Overview

> Source: https://docs.ethena.fi/backing-custody-and-security/overview

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-custody-and-security/overview.md).CopyOn this page
1. [Backing Custody & Security](https://docs.ethena.fi/backing-custody-and-security)

# Overview

A focus on security & control

"Backing Custody" refers to where protocol backing assets are held.

To access centralized exchange liquidity, Ethena must provide backing assets to support the delta hedging derivative positions that act as the peg stability mechanism.

Ethena holds all backing assets with "Off-Exchange Settlement" solutions. These providers both custody deposited assets as well as enable Ethena to delegate/undelegate assets to/from centralized exchanges without ever transferring the assets to the exchanges.

"Off-Exchange Settlement" providers enable Ethena to settle the outstanding PnL of Ethena's derivatives positions frequently. This enables Ethena to mitigate potential impact in the event of an exchange failure between settlement cycles.

Most importantly, Ethena depositing backing assets assets with an "Off-Exchange Settlement" provider does not transfer beneficial title over the assets to the provider or exchange partners. In the event of an agreed exchange failure, Ethena should be able to delegate funds to another exchange to support hedging requirements.

"Off-Exchange Settlement" providers such as [Copper](https://copper.co/products/clearloop), [Ceffu](https://www.ceffu.com/), and [Fireblocks ](https://www.fireblocks.com/)have long been used by institutional participants in the space to ameliorate this exact risk.

### Transparency[](#transparency)

Ethena strongly believes in users' ability to independently verify the existence and control of the protocol backing as well as the hedging derivatives positions.

- All "Off-Exchange Settlement" providers may enable the provision of onchain wallet addresses so users can validate the existence of the protocol backing assets; however, as some backing assets are held in omnibus accounts with other assets, this might not be feasible.
- Periodic attestations (at least monthly) by custodial partners of backing asset value held within institutional custodial solutions will be published to provide transparency where addresses are not able to be provided.
- Ethena is actively exploring tools to help publicly prove & enable users to independently verify the existence of hedging derivatives positions.

### Approach to Decentralization[](#approach-to-decentralization)

There are a variety of trade-offs to consider when evaluating the degree to which the protocol relies on maximally decentralized solutions.

The core mission of creating a stablecoin equivalent that is not reliant on banking infrastructure has to date required either:

1. Capital inefficient overcollateralized "loans" onchain.
2. Unstable algorithmic designs.
3. Unscalable delta-neutral designs that are fully reliant on decentralized exchanges.

In order to address the shortcomings of prior delta-neutral peg mechanism designs it is necessary to interact with centralized liquidity venues where open interest and trading volume on derivatives are >25x larger than onchain liquidity venues.

However, doing so introduces new custodial risks with exchanges. **How does Ethena address this?**

The focus is generally on leveraging solutions for the most important qualities of decentralized exchanges, namely:

1. Holding of assets outside opaque centralized servers.
2. Fully auditable and transparent.
3. Permissionless and programmatic withdrawal.

The use of "Off-Exchange Settlement" providers largely addresses these qualities & enables Ethena to create a synthetic dollar that can meaningfully scale without being overly reliant upon a single source of liquidity, a single custodian of funds, etc.

Last updated 1 year ago

Was this helpful?