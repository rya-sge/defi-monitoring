# Underlying Derivatives

> Source: https://docs.ethena.fi/protocol-overview/underlying-derivatives

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/underlying-derivatives.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Underlying Derivatives

## Context[](#context)

Ethena utilizes derivatives positions to buttress the synthetic USD value of the backing assets in most market conditions. This is achieved by being "delta neutral" through the use of an offsetting short derivatives position to the natural long spot position from backing assets.

In the subsections below, we go into what each term refers to and the key differences:

- Futures vs Perpetuals
- Inverse vs Linear Contracts
- Basis Spread

## Overview[](#overview)

Ethena trades derivatives across all major centralized exchanges that are supported by "Off-Exchange Settlement" providers.

At a high level, Ethena trades derivatives with a few motivations:

- Ethena opens a short position when a user **mints** *USDe*.
- Ethena closes a short position when a user **redeems** *USDe*.
- Ethena closes/opens positions across exchanges to realize unrealized PnL.
- Ethena algorithmically optimizes positions in the backing portfolio to account for risk.
- Ethena algorithmically optimizes positions in the backing portfolio to account for the differences between the exchanges' derivative contract specifications & the capital efficiency available from each exchange.

It is important to note that not all exchanges offer the same derivatives contracts and there are often key differences between each. Ethena is also sensitive to the exchange-assigned backing assets value when using liquid staking Ethereum assets, such as stETH, to margin ETHUSD or ETHUSDT Perpetual positions.

Last updated 1 year ago

Was this helpful?