# Scenario Analysis

> Source: https://docs.ethena.fi/protocol-overview/scenario-analysis

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/scenario-analysis.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Scenario Analysis

Understanding how price movements in BTC impact USDe

Given *USDe's *underlying peg stability mechanism is for the protocol to be long spot assets & short a derivatives position, a common question has been:

**"How does a change in the price of BTC affect the underlying backing composition?"**

This is a great question in that it allows discussion in more detail about the composition of assets in the Ethena backing in different BTC price scenarios.

---

## Overview[](#overview)

Given the protocol utilizes both inverse coin-margined and linear usd-margined contracts as well as trades across multiple exchanges, there are differences in how Ethena settles outstanding PnL. These differences stem from:

- Each exchange's contract specifications, margining, and risk systems being subtly different.
- Inverse coin-margined contracts typically recording & settling PnL in base currency (eg BTC for BTCUSD Perpetual contracts) terms while linear contracts typically recording & settling in *USDT *(eg for ETHUSDT Perpetual contracts).

This brings up an important subject of "unrealized" and "realized" PnL.

- "Unrealized PnL" refers to when an existing position has incurred a profit or loss (difference between the average position price & the mark price of the contract), but the position has not yet been fully or partially closed. In essence, for example, the position has an outstanding profit/loss denominated in *BTC *or *USDT*, but this has not been received or paid from or to the portfolio's collateral balance.
- "Realized PnL" refers to when a part or all of a position has been closed and has received or paid the  PNL to/from the collateral balance.

What this means is that Ethena typically receives/pays profit/loss in *BTC or USDT *depending upon the exchange and margin type of the positions the protocol is trading.

A change in the price of *BTC *does NOT mean the portfolio is immediately buying/selling collateral to meet unrealized PnL moment by moment.

As a result, this means that the portfolio at times has balances owed to it or owes in *BTC *or *USDT *terms. The ~USD value of the backing assets underpinning the synthetic dollar remains constant.

The protocol expects to be able to naturally "realize" "unrealized PnL" by:

- Closing existing positions when **redeem** *USDe* requests are received.
- Periodically rolling hedging positions between exchanges as it suits the risk & return framework.

---

## Scenarios[](#scenarios)

### BTC Price Decreases[](#btc-price-decreases)

In this scenario, the price of *BTC *decreases from when the positions were opened upon **minting ***USDe*. This means the portfolio's derivatives positions have unrealized profits across both inverse coin-margined & linear margined positions. These unrealized profits are denominated in BTC & *USDT*. Ethena has not sold or reduced the amount of backing assets the protocol is holding.

There is no significant drag to the portfolio's yield or risk by holding a small proportion of the portfolio in unrealized *BTC *or *USDT *terms.

Below are two examples demonstrating the impact of differing price scenarios upon inverse & linear contract margined positions. You'll notice the portfolio is able to either purely hold BTC to margin positions or is able to hold a proportion in the "Settlement Currency" (the motivations will be discussed further down).

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FScmCB8OZiXPpOgZ69yYK%252FScenario%2520Analysis%2520-%2520Bybit%2520Linear%2520Margined%2520Positions.png%3Falt%3Dmedia%26token%3D70562628-1f25-4999-835a-a0f40ec3ed88&width=768&dpr=3&quality=100&sign=6be0d70a60d692a9aac6cefcb21ff227&sv=3)Linear Margined Positions![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FEfiXEg1eLkSJzD2VRnMq%252FScenario%2520Analysis%2520-%2520Binance%2520Inverse%2520Margined%2520Positions.png%3Falt%3Dmedia%26token%3D408e507f-16d9-4484-ad63-6294c2d3daf2&width=768&dpr=3&quality=100&sign=3014b9af03535b6550f0bbb417301260&sv=3)Inverse Margined PositionsYou'll notice as the price of *BTC *continues to fall, a greater proportion of the protocol's backing assets value resides in the unrealized profit of the hedging position.

It's important to keep in mind the portfolio is automatically rebalanced by Ethena and the extreme, edge-case price scenarios are designed to demonstrate if rapid movements were to occur and the Ethena system were not to intervene.

### BTC Price Increases[](#btc-price-increases)

In this scenario, the price of *BTC *increases from when the positions were opened upon **minting** *USDe*. This means the portfolio's derivatives positions have unrealized losses across both inverse/coin-m & linear margined positions. These unrealized losses are denominated in *BTC *& *USDT*. Ethena has not sold or reduced the amount of backing assets the protocol is holding.

There is no significant drag to the portfolio's yield or risk by holding a small proportion of the portfolio in unrealized *ETH *or *USDT *terms.

It is important to note that the loss on the derivatives positions is perfectly offset by the gain in the value of the spot assets in normal market conditions. The ~USD collateral underpinning *USDe *generally remains constant in those environments.

One difference between the price of BTC increasing vs decreasing is that Ethena across many exchanges needs to be able to meet the unrealized loss with the "Settlement Currency" asset of the contract. The "Settlement Currency" asset of the contract is the asset in which PnL is settled. For example, for BTCUSDT Perpetual positions, PnL is settled in *USDT*. As such Ethena is able to:

- Maintain a balance of the "Settlement Currency" in the portfolio to meet this requirement.
- "Borrow" the balance from the exchange, at a reasonable variable interest rate, until the debt is extinguished (by acquiring the "Settlement Currency").

Below are two examples demonstrating the impact of differing price scenarios upon inverse & linear contract margined positions.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FvVxHnR5QhFTjXtYKPSO2%252FScenario%2520Analysis%2520-%2520Increase%2520-%2520Bybit%2520Linear%2520Margined%2520Positions.png%3Falt%3Dmedia%26token%3D5d9e64f3-6127-4ac9-98de-c4324dad79ea&width=768&dpr=3&quality=100&sign=09dc59c0200a359a524ad741fc1f4f15&sv=3)Linear Margined Positions![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252Fhba79S5HMzjCn4RLKpA3%252FScenario%2520Analysis%2520-%2520Increase%2520-%2520Binance%2520Inverse%2520Margined%2520Positions.png%3Falt%3Dmedia%26token%3D1487e13a-aff2-41e6-a178-f0fb1b07dae8&width=768&dpr=3&quality=100&sign=8a817f1b30bfa32de4c4f059b79807e0&sv=3)Inverse Margined PositionsYou'll notice as the price of *BTC *increases, a greater proportion of the protocol backing value resides in the spot Staked Ethereum asset with the unrealized loss in *BTC *or *USDT *terms growing.

It's important to keep in mind the portfolio is actively managed by Ethena & the extreme price scenarios are designed to demonstrate if rapid movements were to occur & Ethena were not to intervene. This is not a realistic assumption in reality.

---

## Scenario Consequences to the Portfolio[](#scenario-consequences-to-the-portfolio)

As you'll notice from the scenarios the examples above, there is benefit for the Ethena system to manage the composition of the portfolio as the *BTC *price changes. This management does not need to occur every 5/10/20% difference in price as the implications are related to economic efficiency rather than stability.

The natural **mint **& **redeem ***USDe *flow in combination with automated rebalancing ensures even in the most volatile markets the cost to the portfolio will be minimal & offset by the revenue generated.

---

## Further Notes[](#further-notes)

Given Ethena utilizes both inverse/coin & linear margined contracts, a question has been: **"What proportion of the portfolio is in USDT under different rapid price movements?"**

With the intention to keep this brief, you'll notice in the image below the scenarios wherein the portfolios has greater USDT exposure.

Given the protocol uses both inverse coin-margined contracts as well as linear usd-margined contracts, the proportion very much depends upon how much of the portfolio is hedged with either. As a protocol, we have a firm bias towards using inverse contracts. This is primarily a risk-related decision given it removes the reliance on USDT as well as because of its capital efficiency.

It's also important to note that the portfolio is actively managed & when the price of the underlying asset changes significantly, there is a greater likelihood that the positions will have already been rolled to realize the "unrealized PnL".

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FwZWqbjsEsjEZNLSlOflo%252Fimage_2023-11-15_08-48-25.png%3Falt%3Dmedia%26token%3Dc69623bb-cada-4764-b063-7a9c710c9005&width=768&dpr=3&quality=100&sign=832ca7e75571cbda573d7a8c75126ab1&sv=3)

Last updated 1 year ago

Was this helpful?