# Backing Assets Risk

> Source: https://docs.ethena.fi/protocol-overview/risks/backing-assets-risk

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/backing-assets-risk.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Backing Assets Risk

## **Context**[](#context)

Given Ethena uses some stETH and other LSTs in part to margin the delta hedging derivatives positions, the integrity and confidence in those assets is paramount. "Backing Assets Risk" in this context refers to the fact that a backing asset for USDe differs from the underlying asset of the perpetual futures position.

Ethena is agnostic to Ethereum LSTs. While *stETH *market share initially looked to be winning in a winner's take-all market, its market share has dramatically been reduced by other assets such as Mantle's *mETH*.

As in these cases the backing asset, *ETH LSTs*, is different to the underlying asset of the hedging contracts, *ETH*, Ethena needs to ensure the price difference between those two assets is as small as possible. This is accomplished by supporting LST assets with the least chance of depegging and broad industry support.

As discussed in the [liquidation risk](https://docs.ethena.fi/protocol-overview/risks/liquidation-risk) section, due to low leverage and tighter collateral haircuts, the impact of a stETH depeg is minimal to hedged positions and the possibility of liquidation is extremely unlikely.

Staked Ethereum assets make up just ~6% of the backing assets of USDe as of January 2025.

Last updated 1 year ago

Was this helpful?