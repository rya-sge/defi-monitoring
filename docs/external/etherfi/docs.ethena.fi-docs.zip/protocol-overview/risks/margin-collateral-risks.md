# Margin Collateral Risks

> Source: https://docs.ethena.fi/protocol-overview/risks/margin-collateral-risks

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/margin-collateral-risks.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Margin Collateral Risks

Ethena uses both linear and inverse margined perpetual futures, using linear perpetual futures that are  denominated in USDT. Denominating in Tether means that the margin and PNL calculations are quoted in Tether, and by extension, results in Ethena being positionally long USDT.

For example, if Ethena posts BTC as margin collateral, and takes a short position on a linear BTC/USDT perpetual future - Ethena has a delta of 0 on BTC due to being long spot (collateral) and short futures (perpetual), but it is directionally long USDT (quote currency) with no offsetting short exposure.

The inherent risk this presents is exposure to a potential USDT idiosyncratic event.

For context, 80% of perpetual futures open interest is stablecoin-margined, with the vast majority of those quoted in USDT.

Ethena closely monitors USDT stablecoin price risk and solvency, and if a problem persists will take action accordingly. In this instance, Ethena would aim to move more of the perpetual futures positions into inverse contracts, margined with BTC or ETH, depending on liquidity.

Last updated 1 year ago

Was this helpful?