# Exchange Failure Risk

> Source: https://docs.ethena.fi/protocol-overview/risks/exchange-failure-risk

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/exchange-failure-risk.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Exchange Failure Risk

## Context[](#what-happens-in-the-event-of-a-bankruptcy-of-an-exchange)

Ethena utilizes derivatives positions to offset the delta of the protocol backing assets. These derivatives positions are traded upon CeFi exchanges such as Binance, Bybit, Bitget, Deribit, and Okx. As such, in the event an exchange were to suddenly become unavailable such as FTX, Ethena would need to manage the consequences. This is the "Exchange Failure Risk" we are referring to.

Protocol backing is NEVER deposited to exchanges and always resides with "Off Exchange Settlement" providers. Ethena has made significant efforts to minimize exposure to exchange failures.

## What happens in the event of a failure of an exchange?[](#what-happens-in-the-event-of-a-bankruptcy-of-an-exchange-1)

Ethena retains complete control and ownership of the assets via Off-Exchange Settlement providers with no backing assets ever being deposited with any exchange. This limits Ethena's exposure to idiosyncratic events on any one exchange to the outstanding PnL between Off-Exchange Settlement providers' settlement cycles.

> Copper's Clearloop runs a settlement cycle daily.

As such, in the event of an exchange failure, Ethena would delegate the backing assets to another exchange and hedge the outstanding delta that was previously covered by the failed exchange. In the event of an exchange failure, the derivatives positions are considered closed with Ethena holding/owing no further obligation to the exchange estate.

Capital preservation is front of mind for Ethena. In the event of extreme circumstances, Ethena will always work to protect the value of the backing assets & *USDe *stable peg.

## How is the exchange failure risk managed?[](#how-is-the-exchange-failure-risk-managed)

As with all parts of Ethena' workflows, Ethena is agnostic to each provider at each step of the workflow.

- Ethena diversifies the risk and mitigates the potential impact of exchange failure by utilizing multiple exchanges.
- Ethena is continually integrating with new sources of liquidity in an effort to limit the protocol's exposure to each source.
- Ethena actively monitors the ecosystem with investors, advisors, and friends across the industry, taking a proactive approach to de-risking exchange exposure if associated risks are perceived to have changed.

Ethena distribution across hedging venues can be viewed in our [transparency dashboards.](https://app.ethena.fi/dashboards/transparency)

Last updated 15 days ago

Was this helpful?