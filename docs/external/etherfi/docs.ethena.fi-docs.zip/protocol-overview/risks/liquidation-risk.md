# Liquidation Risk

> Source: https://docs.ethena.fi/protocol-overview/risks/liquidation-risk

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/liquidation-risk.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Liquidation Risk

## Context[](#context)

While Ethena currently uses spot ETH and BTC as backing assets for short derivatives positions, Ethena uses a certain amount of staked Ethereum spot assets and liquid stables as backing assets as well (6% ETH LST's and 7% liquid stables as of January 2025 per the [Positions dashboard](https://app.ethena.fi/dashboards/positions)).

As a result of the protocol sometimes using a different asset than the underlying (ETH or BTC) of the derivatives positions, and exchange partners operating on a "No Loss" principle, exchanges retain the discretion to forcibly close positions when there is a considerable difference in value between the two assets.

This is called "Liquidation" across the space and only occurs when a user no longer has sufficient collateral to meet the margin requirements of the position. In this context, this is the "Liquidation Risk" being referred to.

This section aims to demonstrate how unlikely a liquidation event is, considering Ethena uses very minimal leverage. Further, at present, the composition of backing assets includes comparatively low amounts of LSTs. However, we felt it was necessary to address the possibility of liquidation and make users familiar with the extreme circumstances that would lead to such an event.

## Overview[](#overview)

At a high level, exchanges' risk engines ensure each user has sufficient "Maintenance Margin", to margin existing positions. Many exchanges now offer incremental liquidation as to reduce the cost to the user & the exchange, where a position is slowly closed vs immediately in-full.

Ethena's backing is principally dependent upon the spread between the value of protocol backing assets & the price of the short derivatives positions not diverging in a problematic manner.

## Spread[](#spread)

Given the importance to the protocol of the value of the staked Ethereum backing assets trading in line with *ETH*, it's worth sharing historical data for context.

### Lido's *stETH*'s Spread History[](#lidos-steths-spread-history)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FY9PzjLhAFb80f9TTQUXd%252FstETH%2520to%2520ETH%2520Daily%2520Premium%2520%2526%2520Discount.png%3Falt%3Dmedia%26token%3D261450ca-2ca2-4574-8eaa-34d01df62de1&width=768&dpr=3&quality=100&sign=17665a6bd91a8bdeae25accd2ace666e&sv=3)stETH Discount vs ETHSince the Shapella upgrade of the Ethereum network, wherein one of the features was that enabled users to unstake their *stETH*, the *stETH/ETH* discount has never been more than 0.3%.

Prior to Shapella, the discount reached 8% at its widest. Users' ability to unstake their *stETH *for *ETH *on-demand as well as via swapping in external markets, such as Curve, has ensured that *stETH *is valued extremely closely to *stETH*.

### Exchange *stETH* Spread History[](#exchange-steth-spread-history)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FXzpkPyrSKrD6728Og6qE%252Fimage.png%3Falt%3Dmedia%26token%3D8b27c03b-b479-4354-bf00-88b2f60c9082&width=768&dpr=3&quality=100&sign=f6eae54026dfb249e677a2cff9915eeb&sv=3)While each exchange's risk & liquidation engines are different, the above graph demonstrates the difference between the "Mark Price" and the "Index Price" for *stETH *& an exchange partner's ETHUSD Perpetual in 2023. The "Mark Price" is how the exchange partner values an ETHUSD Perpetual position while the *stETH "*Index Price" is that of the *stETH *spot asset collateral.

This graph demonstrates that for 2023 the widest the spread has been is -3.27% with a median of -0.50%. This further illustrates that the value of the staked Ethereum collateral does not diverge from the value of the perpetual position by an amount that would be anywhere near liquidation, let alone a cause of proactive risk management action from Ethena. In addition, while *stETH *historically held a dominant market share amongst *ETH *LSTs, that share has declined dramatically as alternatives such as Mantle's *mETH *have been introduced to the market, enabling further diversification across assets.

## Worked Example: ETHUSD Perpetual[](#worked-example-ethusd-perpetual)

Ethena plans to integrate with all major CeFi Exchanges. It makes sense to demonstrate Ethena's capacity to respond & under what scenarios Ethena's portfolio could be liquidated if the spread between *stETH *& our derivatives position widened abnormally.

> The modelling below aims to demonstrate how unlikely "Liquidation" is to occur. Such a scenario relies upon a series of unlikely events & a series of assumptions to hold that are unlikely to in reality.

An exchange determines a users' "Maintenance Margin" requirement for a position and if the value of the users' collateral falls below this requirement, the user's position begins to be incrementally liquidated.

"Liquidation" does NOT mean Ethena loses all of the collateral instantly.

It refers to the process by which the exchange incrementally decreases the risk exposure of the protocol's position. "Liquidation" will result in the protocol incurring a realized loss.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FDzzqhzVpSyKwKwKOzUdi%252FMaintenance%2520Margin.png%3Falt%3Dmedia%26token%3D679eb13f-ae4e-4be2-994d-5a542758e52e&width=768&dpr=3&quality=100&sign=893ee32d2184f7a5a8af6b85088d9578&sv=3)From the table above, you'll notice that the "MMR" increases as the size of the derivatives position increases. This results in increasing "Maintenance Margin" requirements as the position size grows.

Ethena does NOT trade with any material leverage, measured on an exchange-by-exchange basis, and as a result even with a position size >$100m, the position size grows approximately equally with the amount of *USDe *circulating, the amount of "Maintenance Margin" required is only half of the backing assets that will be delegated to the exchange.

In the tables below, we will demonstrate the available capacity even if the spread begins to widen & at what point Ethena would begin to be incrementally liquidated. The first column contains the discount scenarios between stETH and ETH, where ETH's value is worth anywhere from 0% to 65% more than stETH.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FJw6mVtQKoZN0UEdvTjpq%252FBasis%2520Spread%2520-%2520Bybit%2520Linear%2520Margined%2520Positions.png%3Falt%3Dmedia%26token%3D22c6630e-6d45-448b-9dfd-35754a66f2e7&width=768&dpr=3&quality=100&sign=2692799c9c73e7039dec3c010d1ca106&sv=3)Our example exchange partner values *stETH *in backing assets value terms 1:1 with *ETH*. This means it assigns the same backing assets value of holding 50,000 *stETH *as it does 50,000 *ETH*.

As a result, the spread would have to diverge to 65%, **which has never happened before**, with the maximum being 8% in history (before Shapella), before incremental liquidation of Ethena's position would begin & Ethena would incur realized losses.

This unlikely scenario assumes, and will be detailed further down this page, that Ethena does not take any proactive risk management measures to address this mark abnormality & reduce position size before liquidation is required. Ethena will take proactive risk management steps to protect the value of backing assets.

Some exchanges apply a discount to the value of *stETH *backing assets depending upon how the derivatives contract is margined & the depth of *stETH *liquidity in their spot order books. These discounts typically range from 1-0.85 *stETH:ETH *and are perpetually improving given the low-risk nature of this trade & integrity of the collateral.

To cover all scenarios, you'll notice that even with a *stETH:ETH* rate of 0.85 the spread needs to diverge to greater than ~25% - 41% to be exact. **This scenario has never happened before** and for the aforementioned reasons, is extremely unlikely to ever come close. As mentioned before, these scenarios also rely upon the unreasonable assumption that Ethena would not proactively intervene to manage risk.

Preserving the value of backing assets is of the utmost importance to the protocol and as a result, "Liquidation" is something the protocol never wishes to endure. Ethena core contributors work closely with exchange partners to constantly improve the assigned backing assets value of *stETH *& LSTs.

## Internal Risk Management Processes[](#internal-risk-management-processes)

Ethena principally trades systematically across multiple exchanges as we accommodate users **minting **& **redeeming ***USDe*, our need to cycle positions across exchanges to realize unrealized PnL, as well as our active need to manage liquidation risk across exchanges.

The Ethena core team features globally distributed team members who are manually able to intervene & are available 24/7 with experience in system maintenance from Wintermute, Flow Traders, Genesis Trading, DRW, and Tower Research. Ethena’s core team members tasked with manually intervening, if necessary, are both the creators and maintainers of the protocol's systematic trading system and are extremely familiar with all exchanges' risk engines & differences as a result of trading & technology backgrounds in the space (Deribit and Paradigm Liquidity).

Given one of the core value propositions of *USDe *is to remain relatively stable, Ethena never wishes to be or to come close to being liquidated. The steps below detail how Ethena would intervene in the case of a market abnormality as well as are realistic assumptions when evaluating the risk to the backing assets of *USDe*.

To mitigate "Liquidation Risk" as a result of the aforementioned risk scenarios:

- Ethena would systematically delegate additional backing assets to improve the margin position of hedging positions in the event either risk scenario eventuates.
- Ethena is able to cycle backing assets delegated between exchanges temporarily to support specific situations.
- Ethena has access to the reserve fund that can be rapidly deployed to support hedging positions on exchanges.
- In the event of an extreme occurrence, such as a critical smart contract flaw in a staked Ethereum asset, Ethena will immediately mitigate the risk with the sole motivation being protecting the value of the backing assets. This includes closing the hedging derivatives leg to avoid liquidation risk becoming a concern as well as disposing of the affected asset for another.

## Common "Liquidation" Concepts[](#common-liquidation-concepts)

Given we all have different backgrounds and histories in the space, it feels appropriate to quickly cover concepts such as an exchange "Insurance Fund" and "ADL". These terms directly relate to the function of exchanges' risk & liquidation engines.

### Exchange Insurance Funds[](#exchange-insurance-funds)

An "Insurance Fund" is a concept of all CeFi Exchanges wherein a proportion of trading & liquidation fees are deposited to insure users of the exchange against potential losses or failures of the exchange's risk & liquidation engine.

Exchange insurance funds aim to ensure all users in profit are made whole.

In the early days of crypto, markets were dramatically more volatile and less liquid. With a greater prevalence of high-levered traders, this resulted in many large profits, but also large losses. Given exchanges operate on a "No Loss" principle, these large losses had to be managed in a manner that didn't bankrupt the exchange or cause the user in profit to wonder if they'll actually get paid. As a result of dramatic increases in the sophistication of exchange risk & liquidation engines, "ADL", available liquidity, and reduction in available leverage, possible losses even in the most extreme circumstances are covered multiple times over by the exchange's reserve funds.

### Auto Deleveraging (ADL)[](#auto-deleveraging-adl)

Auto Deleveraging "ADL" refers to when an exchange forcibly closes a user's profitable position at the bankruptcy price of a bankrupt user to end the risk exposure to the exchange.

ADL typically only occurs after an exchange's reserve fund has been depleted and is unable to cover the outstanding shortfall. It's important to note that not all exchanges use ADL as a mechanism, such as Deribit.

These days, ADL is extremely unlikely to be triggered given the aforementioned reasons in the "Insurance Fund" section, but primarily because of the present-day size of exchange reserve funds to absorb losses.

It's important to keep in mind that if ADL were to occur, the users whose profitable positions were closed, would be able to immediately open those positions again. All users are able to mitigate the chance of being selected for ADL, typically based upon users' with positions in the most profit, by frequently realizing unrealized PnL. Ethena actively plans to do this as a part of standard risk management to note.

To note, some exchanges ascribe a haircut to the value of staked Ethereum assets used to margin derivatives positions.

Last updated 1 year ago

Was this helpful?