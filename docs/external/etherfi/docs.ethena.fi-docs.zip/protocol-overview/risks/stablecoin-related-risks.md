# Stablecoin-Related Risks

> Source: https://docs.ethena.fi/protocol-overview/risks/stablecoin-related-risks

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/stablecoin-related-risks.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Stablecoin-Related Risks

With the introduction of Ethena's dynamic backing asset allocation methodology, the incorporation of stablecoins such as USDC introduce certain additional risks associated with fiat-backed and "Real World Asset" (RWA)-backed stablecoins. Risks associated with these stablecoins are generally disclosed by the issuer of the token.

With respect to USDC, certain risks are disclosed in Section 13 of the USDC Terms available at: [https://www.circle.com/legal/usdc-terms](https://www.circle.com/legal/usdc-terms).

In addition, centralized stablecoins, such as *USDC *or *USDT*, provide stability and capital efficiency, but they introduce:

- Unhedgeable custodial risk with bond reserves in regulated bank or trust accounts which are prone to censorship.
- A critical reliance upon the existing traditional banking infrastructure and country-specific evolving regulations.
- Represent an unsecured credit position to both the issuer and underlying bank holding the reserve assets while mixing these assets with other bank lending activities, as we saw with Silicon Valley Bank.

Other centralized stablecoins that use RWAs as the reserve backing & distribute yield to holders face the same confiscation & censorship risk.

Due to these aforementioned risks, the dynamic allocation methodology only favors allocations to the stablecoin basket in periods of market distress that may threaten the Reserve Fund and overall asset backing for USDe.

Last updated 1 year ago

Was this helpful?