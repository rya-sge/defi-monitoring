# Funding Risk

> Source: https://docs.ethena.fi/protocol-overview/risks/funding-risk

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/funding-risk.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Funding Risk

## Context[](#context)

Given Ethena uses derivatives positions, such as perpetual contracts, to hedge the delta of the backing assets, the protocol is exposed to "Funding Risk".

"Funding Risk" relates to the potential of persistently negative funding rates. Ethena is able to earn revenue from funding, but could also be required to pay funding.

While this is a direct risk to the protocol revenue and backing, the data presented below demonstrates that negative funding periods tend not to persist and revert to a positive mean.

Negative funding rates are a feature, rather than a bug of the system. USDe has been built with this in mind.

We acknowledge that historical data before Ethena's launch does not reflect Ethena's impact on the market. We are monitoring updated funding rate dynamics and will provide updates to this section as we collect the new data.

## How Ethena manages Funding Risk[](#how-ethena-manages-funding-risk)

An Ethena reserve fund exists and will step in on occasions when the combined revenue between LST assets, such as stETH, the funding rate for a short perpetual position, the basis from short dated futures as well as potential rewards from holding liquid stables, is negative. This seeks to protect the spot backing underpinning *USDe*. Ethena does not pass on any "negative revenue" to users who stake *USDe *for *sUSDe*.

Ethena also adopts a dynamic allocation approach to the assets backing USDe. In periods of low or negative funding, more of the backing assets of USDe will be shifted into liquid stables earning approximately the U.S Treasury rate. This aims to reduce the exposure to negative funding rates and thus reduce the possibility of the Reserve Fund being drawn from. See the Dynamic Allocation section for more details.

### **Positive Bias**[](#positive-bias)

*BTC and ETH *funding rates have exhibited natural positive bias and contango, with an average annualized rate of between 7.8% - 9% over the last 3 years on an open interest or volume-weighted basis, including the 2022 bear market.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FqJpx8NknQzXGgZdoUXPV%252Fimage.png%3Falt%3Dmedia%26token%3D0c4017b4-8976-4aaf-83c4-82d64a6e8d23&width=768&dpr=3&quality=100&sign=bb310326077b24b634e1f4eeb50b473b&sv=3)Data updated as of 31st December 2024Below represents the 30d moving average of funding rates, indicating that positive bias is evident, particularly in 2021 and 2023.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FR0SVHjEOBOqRVVRRdCBD%252F30d%2520Moving%2520Average%2520ETH%2520Open%2520Interest%2520Weighted%2520Perpetuals%2520Funding.png%3Falt%3Dmedia%26token%3D12b1d08b-6208-42df-adfa-abab7f7e9ff6&width=768&dpr=3&quality=100&sign=3c5e3f2f1dbb3ac3386d345c9bf6c5ef&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252F9Jce4GdKQWDv03zWbVT3%252F30d%2520Moving%2520Average%2520BTC%2520Open%2520Interest%2520Weighted%2520Perpetuals%2520Funding.png%3Falt%3Dmedia%26token%3Df0d7a584-9d5a-49e2-8bde-225b3fcf871f&width=768&dpr=3&quality=100&sign=afb51f279e3f57460e83f29fe66aff9f&sv=3)Charting the distribution of funding rates per contract, one can further see the positive bias per exchange, with the coloured box per contract indicating the middle 50% of datapoints. That middle 50% of funding data is predominantly positive values on most exchanges.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FNtWcoDzXf4n5bWqvBBv9%252FETH%2520Linear%2520Perpetual%2520Futures%2520Funding%2520Rates%2520Distributions.png%3Falt%3Dmedia%26token%3D444c6245-8c24-4213-9f01-65abefe2fc98&width=768&dpr=3&quality=100&sign=02e0e63a7e96ab9f66158c4627b78646&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FvCpfaSyP3YBCNLCw2vK7%252FBTC%2520Linear%2520Perpetual%2520Futures%2520Funding%2520Rates%2520Distributions.png%3Falt%3Dmedia%26token%3D760b8fc9-15d8-4d46-99e4-f73dac0088cb&width=768&dpr=3&quality=100&sign=b5ea312890fd9dd54bd156f86dabe80f&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252Fo7qZ1cGlKbOSvq4ngbnk%252FETH%2520Inverse%2520Perpetual%2520Futures%2520Funding%2520Rates%2520Distributions.png%3Falt%3Dmedia%26token%3D0b3dc53b-9a3d-4deb-a852-5d6287b820c5&width=768&dpr=3&quality=100&sign=0682772f02ae50c6704f98ceeab6613b&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FyF1OTUyUX56m6499eSbn%252FBTC%2520Inverse%2520Perpetual%2520Futures%2520Funding%2520Rates%2520Distributions.png%3Falt%3Dmedia%26token%3D038a3156-6284-490b-873a-216fbbd9a207&width=768&dpr=3&quality=100&sign=9fc2cc60d5c54ef7b8f9ea79fe24197d&sv=3)
### **Margin of Safety**[](#margin-of-safety)

Using LST collateral, such as *stETH, *as collateral for *USDe, *provides an additional margin of safety for negative funding in the form of the ~3% annualized returns earned on *stETH*.

A reward-accruing liquid stables allocation also aims to provide an additional margin of safety, including the dynamic allocation approach mentioned above.

That is to say, protocol revenue will only be negative when the combined *LST *yield, revenue from liquid stables, and funding rate sum to be negative.

Looking at annualized funding rate values, one observes 17.5% and 15.9% of days had a sum negative return for *ETH* and *BTC* perpetual futures respectively, with an average return over the entire period of 9.15% for ETH versus 7.80% for *BTC*.

Combining annualized staked ETH income and *ETH* funding rate values, one observes only 8.84% of days had a sum negative revenue. This excess revenue could be seen as an upper bound to protocol revenue.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FmRd03O8qzoGFkZOxAp2x%252FETH%2520Positive%2520vs%2520Negative%2520Perpetual%2520Funding%2520Days.png%3Falt%3Dmedia%26token%3Da7455227-ae3a-403f-b463-fd8b4d9cf2f8&width=768&dpr=3&quality=100&sign=a5149043c8c1ca4d711357f41d32bae8&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FnrjbFr54W22HmrW7xTFi%252FBTC%2520Positive%2520vs%2520Negative%2520Perpetual%2520Funding%2520Days.png%3Falt%3Dmedia%26token%3D17a9edf0-311b-40a2-adb5-b4b4cb54c6b6&width=768&dpr=3&quality=100&sign=a0dc3fe4c8e020fed7650cb39d433811&sv=3)There has only been one quarter in the last 3 years where the average sum return was negative and this data was polluted by the *ETH *PoW arbitrage period which was a one-off event that dragged funding deeply negative.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FyXzxPMVWySleW6pDUZgV%252FCumulative%2520Rewards%2520by%2520Quarter.png%3Falt%3Dmedia%26token%3Dfba0fe62-4cac-49f1-a271-d4d54d63ed07&width=768&dpr=3&quality=100&sign=c2d6c01850b17b381d932efbd5de295b&sv=3)Q4 2024 as of October 2024
### **Mean-reversion**[](#mean-reversion)

Funding rates have displayed mean-reverting characteristics, which is to say they may dip negative but those rates do not persist and don't drift lower over time. Positive baseline funding on some of the biggest derivative exchanges, with over 50% of open interest (Binance & Bybit), help keep funding rates naturally positive.

Reversion to a positive mean can be seen in the longest consecutive days of either positive or negative funding rates. Negative funding rates revert quicker thanks to the dynamics described above, with the longest streak of consecutive days with negative funding lasting just 13 days.

The longest streak of positive funding days has been 176 days, set between late 2023 and early 2024 and charted below.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FfTHPvkhouhETggVAgNiN%252FConsecutive%2520negative%2520positive.png%3Falt%3Dmedia%26token%3D8211c078-0156-4394-88c0-7aab14bed778&width=768&dpr=3&quality=100&sign=1ccc1b00b9d2790890744787ac1599e1&sv=3)For a more detailed explanation on the distribution of funding rates as it relates to *USDe*, please read this Twitter [thread](https://twitter.com/leptokurtic_/status/1682781070121652224?s=20) from the Ethena Labs founder on the topic.

Last updated 1 year ago

Was this helpful?