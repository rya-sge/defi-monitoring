# Custodial Risk

> Source: https://docs.ethena.fi/protocol-overview/risks/custodial-risk

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/custodial-risk.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Risks](https://docs.ethena.fi/protocol-overview/risks)

# Custodial Risk

## Context[](#context)

Given that Ethena relies upon "Off-Exchange Settlement" provider solutions to hold protocol backing assets, there is a dependence upon their operational ability. This is the "Custodial Risk" we are referring to.

Counterparty risk is a prevalent issue throughout crypto and has never been more important than it is today. The custodians' business models are built on the safeguarding of assets, vs. the alternative of leaving backing assets sitting on a centralized exchange.

## Overview[](#overview)

There are three principal risks with using an Off-Exchange Settlement provider for custody:

1. **Accessibility and Availability. **Ethena’s ability to deposit, withdraw, and delegate to & from exchanges. Any of these abilities being unavailable or degraded would impede the trading workflows & availability of the **mint**/**redeem ***USDe *functionality.

  - It is important to note that this should NOT affect the value of the backing underpinning *USDe*.
2. **Performance of Operational Duties.** In the event of an exchange failure, the protocol is reliant upon cooperation and reasonable legal behaviour to facilitate the expedient transfer of any unrealized PnL at risk with an exchange. Ethena mitigates this risk by settling PnL with exchanges frequently to avoid large balances being owed to the protocol.

  - For example, Copper's Clearloop settles PnL between exchange partners and Ethena daily.
3. **Operational Failure of Custodian.** While the core team is not aware of any material operational failures or insolvencies for large-scale crypto custodians, this does remain a possibility. While assets are held in segregated accounts, insolvency of a custodian would pose operational issues for the creation and redemption of *USDe *as Ethena manages the transfer of assets to alternative providers.

  - Backing assets within these solutions are not owned by the custodian nor is the custodian or its creditors expected to have a legal claim on the assets. This is a result of OES providers either utilizing bankruptcy-remote trusts or MPC wallet solutions.

These three risks are mitigated by Ethena not exposing too much backing assets to a single OES provider and ensuring concentration risk is managed. It’s important to keep in mind that the system strives to use multiple OES providers with the same exchanges to mitigate both of the aforementioned risks.

## Example: Copper Clearloop[](#example-copper-clearloop)

Individual custodial providers also provide the following protection, using Copper's Clearloop as an example:

- Copper has never been hacked or lost users’ funds in contrast to the $7bn lost in DeFi.
- Copper users’ funds were wholly available within days of Coinflex’s (exchange) failure.
- Copper users’ funds are a part of a bankruptcy-remote trust, meaning in the event of Copper’s failure, users’ funds are not a part of the Copper estate.
- Exchanges post collateral with Copper ahead of time to ensure users’ PnL is settled each cycle. This enables Copper to ensure users receive their PnL even if an exchange refuses to settle.
- Ethena retains the ability to dispute erroneous exchange settlement requests.

For more information, please refer to Copper's one-pager on Clearloop:

[CopperClearloopOnePager.PDF](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FsDzrtEQJW9WaoJfha374%2FCopperClearloopOnePager.PDF?alt=media&token=c8d75a40-8aa1-4055-980a-2c4405c5faf4)PDF · 2MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FsDzrtEQJW9WaoJfha374%2FCopperClearloopOnePager.PDF?alt=media&token=c8d75a40-8aa1-4055-980a-2c4405c5faf4)

Last updated 1 year ago

Was this helpful?