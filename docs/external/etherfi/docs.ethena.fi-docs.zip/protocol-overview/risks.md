# Risks

> Source: https://docs.ethena.fi/protocol-overview/risks

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/risks.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Risks

Synthetic dollar vs fiat and RWA backed stablecoins

## Risks of *USDe* as Synthetic Dollar[](#risks-of-usde-as-synthetic-dollar)

Ethena is committed to transparency. It is crucial to highlight the risks associated with *USDe, *the actions taken to mitigate these risks, as well as plans to further manage and ameliorate these risks.

This section will discuss the following risks:

1. [Funding Risk](https://docs.ethena.fi/protocol-overview/risks/funding-risk)
2. [Liquidation Risk](https://docs.ethena.fi/protocol-overview/risks/liquidation-risk)
3. [Custodial Risk](https://docs.ethena.fi/protocol-overview/risks/custodial-risk)
4. [Exchange Failure Risk](https://docs.ethena.fi/protocol-overview/risks/exchange-failure-risk)
5. [Backing Assets Risk](https://docs.ethena.fi/protocol-overview/risks/backing-assets-risk)
6. [Stablecoin-Related Risk](https://app.gitbook.com/o/uL0A7ZhBdOBWE4R46usw/s/sBsPyff5ft3inFy9jyjt/~/changes/194/solution-overview/risks/stablecoin-related-risks)
7. [Margin Collateral Risk](https://app.gitbook.com/o/uL0A7ZhBdOBWE4R46usw/s/sBsPyff5ft3inFy9jyjt/~/changes/194/solution-overview/risks/draft-margin-collateral-risks)

We would greatly appreciate any feedback or information you would like to see to help the protocol be as transparent as possible. If you believe any risk has not been adequately surfaced please reach out in Discord and notify the contributors.

Last updated 6 months ago

Was this helpful?