# Governance

> Source: https://docs.ethena.fi/protocol-overview/governance

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/governance.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Governance

Rather than a flat governance structure wherein every protocol-level decision is put to a vote for participation by all governance tokenholders, the vast majority of decisions (other than those which the committees deem outside the scope of their remit) are delegated to the relevant committees described in this section. Each committee will have a clearly defined and siloed role within the broader governance framework and ecosystem.

The primary role of $ENA governance tokenholders is initially to appoint committee members on a rotating basis; however, governance going forward will be a generally iterative process where all stakeholders will adapt and tweak the system on a collective basis to move towards an efficient system that enables an appropriate balance between efficient and informed decision-making and enabling stakeholders in the community to have adequate input where it makes sense.

### Why Govern by Committee?[](#why-govern-by-committee)

Due to the design of Ethena (e.g., the necessity for off-chain infrastructure), fully on-chain governance is not a practical or viable option at present. The Committee approach reflects prioritizing practicality while adding external checks and balances to that off-chain infrastructure and governance environment.

In this framework, $ENA governance tokenholders are able to delegate everyday decision-making with respect to key aspects of the ecosystem to sophisticated, expert-level stakeholders - most of whom provide advisory and similar services to other projects and protocols in the industry - while retaining transparency during the process. In addition, the vetting process is put in place to reduce the risk of future Committee members being appointed who are ill-equipped to understand, analyze, and implement these initiatives and decisions.

## Links[](#links)

[Forum](https://gov.ethenafoundation.com/)

[Snapshot Voting](https://snapshot.org/#/ethenagovernance.eth)

Last updated 2 months ago

Was this helpful?