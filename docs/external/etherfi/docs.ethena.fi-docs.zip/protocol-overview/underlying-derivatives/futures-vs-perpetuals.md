# Futures vs Perpetuals

> Source: https://docs.ethena.fi/protocol-overview/underlying-derivatives/futures-vs-perpetuals

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/underlying-derivatives/futures-vs-perpetuals.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Underlying Derivatives](https://docs.ethena.fi/protocol-overview/underlying-derivatives)

# Futures vs Perpetuals

Comparison of derivative contract types

### Futures Contract[](#futures-contract)

A Futures Contract is a derivative instrument and is an agreement to buy or sell a commodity, currency or other instrument at a predetermined price at a specified time in the future. They are either physically or cash settled.

Margin collateral is either be denominated in underlying cryptocurrencies, allowing traders to speculate on the future value of its products using only crypto collateral, or they can be denominated in *USDT*/*USDC*.

### Perpetual Contract[](#perpetual-contract)

In contrast to traditional futures, Perpetual Contracts have no expiry date and include a concept called "Funding". "Funding" incentivizes traders to keep the price of the Perpetual Contract relatively in line with the underlying asset index of which the contract is marked against.

If the Perpetual Contract trades at a higher price than the index, traders that have long positions need to make funding payments to the traders having short positions. This funding payment will make the product less attractive to the long-position holders and more attractive to the short-position holders. This dynamic attempts to drive the perpetual price to trade in line with the price of the index. If the Perpetual Contract trades at a price lower than the index, the short position holders will have to pay the long position holders.

Read more about "Funding": [Bitmex Guide](https://www.bitmex.com/app/perpetualContractsGuideExamples#Long-XBTUSD-Perpetual-Contract-Example), [Deribit Guide](https://insights.deribit.com/education/perpetual-swap-funding/)

### Differences between Futures & Perpetual Contracts[](#differences-between-futures-and-perpetual-contracts)

The core differences between Perpetual and Futures can be summarized as follows:

1. Perpetual contracts have no expiry or settlement.
2. The "Funding" mechanism is used to tether Perpetual contracts to their underlying spot index price. This is in contrast to a Futures contract which may trade at significantly different prices to their associated index until expiry where it is settled at a rate very similar to the index price.
3. Each Perpetual contract has its own details including:

  1. Index Price Source Components
  2. Funding Rate Mechanism

Last updated 1 year ago

Was this helpful?