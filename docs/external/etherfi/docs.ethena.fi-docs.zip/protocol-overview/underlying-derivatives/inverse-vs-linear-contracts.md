# Inverse vs Linear Contracts

> Source: https://docs.ethena.fi/protocol-overview/underlying-derivatives/inverse-vs-linear-contracts

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/underlying-derivatives/inverse-vs-linear-contracts.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Underlying Derivatives](https://docs.ethena.fi/protocol-overview/underlying-derivatives)

# Inverse vs Linear Contracts

### Inverse vs Linear Contracts[](#inverse-vs-linear-contracts)

A linear payout is the simplest to describe and is used for many swaps. The price of a linear contract is expressed as the price of the underlying against the base currency. ETHUSDT is a linear perpetual and is quoted in Tether, with margin and PNL calculations denominated in Tether.

An inverse contract is worth a fixed amount of the quote currency. In the case of the ETHUSD perpetual, each contract is worth $1 of Ethereum at any price. ETHUSD is an inverse contract because it is quoted as ETH/USD but the underlying is USD/ETH or 1 / (ETH/USD). It is quoted as an inverse to facilitate hedging US Dollar amounts while the spot market convention is to quote the number of US Dollars per Ethereum.

### Convexity Implications[](#convexity-implications)

Convexity (also known as Gamma) refers to the second derivative of a contract's value with respect to price, and in the case of inverse perpetual futures, it can differ from the relationship suggested by a linear move in price.

While the payoff for a linear contract is just the Contract Multiplier*(Entry Price-Exit Price), the payoff for an inverse contract is Contract Multiplier*(1/Entry Price - 1/Exit Price), introducing convexity.

**Example**

A trader goes long 50,000 contracts of ETHUSD at a price of 10,000. 

A few days later the price of the contract increases to 11,000.

The trader’s profit will be: 50,000 * 1 * (1/10,000 - 1/11,000) = 0.4545 ETH

If the price had in fact dropped to 9,000, the trader’s loss would have been: 50,000 * 1 * (1/10,000 - 1/9,000) = -0.5556 ETH. 

The loss is greater because of the inverse and non-linear nature of the contract. 

Conversely, if the trader was short then the trader’s profit would be greater if the price moved down than the loss if it moved up.

Last updated 2 years ago

Was this helpful?