# Basis Spread

> Source: https://docs.ethena.fi/protocol-overview/underlying-derivatives/basis-spread

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/underlying-derivatives/basis-spread.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Underlying Derivatives](https://docs.ethena.fi/protocol-overview/underlying-derivatives)

# Basis Spread

### What is a basis trade?[](#what-is-a-basis-trade)

A basis trade is a trade in which the trader simultaneously purchases (sells) an asset and sells (buys) the futures contract for that asset. Since spot and futures are traded separately, their prices are not guaranteed to be the same at all times. In fact, their prices often diverge and this differential is known as the "basis".

As the future approaches expiration, its price often trends towards the underlying spot price. At expiration, futures contracts require the trader long the contract to purchase the underlying asset at the contract’s predetermined price, guaranteeing that at the futures contract expiry. Therefore, as the futures expiration draws nearer, the basis should approach 0.

If for example, the futures contract is trading at a premium to the underlying spot price, a trader can short this future against the underlying and as the future converges to the spot price at expiration they will collect this difference in basis. Fixed expiry futures will provide a fixed interest rate on this basis trade.

**Example**

For instance, as of January 2025, the price for the **BTC/USD** spot was $103,337 whereas the price for the BTC March 28th expiry futures, has a price of $103,401. We define the basis  as being the difference between the spot price and the futures price.

The basis has a value of $103,401 - $103,337 = $64.

Last updated 1 year ago

Was this helpful?