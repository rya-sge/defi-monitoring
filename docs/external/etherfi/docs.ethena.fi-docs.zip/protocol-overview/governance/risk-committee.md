# Risk Committee

> Source: https://docs.ethena.fi/protocol-overview/governance/risk-committee

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/governance/risk-committee.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)
2. [Governance](https://docs.ethena.fi/protocol-overview/governance)

# Risk Committee

The Risk Committee’s mandate is to generally identify, evaluate, and manage risk within the ecosystem

### Members[](#members)

With regards to the Risk Committee, every 6 months, the terms for all 3 members of the committee will lapse, and their positions will be put up to governance via broad vote for either (i) confirmation for another term or (ii) to be filled by a replacement member.

For the current six month term, the Risk Committee members are as follows:​

- Blockworks Advisory
- LlamaRisk
- Kairos Research

ENA holders with more than 1,000 $ENA may nominate potential committee members in the governance forums. If the potential committee member accepts the nomination, the members of the Committee upon which a seat is being filled will conduct a confirmation vote after satisfying themselves regarding the suitability of the nominated candidate. A nominee advancing past the foregoing stages will then be subject to KYC/KYB screening by the Ethena Foundation, and if it passes those checks, will be included in the broader governance vote for the open Committee seats. The nominees that garner the most votes will be named to the relevant Committee and execute a Governance Committee Service Agreement with the Ethena Foundation, which outlines the rights, obligations, compensation, and other terms associated with serving on the relevant Committee. A template of the Governance Committee Service Agreement will be published for public reference.

Committees will hold regular meetings as determined by the members, with support from the Ethena Foundation.

### Committee Decisionmaking Procedure[](#committee-decisionmaking-procedure)

A member of a Committee wishing to make a specific change is required to propose the particular changes or decisions in the governance forums located at gov.ethenafoundation.com Following posting, a seven-day deliberation period begins, during which the members of the relevant Committee discuss the merits of the proposal. At the end of the deliberation period, a vote will be held amongst members of the Committee or their designated sub-committees.

If the proposal successfully passes, the Committee will instruct the relevant parties to implement the decision, subject to oversight by the Foundation. If the proposal is defeated, unless no Committee member other than the member who made the initial proposal votes in favor, Committee members who vote against the proposal are encouraged to provide a detailed response as to its rationale, and, if relevant, proposed amendments to the proposal it would suggest, to support the possibility of reaching consensus.

Committee members are required to recuse themselves from the decision-making process with respect to proposals in which they have a direct financial interest - namely, where a product or service offered by the member is implicated by a proposal whereby the member stands to gain financially.

### Ethena Labs Research[](#ethena-labs-research)

Ethena Labs Research sits on the committee as a nonvoting member (though it may make proposals) and will receive no compensation.

Last updated 6 months ago

Was this helpful?