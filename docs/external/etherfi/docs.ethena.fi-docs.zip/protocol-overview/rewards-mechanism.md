# Rewards Mechanism

> Source: https://docs.ethena.fi/protocol-overview/rewards-mechanism

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/rewards-mechanism.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Rewards Mechanism

How sUSDe accrues discretionary rewards

## Context[](#context)

Users are able to accrue fully discretionary incentive rewards by staking their *USDe *and receiving *sUSDe *atomicallyin return.

Once users stake their *USDe* for *sUSDe*, they begin to accrue rewards, to the extent provided, without any further action or cost. *USDe *that is staked is not rehypothecated in any way to generate returns.

## Overview[](#overview)

The amount of* sUSDe* a user receives is determined by how much *USDe* was transferred as well as when it was transferred. Ethena's *sUSDe *utilizes a reward-bearing "Token Vault" mechanism, the same as [Rocketpool's rETH](https://docs.rocketpool.net/guides/staking/overview.html#the-reth-token) or [Binance's WBETH](https://www.binance.com/en/wbeth).

The protocol does not rehypothecate, lend out, or otherwise utilize deposited *USDe *for any purpose. There is no need for any such action, as the *USDe *backing mechanic inherently creates value in the system.

This mechanism simply enables Ethena to provide rewards to ecosystem participants without users having to do any action to "earn" it. The *USDe *value of *sUSDe *grows on its own. When a user unstakes his or her *USDe*, the user receives an amount of *USDe* equal to the initial amount staked plus their share of rewards deposited in the staking contract as rewards while that user's *USDe* was staked, as reflected in the *USDe *value increase of *sUSDe*.

## Important Notes[](#important-notes)

- The amount of *sUSDe *you receive when you stake *USDe *is likely to be less in number, but valued at the equivalent amount of *USDe*. This is a result of the "Token Vault" mechanism and the ratio defined below in the worked example.
- The value of *USDe *will remain worth the market trading price of *USDe* while *sUSDe *will grow in *USDe* value as the protocol (via a subsidiary of the Ethena Foundation) deposits discretionary rewards in the staking contract.
- If the protocol were to suffer a loss due to funding or another reason, Ethena's Reserve Fund is intended to bear the cost, rather than the staking contract.

*sUSDe* can only accrue positive or flat rewards while staking *USDe; *periods of negative protocol revenue are not passed on to *sUSDe*. During such periods, no discretionary rewards will be provided.

## Calculation & Worked Example[](#calculation-and-worked-example)

*sUSDe*:*USDe* ratio = (total *sUSDe *supply) / (total *USDe *staked + total protocol revenue deposited in *USDe *terms)@c

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FhtSigIwZqCpJexJ47jEX%252FGroup%2520427320584.png%3Falt%3Dmedia%26token%3D75b3951a-72e7-4156-b4fb-95dbb4bc8d3b&width=768&dpr=3&quality=100&sign=276fecf9964a3407b206d6aff93916dc&sv=3)
## sUSDe Rewards Mechanism[](#susde-rewards-mechanism)

The Ethena Foundation, via a subsidiary, calculates APY weekly as part of internal accounting when distributing rewards to the [StakingRewardsDistributor contract](https://etherscan.io/address/0xf2fa332bd83149c66b09b45670bce64746c6b439#code).

To prevent lumpy distributions which people can arbitrage, and because its not currently feasible for Ethena to distribute more frequently than weekly, sUSDe rewards are distributed the week after the period to which they relate, in multiple smaller payments throughout the week. In that period, the USDe supply can increase or decrease, as can the % of USDe supply staked.

This can cause distortions between the APY published, and a number that's just based on the most recent 8 hourly payment to sUSDe, as seen on some data aggregator sites.

Ethena's APY is also annualized with weekly compounding reflecting the compounding interval users actually experience.

Last updated 2 months ago

Was this helpful?