# Peg Arbitrage Mechanism

> Source: https://docs.ethena.fi/protocol-overview/peg-arbitrage-mechanism

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/protocol-overview/peg-arbitrage-mechanism.md).CopyOn this page
1. [Protocol Overview](https://docs.ethena.fi/protocol-overview)

# Peg Arbitrage Mechanism

There is one presently available trade strategy available to users to profit from a price dislocation of *USDe *in external markets from what it is actually worth:

**Cross Market Arbitrage: **purchasing or selling USDe into the protocol mint & redeem contract when USDe price has diverged from $1.

## Trade Strategies[](#trade-strategies)

It's important to keep in mind:

- *USDe *is backed strictly by the protocol backing assets.
- *USDe *is able to be **minted **& **redeemed** on demand by authorized, whitelisted users. This means that at any time, approved users are able to ramp in & out.

  - about 0.50% of backing assets are typically held in stablecoin form and available in the Minting Smart Contract to enable on-demand redemptions. This balance is systematically replenished from the 4% of the backing assets of *USDe *held in stablecoins that are readily available from multiple custodians.
- The value & amount of *USDe's *underlying backing is generally unaffected by any dislocations or rapid movements of price across any Centralized/Decentralized Spot Market, AMM Protocols, etc., though fluctuations in those markets may cause temporary dislocations in the secondary market price of *USDe* as the market's "reference assets" for the target peg.
- The value of the reserve underpinning *USDe *is generally unaffected by the removal of liquidity in volatile markets.

### 1. Cross Market Arbitrage[](#id-1.-cross-market-arbitrage)

This strategy enables any user approved to mint/redeem to profit from the difference between the price/amount users' are able to **mint**/**redeem ***USDe *with Ethena & the value of *USDe *in an external market. An external market includes all centralized & decentralized spot markets such as "USDe/USDC" and AMM Protocols such as Uniswap or Curve. ![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Flh7-us.googleusercontent.com%2Fdocsz%2FAD_4nXe3W4OFZkxbBozA5Xid5BKDx_eBTrSwGn57b4eH1-tjHkZG784up8qbzDg-LDF57l1g5SAy3tFgnJFe7V9vfjhpKgB-Tv-hUBtwf_VEbkIr7xueN1AS1cjxoxVmei4DTaYjHCqOm6ynUCNOMI1WT8Xct2cE%3Fkey%3DLQPGPTylFgZCiOSN3cvgEA&width=300&dpr=3&quality=100&sign=4e3c18618b2403afd8216fe8975ec276&sv=3)

If *USDe *is worth **LESS **in an external market than from Ethena directly, a user could:

1. Buy 1x *USDe *at 0.95 from Curve using *USDT*.
2. Redeem 1x *USDe *at 1.00 from Ethena receiving *USDT*.
3. Profit.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Flh7-us.googleusercontent.com%2Fdocsz%2FAD_4nXfl7pvmWxGSYQbfq7OkGYBrAbd-IuQ29HUesLZZ2kwsd6nVjuXrk4f2Sr9mFuJpRCELN5vIM7zweqE1g510kaMCb0W1swWiw38vPp7tyu5_IOGQoMxrrpoosndZeAu1oKJKPNJ6e-R5vEjbCd7EuSImStOv%3Fkey%3DLQPGPTylFgZCiOSN3cvgEA&width=300&dpr=3&quality=100&sign=398e4f84afc4b2c97619ba74a22dbb09&sv=3)

If *USDe *is worth **MORE **in an external market than from Ethena Labs, a user could:

1. Mint *USDe *using *USDT *from Ethena.
2. Sell the *USDe *in the Curve pool for > 1.00 for *USDT*.
3. Profit.

Last updated 2 years ago

Was this helpful?