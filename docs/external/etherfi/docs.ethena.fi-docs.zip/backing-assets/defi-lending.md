# DeFi Lending

> Source: https://docs.ethena.fi/backing-assets/defi-lending

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/defi-lending.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# DeFi Lending

A portion of the protocol's stable backing assets may be supplied into overcollateralised, on-chain lending markets. In these markets, borrowers post collateral worth more than the value they borrow, and the protocol earns lending revenue from the interest paid by those borrowers.

Ethena supplies into established lending venues - such as markets on protocols including Morpho and Aave - where each market has clearly defined collateral, conservative loan-to-value parameters, and transparent, on-chain activity. Eligible markets, collateral types, and exposure limits are approved subject to governance and Risk Committee review.

[Link to Kamino/Jupiter analysis](https://gov.ethenafoundation.com/t/proposal-lending-usde-backing-assets-into-kamino-and-jupiter-on-solana/785)

DeFi lending extends the protocol's existing comfort with on-chain, transparent, overcollateralised exposure. The revenue it produces is driven by borrowing demand within DeFi, which adds a further source of return that does not depend on perpetual funding rates.

Last updated 3 months ago

Was this helpful?