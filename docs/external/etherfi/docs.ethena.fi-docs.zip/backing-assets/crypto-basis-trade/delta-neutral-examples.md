# Delta-Neutral Examples

> Source: https://docs.ethena.fi/backing-assets/crypto-basis-trade/delta-neutral-examples

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/crypto-basis-trade/delta-neutral-examples.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)
2. [Crypto Basis Trade](https://docs.ethena.fi/backing-assets/crypto-basis-trade)

# Delta-Neutral Examples

## Context[](#context)

*Based on Arthur Hayes' example in his article: *[*Dust on Crust*](https://blog.bitmex.com/dust-on-crust/)

*Here, we have used an inverse perpetual to explain the different payoff scenarios of a delta-neutral strategy. Ethena will utilize both inverse and linear perpetuals. The payoff outcomes on an inverse perpetual are more intricate and as a result, we focus on explaining those scenarios below.*

An Ethereum inverse perpetual which is worth $1 of Ethereum paid out in Ethereum has the following payoff function:

*$1 / Ethereum Price in USD*

If Ethereum is worth $1, then the Ethereum value of the perpetual is 1 *ETH*, $1 / $1.

If Ethereum is worth $0.5, then the Ethereum value of the perpetual is 2 *ETH*, $1 / $0.5.

If Ethereum is worth $2, then the Ethereum value of the perpetual is 0.5 *ETH*, $1 / $2.

---

## Worked Examples[](#worked-examples)

1 *USDe *= $1 of *ETH *+ Short 1 Ethereum / USD Inverse Perpetual

To create 1 *USDe*, Ethena needs to delegate 1 *ETH *as margin with a derivatives exchange (via "Off-Exchange Settlement" solution) and short 1 ETHUSD perpetual.

#### Rapid ETH Price Decrease[](#rapid-eth-price-decrease)

- Now the Ethereum price falls from $1 to $0.1.
- The value of ETHUSD in ETH = $1 / $0.1 = 10 *ETH*
- The PNL of ETHUSD Position = 10 *ETH *(current value) – 1 *ETH *(initial value) = +9 *ETH *
- We have 1 *ETH *delegated as margin with the exchange.
- Ethena's total equity balance with the exchange is 1 *ETH *(our initial margin) + 9 *ETH (*profit from the ETHUSD position), and the total balance is now 10 ETH.
- The Ethereum price is now $0.1, but the system has 10 *ETH*, and therefore the USD value of the total portfolio is **unchanged** at $1, $0.1 * 10 *ETH*.

#### Rapid ETH Price Increase[](#rapid-eth-price-increase)

- Now the Ethereum price rises from $1 to $100.
- The value of ETHUSD in *ETH *= $1 / $100 = 0.01 *ETH*
- The PNL of ETHUSD Position = 0.01 *ETH *(current value) – 1 *ETH *(initial value) = -0.99* ETH*
- Ethena's total equity balance with the exchange is 1 *ETH *(initial margin) – 0.99 *ETH *(loss from ETHUSD position), and total balance is now 0.01 *ETH*.
- The Ethereum price is now $100, but Ethena has 0.01 *ETH*, and therefore the USD value of the total portfolio is **unchanged** at $1, $100 * 0.01 *ETH*.

Delta-neutral strategies aim to ensure the portfolio value in synthetic USD terms is **unchanged** despite changes in value of the underlying collateral. In certain conditions and market environments this may not hold, as is described in more detail in the Risks section.

---

## Further Worked Examples[](#further-worked-examples)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FjdrjUccLOOaUzVm5mlTH%252FDelte%2520Neutral%2520Example%25201.png%3Falt%3Dmedia%26token%3Ded437f39-b1bb-489b-8908-449f083e2d12&width=768&dpr=3&quality=100&sign=f568c7ca05ebc4d79d48000f069ff7bf&sv=3)![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FIkEAaL0Vo4kqk9QLLmOl%252FDelte%2520Neutral%2520Example%25202.png%3Falt%3Dmedia%26token%3D299e6557-6135-4f18-8018-45c719be28f6&width=768&dpr=3&quality=100&sign=6b6acd7582a0c8da7912369e410d6967&sv=3)

Last updated 1 year ago

Was this helpful?