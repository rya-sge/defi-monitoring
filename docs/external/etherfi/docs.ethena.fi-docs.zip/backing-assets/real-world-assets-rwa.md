# Real World Assets (RWA)

> Source: https://docs.ethena.fi/backing-assets/real-world-assets-rwa

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/real-world-assets-rwa.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Real World Assets (RWA)

Real-world assets (RWAs) are tokenised representations of off-chain financial assets. They hold a relatively stable dollar value and generate yield without requiring a derivatives hedge, which makes them a natural component of the protocol's backing portfolio.

Ethena's RWA exposure has historically centred on tokenised short-duration government debt.

The protocol is extending this exposure into high-liquidity real-world assets beyond treasury bills - including tokenised, liquid fixed income and credit instruments selected for low volatility, relatively strong liquidity and settlement terms, and their ability to be exited at predictable values.

RWAs serve two purposes in the backing portfolio. They preserve a stable dollar value, contributing to the stability of USDe backing, and they generate rewards from off-chain markets whose returns are largely uncorrelated with crypto market cycles.

Eligible RWA products, issuers, and exposure limits are approved subject to governance and Risk Committee review, with particular attention to liquidity under stress, credit quality, and legal structure of the assets.

Last updated 3 months ago

Was this helpful?