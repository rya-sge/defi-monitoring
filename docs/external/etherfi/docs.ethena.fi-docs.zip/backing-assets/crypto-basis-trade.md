# Crypto Basis Trade

> Source: https://docs.ethena.fi/backing-assets/crypto-basis-trade

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/crypto-basis-trade.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Crypto Basis Trade

Volatile assets, such as spot crypto and tokenised commodities, are paired with a corresponding short derivatives position so that the combined position is delta-neutral and its dollar value remains relatively stable.

In this process, the protocol aims to collect the funding rate.

#### **Funding Rate**[](#delta-neutrality)

Historically due to the mismatch between demand & supply for exposure to digital assets, there has been a **positive funding rate & basis spread earned by participants who are short this delta exposure.**

For ETH perpetuals, while this earned funding rate is variable, in 2021 it returned 16%, in 2022 0.6%, in 2023 ~9%, and in 2024 returned ~13% APY on a open interest weighted basis.

When allocated to the crypto basis trade, the Ethena protocol earns this funding rate when the funding rate is positive.

#### **Delta Neutrality**[](#delta-neutrality-1)

USDederives its relative peg stability from executing automated and programmatic delta-neutral hedges with respect to the underlying backing assets.

Hedging the price change risk of the backing asset in the same size minimizes fluctuations in the backing asset price as the change in value of the backing assets asset is generally offset 1:1 by the change in value of the hedge.

Since the backing assets can be perfectly hedged (in most market conditions) with a short position of equivalent notional, USDe only requires 1:1 "collateralization" in the majority of market conditions.

See[ Delta Neutrality](https://docs.ethena.fi/backing-assets/crypto-basis-trade/delta-neutral-stability) for more details.

Last updated 2 months ago

Was this helpful?