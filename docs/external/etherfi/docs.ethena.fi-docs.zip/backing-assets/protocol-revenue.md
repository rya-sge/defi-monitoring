# Protocol Revenue

> Source: https://docs.ethena.fi/backing-assets/protocol-revenue

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/protocol-revenue.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Protocol Revenue

Ethena generates revenue from its backing assets. As the backing portfolio has diversified, so have the sources of that revenue, which now span several distinct and largely uncorrelated streams.

Protocol revenue is generated from:

- **Funding and basis spread. **The funding and basis earned on delta-neutral basis trades, in crypto markets and, increasingly, in non-crypto markets such as tokenised commodities. Historically, the mismatch between demand and supply for leveraged exposure has resulted in a positive funding and basis return over time.
- **Lending revenue.** The return earned on investments in overcollateralised loans of stable assets, supplied both into on-chain DeFi lending markets and to institutional counterparties.
- **Real-world asset yield.** The yield earned on tokenised real-world assets held as backing, including short-duration government debt and high-liquidity credit.
- **Liquid stablecoin rewards**. Rewards earned on liquid stablecoin holdings, depending on the asset and where it is held.

The central purpose of diversifying the backing portfolio is to diversify protocol revenue and risk. A model concentrated in a single strategy ties overall risk to a single set of market dynamics; spreading exposure across funding, lending, real-world assets, and stablecoin rewards reduces the likelihood of stress to the Ethena system resulting from revenue compression across all sources at the same time.

Each stream responds to different drivers, so weakness in one can be offset by strength in others, producing a revenue base and risk profile designed to be more resilient across market cycles.

Periods of negative protocol revenue are designed to be borne by the Reserve Fund. See the [Reserve Fund](https://docs.ethena.fi/protocol-overview/reserve-fund) section below.

Last updated 2 months ago

Was this helpful?