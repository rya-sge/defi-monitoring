# Liquid Stablecoins

> Source: https://docs.ethena.fi/backing-assets/liquid-stablecoins

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/liquid-stablecoins.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Liquid Stablecoins

The protocol holds a portion of its backing in liquid, fiat-referenced stablecoins - such as USDC, USDT, and USDtb - that already maintain a stable dollar value using fiat (and equivalent) reserves and therefore do not require a derivatives hedge.

Liquid stablecoins serve several functions in the backing portfolio. They support the protocol's ability to manage on-demand redemptions, allowing whitelisted counterparties to redeem USDe without the protocol needing to unwind hedged positions in order to source liquidity.

Liquid stablecoins also act as a safeguard during periods when perpetual funding rates and futures basis are suboptimal, allowing the protocol to reduce hedged exposure while preserving stable backing.

The allocation to liquid stablecoins is dynamic. It is increased or decreased in response to redemption patterns, market conditions, and the relative attractiveness of other backing strategies. Depending on where they are held, certain liquid stablecoins may earn rewards - for example, rewards available on USDC - which can contribute to overall protocol revenue.

Last updated 3 months ago

Was this helpful?