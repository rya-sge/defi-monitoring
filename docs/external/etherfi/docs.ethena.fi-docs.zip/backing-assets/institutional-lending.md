# Institutional Lending

> Source: https://docs.ethena.fi/backing-assets/institutional-lending

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/institutional-lending.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Institutional Lending

The protocol also extends overcollateralised loans of stable assets to institutional counterparties through direct lending agreements and triparty collateralised arrangements.

Ethena already lends stablecoins from the backing of USDe into DeFi markets such as Aave and Morpho. This represents a natural extension of that existing activity - overcollateralised lending with only high-quality, immediately liquid collateral (BTC/ETH) and facing institutional counterparties that meet strict eligibility criteria.

The CeFi lending market has undergone a structural reset since the credit crisis of 2022–23, where failures of undercollateralised lenders like Genesis, Celsius, and BlockFi eroded trust across the industry. Since then, the market has recovered on a fundamentally different footing: overcollateralised, transparent, and with rigorous counterparty standards.

Crypto-collateralised lending reached an all-time high in Q4 2025, with the composition of that leverage structurally healthier than during the previous cycle. Overcollateralised credit and transparent reporting have become the norm.

Ethena’s direct lending activity will sit firmly within this reformed landscape - facing only institutional counterparties, overcollateralised with high-quality liquid collateral, and subject to the independent oversight of the Risk Committee.

Under these arrangements, an institutional borrower receives a loan of stable assets and posts collateral worth more than the value borrowed. The collateral is held under arrangements designed to protect the protocol's claim - including the use of qualified custodians and triparty structures in which an independent agent holds and administers the collateral. Ethena is establishing lending relationships with institutional-grade counterparties subject to the relevant agreements and Risk Committee approval.

Institutional lending captures borrowing demand from a set of counterparties whose activity is largely independent of crypto-native funding cycles, further diversifying the protocol's revenue base. Counterparty eligibility, collateral requirements, overcollateralisation ratios, and aggregate exposure limits are set subject to governance and Risk Committee review.

[Link to Maple & Anchorage Digital analysis](https://gov.ethenafoundation.com/t/proposal-maple-and-anchorage-digital-as-direct-lending-partners/756)

Last updated 3 months ago

Was this helpful?