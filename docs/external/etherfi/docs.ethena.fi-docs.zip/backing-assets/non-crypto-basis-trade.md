# Non-Crypto Basis Trade

> Source: https://docs.ethena.fi/backing-assets/non-crypto-basis-trade

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/backing-assets/non-crypto-basis-trade.md).CopyOn this page
1. [Backing Assets](https://docs.ethena.fi/backing-assets)

# Non-Crypto Basis Trade

The basis trade is the strategy at the core of USDe: hold a spot asset, open a corresponding short futures position, and earn the funding and basis spread between the two while remaining delta-neutral. The same mechanic does not need to be limited to crypto.

Ethena is extending the basis trade into non-crypto markets where a liquid spot or tokenised asset can be paired with a liquid, well-functioning perpetual or deliverable futures market. One such market is tokenised gold: the protocol would hold tokenised gold - such as PAXG and XAUT - as a spot backing asset and open corresponding short positions in gold perpetual futures, producing a delta-neutral position whose dollar value remains relatively stable while capturing the funding and basis spread of the gold derivatives market.

Non-crypto basis trades broaden the protocol's revenue base in two ways.

First, the funding and basis available in markets such as gold has historically been positive and is driven by demand for leveraged exposure to the underlying commodity, which is structurally distinct from demand for leveraged crypto exposure.

Second, the volatility profile of the underlying asset is generally lower than that of crypto, which can support more stable hedging. Because the drivers of funding in these markets show low correlation to crypto funding, adding them to the backing portfolio diversifies protocol revenue across market cycles.

When operating in tokenised commodity markets, the protocol distinguishes carefully between instrument types. A perpetual contract referencing the spot price of a commodity is treated differently from a cash-settled synthetic contract, and the hedge is constructed against the instrument whose price behaviour corresponds to the spot asset actually held as backing.

Eligible non-crypto basis markets, instruments, and venues are approved subject to governance and Risk Committee review, applying the same standards of spot and derivatives liquidity used for crypto markets.

[Link to Tokenized Gold analysis](https://gov.ethenafoundation.com/t/proposal-expand-usde-backing-with-tokenized-gold-paxg-xaut/779)

Last updated 3 months ago

Was this helpful?