# How to Buy USDe

> Source: https://docs.ethena.fi/video-guides

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/video-guides/how-to-buy-usde.md).CopyOn this page
1. [Video Guides](https://docs.ethena.fi/video-guides)

# How to Buy USDe

USDe can be acquired on the secondary market or minted directly through the Ethena protocol.

[Using the UI](https://app.ethena.fi/swap), non-whitelisted users are able to exchange stablecoins for USDe by accessing external liquidity pools available:

1. The user requests to ***buy*** USDe via the dApp interface by selecting a stablecoin asset to exchange for USDe.
2. This transaction is routed using MEV protection through CowSwap to various onchain liquidity pools in exchange for USDe.
3. This abstracts away the complexity for all users allowing stablecoins as an input asset, and causes small imbalances in the onchain AMM pools which triggers an opportunity for market makers to proceed with the mint workflow outlined below.

Users may also exchange fiat for USDe using our partners [Alchemy Pay](https://ramp.alchemypay.org/?appId=VmpUX9X3MIL36oJ3) and [Transak](https://global.transak.com/?apiKey=39b3a98c-bf84-4f37-a523-472e9777fdb7&cryptoCurrencyCode=USDE).

Minting USDe is the process of sending backing assets to the Ethena protocol in exchange for USDe. Redeeming USDe is the process of burning USDe in exchange for backing assets. Whitelisted users can ***mint*** or ***redeem*** USDe via our API or through the "Mint" tab in the app, which is only visible to whitelisted users.

Last updated 1 year ago

Was this helpful?