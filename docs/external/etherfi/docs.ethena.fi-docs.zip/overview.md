# Ethena Overview

> Source: https://docs.ethena.fi/overview

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/overview/ethena-overview.md).CopyOn this page
1. [Overview](https://docs.ethena.fi/overview)

# Ethena Overview

//Enabling Internet Money

Ethena's USDe is **not **the same as a fiat stablecoin like USDC or USDT. USDe is a synthetic dollar, backed with crypto assets and corresponding short futures positions.

This means that the risks implicated by interacting with USDe are inherently different.

Please refer to our extensive [Risk](https://docs.ethena.fi/protocol-overview/risks)[s](https://docs.ethena.fi/protocol-overview/risks) section for more information.

## Overview[](#overview)

Ethena is a synthetic dollar protocol built on crypto rails, issuing USDe - a dollar-denominated digital asset - alongside sUSDe, the protocol's autonomously and permissionlessly created globally accessible savings asset.

USDe is designed around four principles that together define a superior product for holders of digital dollars:

1. **Capital efficiency**
2. **Industry leading ecosystem rewards**
3. **Resilience across market cycles**
4. **Infrastructure to capture every available source of dollar returns within reserve assets**

#### **Capital efficiency **[](#capital-efficiency)

Each unit of USDe is backed by assets held by the protocol. Virtually every dollar of backing remains productive, generating revenue through the strategies described below, and USDe scales without the onerous collateral buffers required by other decentralised stablecoin designs. Capital efficiency at the protocol level translates directly into rewards available to the ecosystem.

#### **Industry-leading ecosystem rewards**[](#industry-leading-ecosystem-rewards)

Revenue earned on the backing of USDe is utilized in promotional and incentive programs, including sUSDe (which is maintained by a subsidiary of the Ethena Foundation)and certain partner reward programs on partner exchanges, platforms, or protocols. That revenue is generated from a diversified set of strategies, including:

- Funding rates on delta-neutral basis trades in crypto perpetual and futures markets;
- Funding rates on delta-neutral basis trades in non-crypto markets;
- Lending revenue from overcollateralised on-chain DeFi lending markets;
- Lending revenue from overcollateralised loans to institutional counterparties;
- Rewards on tokenised real-world assets, including short-duration government debt and high-liquidity credit;
- Rewards on liquid stablecoin holdings where applicable.

#### **Resilience across market cycles**[](#resilience-across-market-cycles)

Each strategy responds to a different driver. Crypto funding rates reflect leverage demand in digital asset markets. Non-crypto funding rates reflect demand for leverage in commodities and other markets. Lending revenue reflects borrowing demand in DeFi and at institutional venues. Real-world asset returns reflect rates in traditional fixed income.

These drivers are largely uncorrelated, which means weakness in any one source can be offset by strength in others. That diversification across revenue sources mitigates risk across the entire protocol.

The backing portfolio is also dynamic. The protocol can shift weight between strategies as conditions evolve, subject to governance and Risk Committee review. In periods when crypto funding rates compress, the portfolio can lean into lending, real-world assets, and non-crypto basis to mitigate associated risks while being revenue positive. When leverage demand in crypto markets accelerates and perpetual funding rises, the portfolio can shift weight back towards crypto basis trades to capture that opportunity at scale - the only protocol in the industry that has the infrastructure set up to do so.

#### Positioned to capture every available source of dollar returns[](#positioned-to-capture-every-available-source-of-dollar-returns)

Accessing this full set of strategies requires infrastructure that few protocols possess: off-exchange custody with multiple regulated providers, direct relationships with the deepest crypto and commodity derivatives venues, onboarded counterparties for institutional lending, integrations with leading tokenised real-world asset issuers, and exposure into curated DeFi lending markets - all governed by a Risk Committee setting consistent exposure limits across categories.

Ethena has built this infrastructure since launch and is operating it at the scale required to make each category of backing materially additive to USDe’s resilience and profile.

Website: [https://ethena.fi/](https://ethena.fi/)

Telegram: [https://t.me/ethena_labs](https://t.me/ethena_labs)

Discord: [https://discord.com/invite/cepXWnXHaa](https://discord.com/invite/cepXWnXHaa)

X: [https://x.com/ethena](https://x.com/ethena)

LinkedIn: [https://www.linkedin.com/company/ethena-labs/](https://www.linkedin.com/company/ethena-labs/)

The acquisition of sUSDe is not offered to persons with their habitual residence or registered office in the European Union or the European Economic Area.

## Quick Links[](#quick-links)

[![Logo](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fwww.notion.so%2Ffront-static%2Flogo-ios.png&width=20&dpr=3&quality=100&sign=e6712e85a03aaaf40a4c77fd8e7699ef&sv=3)Ethena FAQs  | Notionethena on Notion](https://www.notion.so/ethena/Ethena-FAQs-3ccc1437e13343f8b74c0d005e4f5128?pvs=4)[How to Buy USDe](https://docs.ethena.fi/video-guides/how-to-buy-usde)Users are currently able to:

- **Permissionless Acquire** *USDe. *Access external AMM pools to acquire or dispose of *USDe *with assets such as USDT or USDC.
- **Direct Mint ***USDe*. Transfer accepted reserve assets and receive *USDe, subject to clearing KYC/KYB checks exclusively for approved market making counterparties*. See Supplemental USDe Terms and Conditions.
- **Direct Redeem ***USDe*. Burn *USDe *& receive backing assets*, subject to clearing KYC/KYB checks exclusively for approved market making counterparties*. See Supplemental USDe Terms and Conditions.
- **Stake & Unstake** *USDe*. Receive rewards from protocol revenue. *Available exclusively for users in permitted jurisdictions.*

Last updated 1 month ago

Was this helpful?