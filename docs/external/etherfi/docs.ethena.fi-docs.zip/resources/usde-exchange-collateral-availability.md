# USDe Exchange Collateral Availability

> Source: https://docs.ethena.fi/resources/usde-exchange-collateral-availability

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/usde-exchange-collateral-availability.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# USDe Exchange Collateral Availability

This page details where *USDe *is both or individually able to be used as derivatives margin collateral with exchange partners and eligible for rewards as part of partners' promotional programs.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FwjNwZ17KrZOsOn5p8BYH%252Ftg_image_3227177078.png%3Falt%3Dmedia%26token%3Dda78763f-a110-407d-a0dc-b601748d6b41&width=768&dpr=3&quality=100&sign=bb1c7821b5ccee1b1c67cddaa422d59a&sv=3)
- [Binance Collateral Details](https://www.binance.com/en/futures/trading-rules/perpetual/portfolio-margin/tiered-collateral-ratio)
- [Bybit Collateral Details](https://www.bybit.com/en/announcement-info/fullstock-leverage-uta/)
- [Deribit Collateral Details](https://www.deribit.com/account/USDE/portfolio-margin)
- [MEXC Collateral Details](https://www.mexc.com/futures/information/multi_asset)

Last updated 4 months ago

Was this helpful?