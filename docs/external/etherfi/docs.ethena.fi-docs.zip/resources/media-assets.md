# Media Assets

> Source: https://docs.ethena.fi/resources/media-assets

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/media-assets.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Media Assets

### Logos[](#logos)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252F8BsIiCc6KuAZFVtYQR6E%252Fethena-dark.png%3Falt%3Dmedia%26token%3D090d0dfe-a010-4d47-8714-84f531fcd7b7&width=300&dpr=3&quality=100&sign=9386a3c758eda2a17cddfa49ea6ca7ee&sv=3)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FFRPe2pJGg4mbroiByPba%252Fethena-light.png%3Falt%3Dmedia%26token%3D7f53101f-9915-485a-ad28-f1fba032f270&width=300&dpr=3&quality=100&sign=a3fcda20ce685ebabfa67c42402ab092&sv=3)

A more extensive collection of assets in Figma can be viewed [here](https://www.figma.com/file/OYn3YOnDrt77qNLSGDuVkH/Ethena-Media-Assets?type=design&node-id=733%3A1794&mode=design&t=D3VpsKDeYJb8oT4G-1).

### Media Enquiries[](#media-enquiries)

Please contact nate.johnson@augustco.com for any PR related queries.

Last updated 1 year ago

Was this helpful?