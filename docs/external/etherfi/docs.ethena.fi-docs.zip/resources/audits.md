# Audits

> Source: https://docs.ethena.fi/resources/audits

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/audits.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Audits

Security is the most important focus

At Ethena, the integrity of our smart contracts is paramount. We maintain this by conducting comprehensive audits, which help identify potential vulnerabilities, logical errors, or inefficiencies. These rigorous audits, carried out by industry experts, fortify our security and seek to increase trust in the platform.

### Approach to Audits[](#approach-to-audits)

Ethena has undertaken a multi-phased audit program to ensure the highest level of security on the procotol.

**Phase 1:** conducted initial audit with Zellic on the v1 of the protocol where no critical or high level vulnerabilities were found.

**Phase 2**: architecture design review and economic risk factor analysis with [Spearbit](https://spearbit.com/)'s [Kurt Barry](https://twitter.com/Kurt_M_Barry) former Lead Engineer at MakerDAO

**Phase 3:** phased audit with industry leading firms:

-[Quantstamp](https://quantstamp.com/)
-[Spearbit](https://spearbit.com/) & [Cantina](https://cantina.xyz/welcome)

**Phase 4:** independent audit with [Pashov](https://twitter.com/pashovkrum) with individual experience of over 50 audits

**Phase 5:** public audit with [Code4rena](https://code4rena.com/)

**Phase 6:** economic and financial risk audit by [Chaos Labs](https://chaoslabs.xyz/)

**Phase 7:** upcoming public bug bounty program with [Immunefi](https://immunefi.com/)

### Reports[](#reports)

#### Zellic Audit on v1 of contracts[](#zellic-audit-on-v1-of-contracts)

Our initial audit on the first version of the contracts was performed by [![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fuploads-ssl.webflow.com%2F630c186854997f2e77e0316b%2F630c1995f3891d0f63cbf7f2_favicon.svg&width=300&dpr=3&quality=100&sign=d967dbc1652e0a67e48be641d5b85749&sv=3)Zellic](http://zellic.io/) and was a success in that no **critical, or high** vulnerabilities were identified. The small and medium-level feedback and optimisations were reviewed and patched during the audit cycle.

[Ethena x Zellic - Audit Report](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FGZbd1DrrG3YmnTlJnTHa%2FEthena%20-%20Zellic%20Audit%20Report%20Draft.pdf?alt=media&token=2e65890c-6724-49b7-97f4-6d2223ba086e)PDF · 395KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FGZbd1DrrG3YmnTlJnTHa%2FEthena%20-%20Zellic%20Audit%20Report%20Draft.pdf?alt=media&token=2e65890c-6724-49b7-97f4-6d2223ba086e)
#### Quantstamp Audit on v1 of contracts[](#quantstamp-audit-on-v1-of-contracts)

Attached is the audit report by Quantstamp completed on 18 Oct 2023. No critical or high level issues were identified.

[Ethena x Quantstamp - Audit Report](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2F17Ucep7IYMBZ6mAHGLyw%2FEthena%20Final%20Report%20(1).pdf?alt=media&token=51a6a101-516e-4984-8360-14daf860a961)PDF · 887KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2F17Ucep7IYMBZ6mAHGLyw%2FEthena%20Final%20Report%20(1).pdf?alt=media&token=51a6a101-516e-4984-8360-14daf860a961)
#### Spearbit Audit on v1 of contracts[](#spearbit-audit-on-v1-of-contracts)

Attached is the audit report by Speabit completed on 18 Oct 2023. No critical or high level issues were identified.

[Spearbit x Ethena - Audit Report](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FsX7xO54StGnS6RlZM0Qa%2FSpearbit%20_Ethena_v2_Final_report-ethena__1_.pdf?alt=media&token=d0968065-7e4d-4661-b53f-a1d5181c30bd)PDF · 515KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FsX7xO54StGnS6RlZM0Qa%2FSpearbit%20_Ethena_v2_Final_report-ethena__1_.pdf?alt=media&token=d0968065-7e4d-4661-b53f-a1d5181c30bd)
#### Independent Audit by Pashov on v1 of contracts[](#independent-audit-by-pashov-on-v1-of-contracts)

Attached is the audit report by Pashov completed on 22 Oct 2023. No critical or high level issues were identified.

[Ethena x Pashov - Audit Report](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FzUZDAQ77jrhUOIMqFka9%2FEthena-security-review%20(1).pdf?alt=media&token=0358ec8b-36fe-4166-a159-2c782a9f8d40)PDF · 217KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FzUZDAQ77jrhUOIMqFka9%2FEthena-security-review%20(1).pdf?alt=media&token=0358ec8b-36fe-4166-a159-2c782a9f8d40)
#### Public Code4rena Audit on v1 of contracts[](#public-code4rena-audit-on-v1-of-contracts)

Attached is the audit report by Code4rena completed on 13 Nov 2023. No critical or high level issues were identified.

[![Logo](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fcode4rena.com%2Ffavicon.ico&width=20&dpr=3&quality=100&sign=6bea2793f947e517e935ca5b72869e97&sv=3)Ethena Labs Audit | Code4renaCode4rena | Keeping high severity bugs out of production](https://code4rena.com/contests/2023-10-ethena-labs#top)
#### Independent Audit by Pashov on ENA and LP staking contracts[](#independent-audit-by-pashov-on-ena-and-lp-staking-contracts)

Attached is the audit report by Pashov completed on December 22nd 2023.

[Ethena-security-review (1).pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FBCV8xxvUneCO2WlUk2KS%2FEthena-security-review%20(1).pdf?alt=media&token=c552507e-b245-43b7-8cc6-cd51a6a92005)PDF · 438KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FBCV8xxvUneCO2WlUk2KS%2FEthena-security-review%20(1).pdf?alt=media&token=c552507e-b245-43b7-8cc6-cd51a6a92005)
#### Independent Audit by Pashov on V2 of contracts[](#independent-audit-by-pashov-on-v2-of-contracts)

Attached is the audit report by Pashov completed on May 23th 2024.

[v2-audit.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FJHbdthPqKCPoZFzrpryW%2Fv2-audit.pdf?alt=media&token=68bbdbae-4fcf-4e90-ad20-8c4d6a5a29a0)PDF · 676KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FJHbdthPqKCPoZFzrpryW%2Fv2-audit.pdf?alt=media&token=68bbdbae-4fcf-4e90-ad20-8c4d6a5a29a0)
#### Economics Audit and Risk Analysis by Chaos Labs on System Design[](#economics-audit-and-risk-analysis-by-chaos-labs-on-system-design)

[Chaos Labs - Ethena LST Market Risk Analysis](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FS8e4wljMcMDkw6fMcnby%2FChaos%20Labs%20-%20Ethena%20LST%20Market%20Risk%20Analysis%20(1).pdf?alt=media&token=071b4952-5995-4805-8904-2e617176396e)PDF · 2MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FS8e4wljMcMDkw6fMcnby%2FChaos%20Labs%20-%20Ethena%20LST%20Market%20Risk%20Analysis%20(1).pdf?alt=media&token=071b4952-5995-4805-8904-2e617176396e)[Chaos Labs - Ethena Perpetual Assessment Report Final.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FXx0DNbv33KWqybLS4HvU%2FChaos%20Labs%20-%20Ethena%20Perpetual%20Assessment%20Report%20Final.pdf?alt=media&token=0d167789-ee8b-4135-9ebd-d5e07033aa48)PDF · 5MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FXx0DNbv33KWqybLS4HvU%2FChaos%20Labs%20-%20Ethena%20Perpetual%20Assessment%20Report%20Final.pdf?alt=media&token=0d167789-ee8b-4135-9ebd-d5e07033aa48)[Chaos Labs - USDe On Chain Liquidity Assessment](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FxB8Qp1VgHy3GN2aJ57JO%2FChaos_Labs___USDe_On_chain_Liquidity_Assessment.pdf?alt=media&token=636dddfd-9861-4378-9f1e-d59c85bf2aca)PDF · 2MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FxB8Qp1VgHy3GN2aJ57JO%2FChaos_Labs___USDe_On_chain_Liquidity_Assessment.pdf?alt=media&token=636dddfd-9861-4378-9f1e-d59c85bf2aca)
#### Independent Audit by Pashov on Staked ENA (sENA)[](#independent-audit-by-pashov-on-staked-ena-sena)

Attached is the audit report by Pashov completed on 2 Sept 2024. No critical or high level issues were identified.

[Ethena x Pashov - SENA Audit Report.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FtqsJW7hPQMXv80sibsUK%2FEthena%20x%20Pashov%20-%20SENA%20Audit%20Report.pdf?alt=media&token=9b05cbba-cd3f-4252-9940-ba35b5408b9c)PDF · 936KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FtqsJW7hPQMXv80sibsUK%2FEthena%20x%20Pashov%20-%20SENA%20Audit%20Report.pdf?alt=media&token=9b05cbba-cd3f-4252-9940-ba35b5408b9c)
#### Quantstamp Audit on USDTB[](#quantstamp-audit-on-usdtb)

Attached is the audit report by Quantstamp completed on 25 Oct 2024. No critical or high level issues were identified.

[Ethena x Quantstamp - USTB.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FuyJ6FDS2CVacoHv303Cw%2FEthena%20x%20Quantstamp%20-%20USTB.pdf?alt=media&token=df9b8f23-54bc-4879-8016-096b966124cc)PDF · 2MBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2FuyJ6FDS2CVacoHv303Cw%2FEthena%20x%20Quantstamp%20-%20USTB.pdf?alt=media&token=df9b8f23-54bc-4879-8016-096b966124cc)
#### Cyfrin Audit on USDTB[](#cyfrin-audit-on-usdtb)

Attached is the audit report by Cyfrin completed on 31 Oct 2024. No critical or high level issues were identified.

[Ethena x Cyfrin - USTB.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fd7jvu5NZ9eh8thYYRBmP%2FEthena%20x%20Cyfrin%20-%20USTB.pdf?alt=media&token=9d693945-8baf-4373-bb4c-12cdee038db2)PDF · 201KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fd7jvu5NZ9eh8thYYRBmP%2FEthena%20x%20Cyfrin%20-%20USTB.pdf?alt=media&token=9d693945-8baf-4373-bb4c-12cdee038db2)
#### Independent Audit by Pashov on USDTB[](#independent-audit-by-pashov-on-usdtb)

Attached is the audit report by Pashov completed on 20 Oct 2024. No critical or high level issues were identified.

[Ethena x Pashov - USTB.pdf](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fvjn1dqCWVE3YWhLFTFFU%2FEthena%20x%20Pashov%20-%20USTB.pdf?alt=media&token=b0e93bf7-e95d-44df-8c25-270e21ec2582)PDF · 994KBDownload[Open](https://596495599-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FsBsPyff5ft3inFy9jyjt%2Fuploads%2Fvjn1dqCWVE3YWhLFTFFU%2FEthena%20x%20Pashov%20-%20USTB.pdf?alt=media&token=b0e93bf7-e95d-44df-8c25-270e21ec2582)Last updated 1 year ago

Was this helpful?