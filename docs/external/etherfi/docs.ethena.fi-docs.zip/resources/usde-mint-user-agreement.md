# USDe Mint User Agreement

> Source: https://docs.ethena.fi/resources/usde-mint-user-agreement

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/usde-mint-user-agreement.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# USDe Mint User Agreement

Last Updated: August 2025

This USDe Mint User Agreement (this “Agreement”) is a contract between you (“you” or a “ Mint User”) and Ethena BVI Limited ("referred to as the “Company,” and  “Ethena BVI”, “we,” or “us”). This Agreement applies to your use of Ethena BVI--related products and services (the “Services”) on the Company platform (the “Platform” or “Company”). The USDe Terms apply to your USDe and your status as a Mint User, as applicable, as defined in the USDe Terms.  From and after the date set forth above, this Agreement shall govern your use of any Company products or Services.

For the avoidance of doubt, your access to the Services is contingent on your status as a Mint User, as defined herein.

By registering as a Mint User or using any of the Services, you agree that you have read, understood and accept all of the terms and conditions contained in this Agreement as well as the Privacy Policy, Cookie Policy, and other policies, and you acknowledge and agree that you will be bound by these agreements and policies.

Note that this Agreement uses the term “Digital Currency” to refer to USDe or any other digital currencies, cryptocurrencies, virtual currencies, or digital assets. For the avoidance of doubt, where used herein, the term “funds” includes Digital Currency.

Please note that Section 20 contains an arbitration clause and collective or class action waiver.  By agreeing to this Agreement, you agree to resolve all disputes, except as otherwise set forth in Section 20, through binding individual arbitration, which means that you waive any right to have the dispute decided by a judge or jury, and you waive any right to participate in collective action, whether that be a class action, class arbitration, or representative action.

Section 21 of this Agreement governs how this Agreement may be changed over time; the date of the last update is set forth at the top of this Agreement.

**1. Eligibility; Limitations; Registration Process; Identity Verification**

Eligibility; Limitations

The Platform and the Services are currently only available to users located in supported jurisdictions. In registering to use the Company Services as a Mint User on behalf of an entity, you represent and warrant that (i) such legal entity is duly organized and validly existing under the applicable laws of the jurisdiction of its organization; (ii) you are duly authorized by such legal entity to act on its behalf, and (iii) such organization (and any affiliate entity) must not have been previously suspended or removed from the Services or any other service or product offered by the Company or its affiliate entities.

Use of certain Services may have further eligibility requirements that will need to be verified prior to you using such Services or from time to time in order to continue your use of the Services and may be subject to additional terms and conditions.

By using your status as a Mint User and the Services, you further represent and warrant that:

- you are at least 18 years old and are not a Restricted Person, nor are you resident of a Restricted Territory (each as defined in Section 27 below).
- you will not be using your status as a Mint User and Services for any illegal activity, including, but not limited to, illegal gambling, money laundering, fraud, blackmail, extortion, ransoming data, terrorism financing, other violent activities or any prohibited market practices, including, but not limited to, those listed in the USDe Terms and Conditions.

You also understand that there are additional representations and warranties made by you elsewhere in (or by reference in) this Agreement and that any misrepresentation by you is a violation of this Agreement.

Users in the United States are not eligible to become a Mint User. This restriction may be revisited from time to time taking into account relevant changes in law.

When you register as a Mint User, you will be required to designate an administrator for your registration and provide a wallet address to be whitelisted. The Company may, in its discretion, enable functionality utilizing your status as a Mint User and some or all of the Services to other persons at your firm (e.g. your employees) (such persons, “Additional Users”).  Such access is subject to the Company’s review and approval, and such Additional Users’ agreement to all of the terms hereof. To the extent that you choose to have Additional Users have access and control over the Mint User profile and relationship, you will have to designate those Additional Users and manage their access to your Mint User whitelisted wallets. By you requesting such access, you and all Additional Users automatically agree to this Agreement.

If the Company determines that you or any of your Additional Users have violated this Agreement, including, but not limited to, transacting with Blocked Addresses (as defined in the USDe Terms and Conditions) or engaging in Restricted Activities or Prohibited Transactions then the Company may be forced to terminate your status as a Mint User.

Notwithstanding the foregoing, the Company may determine not to make the Services, in whole or in part, available in every market, either in its sole discretion or due to legal or regulatory requirements, depending on your location. We may also, without liability to you or any third party, refuse to let you register as a Mint User in the Company’s sole discretion.

Registration Process; Identity Verification

When registering as a Mint User, you must provide current, complete, and accurate information for all required elements on the registration page or via any third-party service providers (e.g., KYC/KYB information collection and screening providers), including your full legal name and the legal name of your organization. You also agree to provide us, when registering as a Mint User and on an ongoing basis, any additional information we request for the purposes of identity verification and the detection of money laundering, terrorist financing, fraud, or any other financial crime. You permit us to keep a record of such information and authorize us to make the inquiries, whether directly or through third parties, that we consider necessary or desirable to verify your identity or protect you and/or us against fraud or other financial crime, and to take action we reasonably deem necessary based on the results of such inquiries. When we carry out these inquiries, you understand, acknowledge and agree that your personal information may be disclosed to credit reference and fraud prevention or financial crime agencies and that these agencies may respond to our inquiries in full.

In certain circumstances, we may require you to submit additional information about yourself or your business, provide records, and complete other verification steps (such process, "Enhanced Due Diligence").

You represent and warrant that all information provided to us pursuant to this Agreement is true, accurate and not misleading in any respect. If any such information changes, it is your obligation to update such information as soon as possible.

From time to time we may be required to request further information or review or update existing information regarding your registration or your transactions to comply with applicable laws and regulation, and in some cases, payment network. Failure to provide such information, if requested by the Company, in a timely fashion may result in the suspension of your ability to use the Services (until you provide such information) or the termination of your status as a Mint User.

We reserve the right to maintain your registration information after you terminate your status as a Mint User for business and regulatory compliance purposes, subject to applicable laws and regulation.

**2. Services**

The Company offers the following Services in connection with your status as a Mint User:

The Company provides USDe-related services, which are described more fully in Section 10 and in the USDe Terms. The USDe Terms are incorporated herein by reference.

**3. Custody**

The Company does not provide any custody services with respect to USDe or any other assets. Additionally, for the avoidance of doubt, the Company is not a fiduciary, and the Company does not provide any trust or fiduciary services to any User in the course of such User visiting, accessing, or using the the Company website or services, including, for the avoidance of doubt, holding USDe.

Legal title to the reserves associated with USDe are held by the Company, which administers the assets accordingly.

**4. No Investment Advice**

The Company does not provide investment, tax, or legal advice, nor does the Company broker trades on your behalf. You should consult your legal or tax professional regarding your specific situation. The Company may provide educational information about USDe and other Digital Currency not supported by the Company. Information may include, but is not limited to, blog posts, articles, links to third-party content, news feeds, tutorials, and videos. The information provided on this website or any third-party sites does not constitute investment advice, financial advice, trading advice, or any other sort of advice, and you should not treat any of the website's content as such.

**5. Privacy**

We are committed to protecting your personal information and helping you understand exactly how your personal information is being used. You should carefully read the  Privacy Policy as it provides details on how your personal information is collected, stored, protected, and used.

**6. Communications**

By entering into this Agreement, you agree to receive electronic communications and notifications in accordance with our E-Sign Consent Policy, as detailed in the USDe Terms.

This Agreement is provided to you and communicated in English. We will also communicate with you in English for all matters related to your use of the Services. Where we have provided you with a translation of the English language version of this Agreement or any information related to your status as a Mint User, you acknowledge and agree that such translation is provided for your convenience only and that the English language version of the Agreement will govern your use of the Services.

**7. Security of User Information**

You are responsible for maintaining the confidentiality and security of all account names, User IDs, passwords, seed phrases, private keys, personal identification numbers (PINs) and other access codes that you use to access the Services. You are responsible for keeping your email address and all other access and User information up to date with us and for maintaining the confidentiality of your User information. You agree to (i) notify the Company immediately if you become aware of any unauthorized use of your registration as a Mint User, the Services, or any other breach of security regarding the Services or the Platform. We strongly advise you to enable all security features that are available to you (such as, by way of example, using hardware wallets to secure private keys); this offers you enhanced protection from possible malicious attacks. The Company will not be liable for any loss or damage arising from your failure to protect your registration information or private keys.

We shall not bear any liability for any damage or interruptions caused by any computer viruses, spyware, or other malware that may affect your computer or other equipment, or any phishing, spoofing, or other attack. We recommend the regular use of a reliable virus and malware screening and prevention software. If you question the authenticity of a communication purporting to be from the Company, you should contact a representative directly.

**8. Suspension & Closure**

We may, without liability to you or any third party, suspend your status as a Mint User or terminate your status as a Mint User or suspend your use of one or more of the Services in accordance with the terms of this Agreement, as determined in our sole and absolute discretion. Such actions may be taken as a result of inactivity, failure to respond to customer support requests, failure to positively identify you, a court order, your violation of the terms of this Agreement or for other similar reasons. The Company may also temporarily suspend your status as a Mint User in the event that a technical problem causes system outage or the Company errors until the problem is resolved. For the avoidance of doubt, in the event your status as a Mint User is suspended or closed, you will no longer be able to access any of the Services.

You may terminate this Agreement at any time by terminating your status as a Mint User in accordance with this Agreement. In order to do so, you should contact the Company’s “Support Team” who will assist you in terminating your status as a Mint User. You may not terminate your status as a Mint User if the Company believes, in its sole discretion, that such termination is being performed in an effort to evade a court order or legal or regulatory investigation or to avoid paying any amounts otherwise due to the Company.

Upon closure or suspension of your status as a Mint User, you authorize the Company to cancel or suspend pending transactions and forfeit all proprietary rights and claims against the Company in relation to any assets otherwise eligible for redemption.

In the event that you or the Company terminates this Agreement or your access to the Services, or cancels your status as a Mint User, you remain liable for all activity conducted on or with your status as a Mint User while it was active and for all amounts due hereunder.

**9. Fees**

The Company may charge fees in connection with the Services, which will typically not represent fees for the Company’s own account and will constitute reimbursements for costs associated with transactions initiated by you, such as blockchain gas fees and execution fees. You agree to pay the fees shown to you, if any, or as separately agreed between you and the Company, when you enter into a transaction.  Fees are generally disclosed prior to your confirmation of any transaction with the Company; we may change any of the fees that the Company charges at any time, with or without notice.

The applicable Digital Currency network may charge a fee in connection with blockchain transactions. You are responsible for all such fees.

**10. Applicable USDe Terms**

To the extent that you utilize your status as a Mint User for any transaction or service involving USDe to which the Company is a counterparty, the USDe Terms shall apply to all such transactions and such agreement. Notwithstanding anything to the contrary set forth in this Agreement or otherwise, in the event of a conflict between any term set forth herein and any term set forth in the USDe Terms, (i) in connection with any USDe transaction, the terms of the USDe Terms shall control, and (ii) in respect of any other Digital Currency transaction, the terms of this Agreement shall control.

**11. Mobile Services**

To the extent you access the Services through a mobile device, your wireless service carrier’s standard charges, data rates, and other fees may apply. In addition, downloading, installing, or using certain mobile applications may be prohibited or restricted by your carrier, and not all Services may work with all carriers or devices. By using mobile Services, you agree that we may communicate with you by SMS, MMS, text message, push notification, and/or other electronic means via your mobile device (“Mobile Messaging”) and that certain information about your usage of the Services may be communicated to us. In the event that you change or deactivate your mobile telephone number, you agree to promptly update your registration information to ensure that your messages are not sent to any person who might acquire your old number.

You may receive messages related to the Services or your status as a Mint User via Mobile Messaging. Message and data rates may apply. Reply STOP to any such Mobile Message to Cancel and unsubscribe. For help, please contact  the Support Team.

You hereby confirm that with respect to any mobile phone number provided, you own the account corresponding to that mobile phone number or otherwise have the account holder’s permissions to use this service. By registering a mobile phone number you are agreeing to the specific terms set forth in this Section 11.

**12. Transaction Limits**

The Company reserves the right to change the mint, redemption, transfer, and velocity limits as we deem necessary. We may establish individual or aggregate transaction limits on the size or number of mints, redemptions, transfers or other transactions that you initiate using your status as a Mint User during any specified time period.

**13. Right to Change/Remove Features or Suspend/Delay Transactions**

Subject to Section 17 of the USDe Terms, we reserve the right to change, suspend, or discontinue any aspect of the Services or the Platform at any time, including hours of operation or availability of any feature, without notice and without liability. We may, in our sole discretion, delay any transaction if we believe that such transaction is suspicious, may involve fraud or misconduct, violates applicable laws or payment network rules, or violates any term of this Agreement.

**14. Insufficient Funds**

If you have insufficient funds in your whitelisted wallet associated with your status as a Mint User to complete a transaction, such transaction will not be completed.

**15. Refunds; Reversals**

Once a transaction has been initiated (including, but not limited to, a Digital Currency Transfer), it cannot be reversed or refunded, except as set forth in this Agreement. You may have additional refund or chargeback rights under your agreement with the recipient of such funds, your financial institution, or applicable law. You should periodically review statements from your financial institution and any other service that you use to transact Digital Currency, which should reflect all applicable transactions made using the related transaction method.

**16. Taxes**

It is your responsibility to determine what, if any, taxes apply to the payments you make or receive, and to collect, report, and remit the correct tax to the appropriate tax authority. the Company is not responsible for determining whether taxes apply to your transaction, or for collecting, reporting, or remitting any taxes arising from any transaction.

**17. Indemnification; Release**

You agree to indemnify and hold the Company, its affiliates, and service providers, and each of their officers, directors, agents, joint venturers, employees, and representatives harmless from any claim or demand (including attorneys’ fees and any losses, fines, fees or penalties imposed by any regulatory authority) arising out of your breach of this Agreement, your violation of any law or regulation or your use of the Services.

For the purpose of this Section 17, the term “losses” means all net costs reasonably incurred by us or the other persons referred to in this Section which are the result of the matters set out in this Section 19 and which may relate to any claims, demands, causes of action, debt, cost, expense or other liability, including reasonable legal fees (without duplication).

If you have a dispute with one or more Users or third parties, you release the Company (and its affiliates and service providers, and each of their officers, directors, agents, joint ventures, employees and representatives) from all claims, demands, and damages (actual and consequential) of every kind and nature arising out of or in any way connected with such disputes.

**18. Limitation of Liability; No Warranty**

YOU EXPRESSLY UNDERSTAND AND AGREE THAT THE COMPANY AND OUR AFFILIATES AND SERVICE PROVIDERS, AND THEIR RESPECTIVE OFFICERS, DIRECTORS, AGENTS, JOINT VENTURERS, EMPLOYEES, AND REPRESENTATIVES WILLNOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY DAMAGES, OR DAMAGES FOR LOSS OF PROFITS INCLUDING BUT NOT LIMITED TO, DAMAGES FOR LOSS OF GOODWILL, USE, DATA, OR OTHER INTANGIBLE LOSSES (EVEN IF THE COMPANY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES),WHETHER BASED ON CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY, OR OTHERWISE, RESULTING FROM: (I) THE USE OR THE INABILITY TO USE THE SERVICES; (II) THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES RESULTING FROM ANY GOODS, DATA, INFORMATION, OR SERVICES PURCHASED OR OBTAINED OR MESSAGES RECEIVED OR TRANSACTIONS ENTERED INTO THROUGH OR FROM THE SERVICES; (III) UNAUTHORIZED ACCESS TO OR ALTERATION OF YOUR TRANSMISSIONS OR DATA; OR (IV) ANY OTHER MATTER RELATING TO THE SERVICES.

SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF CERTAIN WARRANTIES OR THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES. ACCORDINGLY, SOME OF THE LIMITATIONS SET FORTH ABOVE MAY NOT APPLY TO YOU. IF ANY PROVISION OF THIS SECTION CANNOT BE GIVEN FULL EFFECT UNDER THE LAWS OF YOUR JURISDICTION, REVIEWING COURTS SHALL APPLY LOCAL LAW THAT MOST CLOSELY APPROXIMATES THE INTENDED ECONOMIC EFFECT OF SUCH PROVISION, INCLUDING AN ABSOLUTE WAIVER OF ALL CIVIL LIABILITY IN CONNECTION WITH THE SERVICES TO THE EXTENT PERMITTED BY LAW. IF YOU ARE DISSATISFIED WITH ANY PORTION OF THE SERVICES OR WITH THIS AGREEMENT, YOUR SOLE AND EXCLUSIVE REMEDY IS TO DISCONTINUE USE OF THE SERVICES AND TERMINATE YOUR STATUS AS A MINT USER.

THE SERVICES ARE PROVIDED "AS IS" AND WITHOUT ANY REPRESENTATION OR WARRANTY, WHETHER EXPRESS,IMPLIED OR STATUTORY. THE COMPANY, OUR AFFILIATES, AND OUR RESPECTIVE OFFICERS, DIRECTORS, AGENTS, JOINT VENTURERS, EMPLOYEES, AND SUPPLIERS SPECIFICALLY DISCLAIM ANY IMPLIED WARRANTIES OF TITLE,MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. THE COMPANY MAKES NO WARRANTY THAT (I) THE SERVICES WILL MEET YOUR REQUIREMENTS, (II) THE SERVICES WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE, OR (III) THE QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL PURCHASED OR OBTAINED BY YOU WILL MEET YOUR EXPECTATIONS.

The Company will make reasonable efforts to ensure that requests for the Company transactions are processed in a timely manner, but the Company makes no representations or warranties regarding the amount of time needed to complete processing because the Services are dependent upon many factors outside of our control, such as delays in the banking system. or international mail service. Some jurisdictions do not allow the disclaimer of implied warranties, so the foregoing disclaimers may not apply to you. This Section gives you specific legal rights and you may also have other legal rights that vary from state to state.

**19. Right to Set Off**

The Company may and is authorized, without prior notice and both before and after demand, to set off the whole or any part of your liabilities or other amounts payable to the Company, including but not limited to fees, whether such amounts are present or future, actual or contingent, or liquidated or unliquidated, against any sums held by the Company and owed to you, whether under this Agreement or any other agreement between the Company and you.

For the purpose of exercising its rights under this Section 21: (i) the Company is entitled to convert and/or exchange any Supported Digital Currency owned by you and held by the Company, and is authorized to effect any such conversions at the then prevailing exchange rate; and (ii) if your liability is contingent and/or unliquidated, then the Company may set off the amount it estimates in good faith will be the liquidated amount.

**20. Arbitration**

Except for claims for injunctive or equitable relief or claims regarding intellectual property rights (which may be brought, in an individual capacity only, and not on a class-wide or representative basis, in the courts specified in Section 28 without the posting of a bond), any dispute between you and the Company related in any way to, or arising in any way from, our Services or this Agreement (“Dispute”) shall be finally settled on an individual, non-representative basis in binding arbitration shall be settled by arbitration in accordance with the BVI IAC Arbitration Rules, as modified by this Agreement, or in accordance with rules on which we may mutually agree in writing; provided, however, that to the extent a Dispute is within the scope of a small claims court’s jurisdiction, either you or the Company may commence an action in small claims court, in the county of your most recent physical address, to resolve the Dispute.

Any arbitration will be conducted by a single, neutral arbitrator and shall take place in Road Town, Tortola, British Virgin Islands, unless we agree otherwise. The arbitrator may award any relief that a court of competent jurisdiction could award, including attorneys’ fees when authorized by law. The arbitral decision may be enforced in any court of competent jurisdiction. An arbitral decision is subject to very limited review by a court.

**21. Amendments**

The Company may amend any portion of this Agreement at any time by posting the revised version of this Agreement with an updated revision date. The changes will become effective, and shall be deemed accepted by you, the first time you use the Services after the initial posting of the revised Agreement and shall apply on a going-forward basis with respect to transactions initiated after the posting date. In the event that you do not agree with any such modification, your sole and exclusive remedy is to terminate your use of the Services and terminate your status as a Mint User. You agree that we shall not be liable to you or any third party as a result of any losses suffered by any modification or amendment of this Agreement.

If the revised Agreement includes a material change, we will provide you with prior notice via our website and/or email before the material change becomes effective. For this purpose a “material change” means a significant change other than changes that (i) are to your benefit, (ii) are required to be made (a) to comply with applicable laws and/or regulations, (b) to comply with a payment network , or (c) as otherwise required by one of our regulators, (iii) relates to a new product or service made available to you, or (iv) to otherwise clarify an existing term.

**22. Assignment**

You may not transfer or assign this Agreement or any rights or obligations hereunder, by operation of law or otherwise and any such attempted assignment shall be void. We reserve the right to freely assign this Agreement and the rights and obligations of this Agreement to any third party at any time without notice or consent. If you object to such transfer or assignment, you may stop using our Services and terminate this Agreement by contacting the Company’s Support Team and asking us to terminate your status as a Mint User.

**23. Change of Control**

In the event that the Company is acquired by or merged with a third party entity, we reserve the right, in any of these circumstances, to transfer or assign the information we have collected from you as part of such merger, acquisition, sale, or other change of control.

**24. Survival; Force Majeure**

Upon termination of your status as a Mint User or this Agreement for any reason, all rights and obligations of the parties that by their nature are continuing will survive such termination.

The Company shall have no liability for any failure or delay resulting from any condition beyond our reasonable control, including but not limited to governmental action or acts of terrorism, pandemics, earthquake, fire, flood, or other acts of God, labor conditions, power failures, equipment failures, and Internet disturbances.

**25. Website; Third Party Content**

The Company strives to provide accurate and reliable information and content on the Company website, but such information may not always be correct, complete, or up to date. The Company will update the information on the Company website as necessary to provide you with the most up to date information, but you should always independently verify such information. The Company website may also contain links to third party websites, applications, events or other materials (“Third Party Content”). Such information is provided for your convenience and links or references to Third Party Content do not constitute an endorsement by the Company of any products or services. The Company shall have no liability for any losses incurred as a result of actions taken in reliance on the information contained on the Company website or in any Third Party Content.

**26. Limited License; IP Rights**

We grant you a limited, non-exclusive, non-sublicensable, and non-transferable license, subject to the terms and conditions of this Agreement, to access and use the Services solely for approved purposes as determined by the Company. Any other use of the Services or the Platform is expressly prohibited. the Company and its licensors reserve all rights in the Services and you agree that this Agreement does not grant you any rights in or licenses to the Services except for the limited license set forth above. Except as expressly authorized by the Company, you agree not to modify, reverse engineer, copy, frame, scrape, rent, lease, loan, sell, distribute, or create derivative works based on the Services or the Platform, in whole or in part. If you violate any portion of this Agreement, your permission to access and use the Services and your status as a Mint User may be terminated pursuant to this Agreement. "USDe.money", "the Company", and all logos related to the Services are either trademarks, or registered marks of the Company or its licensors. You may not copy, imitate, or use them without the Company's prior written consent. All right, title, and interest in and to the the Company website, any content thereon, the Services, and all technology and any content created or derived from any of the foregoing is the exclusive property of the Company and its licensors.

**27. Applicable Law; Legal Compliance**

Your use of the Services is subject to the laws, regulations, and rules of any applicable governmental or regulatory authority, including, without limitation, all applicable tax, anti-money laundering (“AML”) and counter-terrorist financing (“CTF”) provisions.

You unequivocally agree and understand that by registering as a Mint User and using the Services in any capacity, you will act in compliance with and be legally bound by this Agreement and all applicable laws and regulations (including, without limitation, those stated in this Section 27, where applicable). For the avoidance of doubt, continued use of your status as a Mint User and the Company’s obligations to you under this Agreement are conditional on your continued compliance at all times with this Agreement and all applicable laws and regulations. The Company’s AML and CTF procedures are guided by all applicable laws and regulations regarding AML and CTF. These standards are designed to prevent the use of the Services for money laundering or terrorist financing activities. We take compliance very seriously and it is our policy to take all necessary steps to prohibit fraudulent transactions, report suspicious activities, and actively engage in the prevention of money laundering and any related acts that facilitate money laundering, terrorist financing or any other financial crimes.

You agree, represent, and warrant that all funds transacted as a Mint User, or funds deposited by you with the Company in the future, are not the direct or indirect proceeds of any criminal or fraudulent activity.

The Services are subject to economic sanctions programs administered in the countries where we conduct business, including but not limited to those administered by the U.S. Department of Treasury’s Office of Foreign Assets Control (“OFAC”), pursuant to which we are prohibited from providing services or entering into relationships with certain individuals and institutions.  By using the Services, you represent that your actions are not in violation of such sanctions programs. Without limiting the foregoing, you may not use the Services if (i) you are a resident, national or agent of a jurisdiction subject to comprehensive sanctions by OFAC (“Restricted Territories”), (ii) you are on the Table of Denial Orders, the Entity List, or the List of Specially Designated Nationals (“Restricted Persons”), or (iii) you intend to transact with any Restricted Territories or Restricted Persons. You further represent that you are not a citizen, resident, or organized in, the following jurisdictions (the “Prohibited Jurisdictions”): Abkhazia, Afghanistan, Angola, Belarus, Burundi, Central African Republic, Congo, Cuba, Crimea, Ethiopia, Guinea-Bissau, Iran, Ivory Coast (Cote D’Ivoire), Lebanon, Liberia, Libya, Mali, Burma (Myanmar), Nicaragua, North Korea, Northern Cyprus, Russia, Somalia, Somaliland, South Ossetia, South Sudan, Sudan, Syria, Ukraine (Donetsk and Luhansk regions), United States, Venezuela, Yemen, Zimbabwe.

In the event that we are required to block funds associated with your registration as a Mint User in accordance with a sanctions program, or other similar government sanctions programs, we may: (i) suspend your status as a Mint User; (ii) terminate your status as a Mint User; or (iii) return funds to the destination of their origin or to an account specified by authorities. In certain cases, taking one or more of these actions may result in a forfeiture of some or all of your assets held with the Company. We are not responsible for any losses, whether direct or indirect, that you may incur as a result of our complying with applicable law and regulations, the guidance or direction of any regulatory authority or government agency, or any writ of attachment, lien, levy, subpoena, warrant, or other legal order.

**28. Governing Law; Venue**

The laws of the British Virgin Islands shall govern this Agreement. Except for those disputes that shall be resolved in arbitration or in small claims court, each party agrees to submit to the personal and exclusive jurisdiction of the courts located in the British Virgin Islands, provided that any claims or disputes shall be subject to the arbitration provisions set forth in Section 20. You agree with us that, if you are a consumer, the courts in the permitted region where you are resident will have non-exclusive jurisdiction.

**29. Entire Agreement**

The failure of the Company to exercise or enforce any right or provision of the Agreement shall not constitute a waiver of such right or provision. If any provision of this Agreement shall be adjudged by any court of competent jurisdiction to be unenforceable or invalid, that provision shall be limited or eliminated to the minimum extent necessary so that this Agreement shall otherwise remain in full force and effect and remain enforceable between the parties, except as specified in Section 25. The headings and explanatory text are for reference purposes only and in no way define, limit, construe, or describe the scope or extent of such section. This Agreement, including any additional agreement incorporated by reference herein; the Company’s policies governing the Services referenced herein (including, without limitation, those set forth in the USDe Terms); the the Company Privacy Policy and the Cookie Policy constitute the entire agreement between you and the Company with respect to the use of the Services. This Agreement is not intended and shall not be construed to create any rights or remedies in any parties other than you and the Company and other the Company affiliates which each shall be a third-party beneficiary of this Agreement, and no other person shall assert any rights as a third-party beneficiary hereunder.

**30. User Support**

Please contact our Support Team to report any violations of this Agreement or to ask any questions regarding this Agreement or the Services.

Last updated 9 months ago

Was this helpful?