# Testnet

> Source: https://docs.ethena.fi/resources/testnet

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/testnet.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Testnet

Resources for testing Ethena smart contracts

Because of the active ecosystem on Ethereum mainnet and the history of our contracts there, it is highly encouraged to test there using a fork.  Such can be achieved with tools like Tenderly and Anvil.

Canonical, verified testnet deployments of USDe can be found here: 

Ethereum Sepolia: [https://sepolia.etherscan.io/address/0x9458caaca74249abbe9e964b3ce155b98ec88ef2](https://sepolia.etherscan.io/address/0x9458caaca74249abbe9e964b3ce155b98ec88ef2)

Ethereum Goerli: [https://goerli.etherscan.io/address/0x7faaf9bbc8a07d7731aab129e9a066f40560cf21](https://goerli.etherscan.io/address/0x7faaf9bbc8a07d7731aab129e9a066f40560cf21)

Last updated 2 years ago

Was this helpful?