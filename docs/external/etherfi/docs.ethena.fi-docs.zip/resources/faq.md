# FAQ

> Source: https://docs.ethena.fi/resources/faq

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/faq.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# FAQ

Frequently Asked Questions

## Our FAQ aims to answer every question we've been asked on Ethena and USDe.[](#our-faq-aims-to-answer-every-question-weve-been-asked-on-ethena-and-usde)

Link to the full FAQ [here](https://www.notion.so/ethena/Ethena-FAQs-3ccc1437e13343f8b74c0d005e4f5128?pvs=4).

[![Logo](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fwww.notion.so%2Ffront-static%2Flogo-ios.png&width=20&dpr=3&quality=100&sign=e6712e85a03aaaf40a4c77fd8e7699ef&sv=3)Ethena FAQs  | Notionethena on Notion](https://www.notion.so/ethena/Ethena-FAQs-3ccc1437e13343f8b74c0d005e4f5128?pvs=4)
## General Questions[](#general-questions)

#### Can anyone mint/redeem *USDe*?[](#can-anyone-mint-redeem-usde)

All addresses will need to be whitelisted by the Ethena Protocol after satisfying KYC/AML checks. US users are not able to access the application. Feel free to reach out in our [Telegram ](https://t.me/ethena_labs)or [Discord ](https://discord.gg/cepXWnXHaa)for help onboarding.

## Peg Stability[](#peg-stability)

#### *How is stability supported?*[](#how-is-stability-supported)

*USDe's *peg stability is supported through the protocol immediately hedging the delta of protocol backing assets. This aims to protect the underlying backing supporting *USDe* from significant variance in "USD" equivalent value under volatile market conditions or price action.

## Security & Safety of Protocol Backing[](#security-and-safety-of-protocol-backing)

#### *How is protocol backing kept safe from hacks or exchange failures?*[](#how-is-protocol-backing-kept-safe-from-hacks-or-exchange-failures)

Protocol backing is held solely in audited smart contracts as well as regulated & licensed custodians and MPC wallet providers. The custodian and MPC wallet provider partners have the highest possible security and are used by all institutional participants in the space. The use of custodians and MPC wallet providers also enables the system to custody funds off-exchange, but to still have funds available on the exchanges to collateralize the delta hedging derivatives positions. In the event of an exchange failure, the funds are NOT expected to be locked or party to the bankruptcy and Ethena should retain control to support all mint & redeem requests of *USDe *on demand.

***Why doesn't the protocol just hold assets with the exchanges?***

Holding protocol backing with exchanges exposes the protocol to risks if an exchange were to limit/delay withdrawals or were to close suddenly like FTX. The ability to use off-exchange custody providers enables Ethena to enjoy the benefits of a disintermediation of incentives as well as the availability of backed assets to trade on the most liquid markets.

## Rewards Explanation[](#rewards-explanation)

#### The protocolshares rewards with certain users, how is that received?[](#the-protocol-shares-rewards-with-certain-users-how-is-that-received)

The protocol-level revenue Ethena generates come from three different sources:

1. Staked ETH yield
2. Perpetual Futures Funding Rates or Expiry Futures Basis
3. Fixed rewards on Liquid Stables

On the backing asset side, staked Ethereum backing USDe will offer rewards that are currently around 3-4%. The delta hedged derivative positions offsetting the backing assets can also earn income on both perpetual futures funding rates and the basis on dated futures. Lastly, the rewards from liquid stables held by the protocol are in line with the TradFi risk free rate.

Basis refers to the difference between the spot price of an asset and the price of the corresponding expiring futures contract. More on basis trades [here](https://docs.ethena.fi/protocol-overview/underlying-derivatives/basis-spread).

Funding Rates are periodic payments made to traders who are long or short depending on the difference between spot prices and perpetual contract markets. Consequently, traders will either pay or get funding based on open positions depending on demand for long or short positions. When the funding rate is positive, long positions pay shorts; when it is negative, short positions pay those long the contract. This mechanism ensures avoiding long-term divergence in the prices of the two markets.

Both dated futures basis and perpetual funding rates have, on average, returned a yield to the short side of c.6-7% over the last 3 years, leading to an excess return over staked Ethereum and liquid stables holdings.

These protocol level rewards are variable, transparent, sustainable, and partially distributed to users (net of revenue that accrues to the reserve fund) according to the staking mechanism.

## Perpetual Futures[](#perpetual-futures)

***Aren't perpetual futures funding rates volatile?***

Perpetual futures funding rates have two primary components: the interest rate and the premium. The venue determines how funding rates are calculated. Funding rates may exhibit sharp behavior during times of market volatility, they may go negative for significant periods but usually revert closer to zero or positive and display mean-reverting characteristics.

Historically, long positions have paid the funding rate to the short side, which on average are expected to provide Ethena with an excess return over rewards from ETH staking and liquid stables holdings. The table below summarizes the distribution of funding rates since inception. We can see that the mean for annualized open interest-weighted funding rates is 9.03% for ETH and 7.79% for BTC.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FfKFSqgaVuInwvWlKGyzc%252Fimage.png%3Falt%3Dmedia%26token%3D751ada0c-b07b-4110-8054-d336e46bc42f&width=768&dpr=3&quality=100&sign=a351229c17a1a46fe09d03f11ccb50d7&sv=3)***How does this affect the combined protocol yield?***

Combining the different income sources gives the system an excess return, which is broken down below for each perpetual future contract per quarter. Q3 2022 was the only quarter with a negative excess return on some exchanges thanks to an arbitrage opportunity related to the ETH Proof of Work token airdrop post-Merge.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FyXzxPMVWySleW6pDUZgV%252FCumulative%2520Rewards%2520by%2520Quarter.png%3Falt%3Dmedia%26token%3Dfba0fe62-4cac-49f1-a271-d4d54d63ed07&width=768&dpr=3&quality=100&sign=c2d6c01850b17b381d932efbd5de295b&sv=3)There are "Quick Answers" available throughout the documentation as well.

We would love to answer any unanswered questions. Join us in [Telegram ](https://t.me/ethena_labs)& [Discord](https://discord.com/invite/cepXWnXHaa).

Last updated 1 month ago

Was this helpful?