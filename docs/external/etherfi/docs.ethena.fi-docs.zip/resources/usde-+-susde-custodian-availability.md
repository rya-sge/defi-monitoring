# USDe + sUSDe Custodian Availability

> Source: https://docs.ethena.fi/resources/usde-+-susde-custodian-availability

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/usde-+-susde-custodian-availability.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# USDe + sUSDe Custodian Availability

This page details where *USDe *and *sUSDe* are available to be custodied.

If either asset is not available to be custodied with a custodian, Ethena is in the process of enabling it to be.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FgDkLcT3pDZEiUMr6REwK%252Fusde.png%3Falt%3Dmedia%26token%3D698a9f98-bc17-462b-9d65-31744871e90a&width=768&dpr=3&quality=100&sign=e56c7223ae3fc51c89a14cdbd49821d0&sv=3)Last updated 10 months ago

Was this helpful?