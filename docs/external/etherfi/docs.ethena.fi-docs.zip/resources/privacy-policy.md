# Privacy Policy

> Source: https://docs.ethena.fi/resources/privacy-policy

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/privacy-policy.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Privacy Policy

Last Revised on August 2025

This Privacy Policy for Ethena (BVI) Limited (collectively with its affiliates, "Company", "we", "us" "our") describes how we collect, use and disclose information about users of the Company's websites (ethena.fi, the “Site”), and any related services, tools and features, including the Ethena service (collectively, the "Services"). For the purposes of this Privacy Policy, "you" and "your" means you as the user of the Services. Please read this Privacy Policy carefully. By using, accessing, or downloading any of the Services, you agree to the collection, use, and disclosure of your information as described in this Privacy Policy. If you do not agree to this Privacy Policy, please do not use, access or download any of the Services. ​

### UPDATING THIS PRIVACY POLICY[](#updating-this-privacy-policy)

We may modify this Privacy Policy from time to time in which case we will update the "Last Revised" date at the top of this Privacy Policy. If we make material changes to the way in which we use information we collect, we will use reasonable efforts to notify you (such as by emailing you at the last email address you provided us, by posting notice of such changes on the Site, or by other means consistent with applicable law) and will take additional steps as required by applicable law. If you do not agree to any updates to this Privacy Policy please do not access or continue to use the Services. ​

### COMPANY'S COLLECTION AND USE OF INFORMATION[](#companys-collection-and-use-of-information)

​When you access or use the Services, we may collect (directly or through third-party providers) certain categories of information about you from a variety of sources, which comprises: ​

- Information provided during “Know Your Customer” (“KYC”) and Anti-Money Laundering (“AML”) processes, which includes personal identifying information. This may include:
- Basic Information: Name, Address, Date of Birth, Nationality, Country of Residence, Phone Number, Email Address.
- Identification Information: Utility bills (or other proof of address), photographs, Government-issued identification (such as identification cards, passports, driver’s licenses, etc.), tax ID number, employment information, proof of residency, visa information, organizational documents, and information regarding ultimate beneficial owners.
- Financial Information: Income/net assets/wealth verification statements.

We process the data provided and collected to provide the Services, personalize your experience with the Services, and improve the Services. Specifically, we use your data to:

- identify you as a user in our system;
- identify your place of residence, or registered office;
- provide you with our Service;
- improve the administration of our Service and quality of experience when you interact with our Service;
- provide customer support and respond to your requests and inquiries;
- investigate and address conduct that may violate our Terms of Use;
- detect, prevent, and address fraud, violations of our terms or policies, and/or other harmful or unlawful activity;
- send you administrative notifications, such as security, support, and maintenance advisories;
- send you newsletters, promotional materials, and other notices related to our Services or third parties' goods and services;
- respond to your inquiries related to employment opportunities or other requests;
- comply with applicable laws, cooperate with investigations by law enforcement or other authorities of suspected violations of law, and/or to pursue or defend against legal threats and/or claims; and
- act in any other way we may describe when you provide the Personal Data.

### HOW THE COMPANY SHARES YOUR INFORMATION[](#how-the-company-shares-your-information)

​In certain circumstances, the Company may share your information with third parties for legitimate purposes subject to this Privacy Policy. Such circumstances comprise of: ​

- Blockchain analysis service providers, including TRM​ (TRM is a member of the EU-U.S. Data Privacy Framework as set forth by the U.S. Department of Commerce.)
- Data analytics vendors, including Google Analytics ​
- To comply with applicable law or any obligations thereunder, including cooperation with law enforcement, judicial orders, and regulatory inquiries ​
- In connection with an asset sale, merger, bankruptcy, or other business transaction ​
- To enforce any applicable terms of service ​
- To ensure the safety and security of the Company and/or its users ​
- With any parent companies, subsidiaries, joint ventures, or other companies under common control with us, in which case we will require such entities to honor this Privacy Policy
- In connection with or during negotiation of any merger, financing, acquisition, or dissolution transaction or proceeding involving sale, transfer, divestiture, or disclosure of all or a portion of our business or assets. In the event of an insolvency, bankruptcy, or receivership, data may also be transferred as a business asset. If another company acquires our company, business, or assets, that company will possess the data collected by us and will assume the rights and obligations regarding your data as described in this Privacy Policy.
- When you request us to share certain information with third parties, such as through your use of login integrations ​
- With professional advisors, such as auditors, law firms, accounting firms, or KYC service providers ​
- With related companies, e.g. Ethena BVI Limited, to provide the Services

### LEGAL BASIS UNDER GDPR[](#legal-basis-under-gdpr)

The legal bases for the processing of personal data of natural persons in the European Economic Area (EEA) are detailled in the General data Protection Regulation (GDPR). The legal bases for processing your personal data are:

- In the case of the initiation of a contract or an ongoing contractual relationship, the legal basis follows from Art. 6 (1) lit. b GDPR;
- We are obliged by law to process Your data, e.g. by Financial Regulations (such as MiCAR Markets in Crypto Assets Regulation), Anti Money Laundering Laws, Tax Laws etc; the legal basis for such processing is Art. 6 (1) lit. c GDPR;
- Our legitimate interests under Art. 6 (1) lit. f GDPR; our legitimate interests are e.g. to safeguard the security and stability of our Services; to monitor the use of our Services in order to comply with all applicable laws; to detect, prevent, and address fraud, violations of our terms or policies, and/or other harmful or unlawful activity; to improve our Services; and for certain limited promotional purposes.
- If You have given Your consent to process Your data, the legal basis is Art. 6 (1) lit. a GDPR.

### COOKIES AND OTHER TRACKING TECHNOLOGIES[](#cookies-and-other-tracking-technologies)

Do Not Track Signals: ​ Your browser settings may allow you to transmit a "Do Not Track" signal when you visit various websites. Like many websites, our website is not designed to respond to "Do Not Track" signals received from browsers. To learn more about "Do Not Track" signals, you can visit http://www.allaboutdnt.com/. ​

Cookies and Other Tracking Technologies: ​ Most browsers accept cookies automatically, but you may be able to control the way in which your devices permit the use of cookies, web beacons/clear gifs, other geolocation tracking technologies. If you so choose, you may block or delete our cookies from your browser; however, blocking or deleting cookies may cause some of the Services, including any portal features and general functionality, to work incorrectly. If you have questions regarding the specific information about you that we process or retain, as well as your choices regarding our collection and use practices, please contact us using the information listed below. ​ You can opt out of tracking by Google Analytics. ​ Your browser settings may allow you to transmit a "Do Not Track" signal when you visit various websites. Like many websites, our website is not designed to respond to "Do Not Track" signals received from browsers. To learn more about "Do Not Track" signals, you can visit http://www.allaboutdnt.com/. ​

The legal bases for the setting of cookies are legitimate interests under Art. 6 para. 1 letter f) GDPR and, if applicable, Your consent in accordance with Art. 6 (1) (b) GDPR.  In the case of the initiation of a contract or an ongoing contractual relationship, the legal basis also follows from Art. 6 para. 1 sentence 1 letter b) GDPR.

### SOCIAL NETWORKS AND OTHER THIRD PARTY WEBSITES AND LINKS[](#social-networks-and-other-third-party-websites-and-links)

We may provide links to websites or other online platforms operated by third parties, including third-party social networking platforms, such as Twitter, Discord, Telegram or Medium as well as Curve Finance & Uniswap, operated by third parties (such platforms are "Social Networks" or “Decentralized Finance Applications”). If you follow links to sites not affiliated or controlled by us, you should review their privacy and security policies and other terms and conditions. We do not guarantee and are not responsible for the privacy or security of these sites, including the accuracy, completeness, or reliability of information found on these sites. Information you provide on public or semi-public venues, including information you share or post on Social Networks, may also be accessible or viewable by other users of the Services and/or users of those third-party online platforms without limitation as to its use by us or by a third party. Our inclusion of such links does not, by itself, imply any endorsement of the content on such platforms or of their owners or operators, except as disclosed on the Services. ​

### THIRD PARTY WALLET EXTENSIONS[](#third-party-wallet-extensions)

​Certain transactions conducted via our Services, will require you to connect a Wallet to the Services. By using such Wallet to conduct such transactions via the Services, you agree that your interactions with such third party Wallets are governed by the privacy policy for the applicable Wallet. We expressly disclaim any and all liability for actions arising from your use of third party Wallets, including but without limitation, to actions relating to the use and/or disclosure of personal information by such third party Wallets.

### PUBLIC INFORMATION OBSERVED FROM BLOCKCHAINS[](#public-information-observed-from-blockchains)

We collect data from activity that is publicly visible and/or accessible on blockchains. This may include blockchain addresses and information regarding holdings, purchases, sales, or transfers of tokens, which may then be associated with other data you have provided to us.

### CHILDREN'S PRIVACY[](#childrens-privacy)

Children under the age of 18 are not permitted to use the Services, and we do not seek or knowingly collect any personal information about children under 13 years of age. If we become aware that we have unknowingly collected information about a child under 13 years of age, we will make commercially reasonable efforts to delete such information from our database. ​ If you are the parent or guardian of a child under 13 years of age who has provided us with their personal information, you may contact us using the below information to request that it be deleted. ​

### DATA ACCESS AND CONTROL[](#data-access-and-control)

You can view, access, edit, or delete your data for certain aspects of the Service via your Settings page. You may also have certain additional rights:

- If you are a user in the European Economic Area, you have certain rights under the European General Data Protection Regulation (“GDPR”). These include the right to
- - (i) request access and obtain a copy of your personal data;
  - (ii) request rectification or erasure;
  - (iii) object to or restrict the processing of your personal data; and
  - (iv) request portability of your personal data. Additionally, if we have collected and processed your personal data with your consent, you have the right to withdraw your consent at any time.

If you wish to exercise your rights under the GDPR, CCPA, or other applicable data protection or privacy laws, please contact us at the address provided herein, specify your request, and reference the applicable law. We may ask you to verify your identity, or ask for more information about your request. We will consider and act upon any above request in accordance with applicable law. We will not discriminate against you for exercising any of these rights.

Notwithstanding the above, we cannot edit or delete any information that is stored on a blockchain, for example the Ethereum blockchain, as we do not have custody or control over any blockchains.

### DATA RETENTION[](#data-retention)

We may retain your data as long as you continue to use the Services, have an account with us, or for as long as is necessary to fulfill the purposes outlined in this Privacy Policy. We may continue to retain your data even after you deactivate your account and/or cease to use the Service if such retention is reasonably necessary to comply with our legal obligations, to resolve disputes, prevent fraud and abuse, enforce our Terms or other agreements, and/or protect our legitimate interests. Where your data is no longer required for these purposes, we will delete it.

### DATA SECURITY[](#data-security)

We use appropriate technical and organizational measures to prevent accidental or intentional manipulation, partial or total loss, destruction or unauthorized access to your data by third parties. Our security measures are continuously improved in line with technological developments. Furthermore, all service providers commissioned by us are obliged by means of appropriate contractual agreements to take appropriate measures in accordance with the current state of the art to prevent the aforementioned risks.

Please be aware that, despite our reasonable efforts to protect your information, no security measures are perfect or impenetrable, and we cannot guarantee "perfect security." Please further note that any information you send to us electronically, while using the Services or otherwise interacting with us, may not be secure while in transit. We recommend that you do not use unsecure channels to communicate sensitive or confidential information to us. ​You are responsible for the security of your digital wallet(s), and urge you to take steps to ensure it is and remains secure.

In the event that any information under our custody and control is compromised as a result of a breach of security, we will take steps to investigate and remediate the situation and, in accordance with applicable laws and regulations, notify those individuals whose information may have been compromised.

### Rights of Data Subjects under GDPR[](#rights-of-data-subjects-under-gdpr)

This section applies to you if you are able to avail yourself of certain rights under GDPR.

a)        Right to information, rectification, deletion as well as rights to restriction of processing or transfer of your data to another body

You have the right to request information (Art. 15 GDPR) about your personal data and related information. In addition, you can request the correction (Art. 16 GDPR) and the deletion (Art. 17 para. 1 GDPR) of your personal data. You can also request that the processing of  your personal data  be restricted (Art. 18 GDPR). Furthermore, you have the right to receive your personal data from the responsible body  or to have it transmitted to another responsible body  (Art. 20 GDPR).

b)        Revocation of consent to data processing

You can revoke your consent in accordance with Art. 6 (1) sentence 1 (a) GDPR  at any time with immediate effect in accordance with Art. 7 (3) sentence 1 GDPR. Please note that data processing that took place before the revocation is not affected by the revocation and is therefore lawful despite the revocation. If you would like to make use of your right of objection, a simple notification to the person listed under no. 1.

c)        Objection to profiling and direct marketing

In certain cases, you also have the right to object (Art. 21 GDPR) to the data processing.

In particular, you have the right to object at any time to the processing of your data (in particular in the case of so-called profiling) based on Art. 6 (1) sentence 1 (f) GDPR (data processing on the basis of a balancing of interests) or Art. 6 (1) sentence 1 (i) GDPR (data processing in the public interest) in accordance with Art. 21 (1) GDPR. We will then no longer process your personal data for these purposes, unless we can demonstrate compelling legitimate grounds for the processing which override the interests, rights and freedoms of the data subject, or the processing serves to establish, exercise or defend legal claims.

If your personal data is processed for direct marketing, you can also object to the processing of your data for the purpose of direct marketing at any time in accordance with Art. 21 para. 2 GDPR, including profiling, insofar as it is related to such direct marketing. If you object, your personal data will no longer be used for these direct marketing purposes.

d)        Right to lodge a complaint with the competent data protection supervisory authority

If you believe that we have not complied with data protection regulations when processing your data, you can submit a complaint to the supervisory authority responsible for us. The indication of the supervisory authority is not a mandatory part of the privacy policy.

### HOW TO CONTACT US[](#how-to-contact-us)

​Should you have any questions about our privacy practices or this Privacy Policy, please email us at [finance@ethenalabs.xyz](mailto:finance@ethenalabs.xyz).

.

Last updated 1 year ago

Was this helpful?