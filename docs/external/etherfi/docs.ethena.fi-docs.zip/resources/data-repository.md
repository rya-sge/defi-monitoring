# Data Repository

> Source: https://docs.ethena.fi/resources/data-repository

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/data-repository.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# Data Repository

Repository for data related questions

## Data Link[](#data-link)

Link to the full FAQ [here](https://www.notion.so/ethena/Ethena-Chartbook-c35c316346ee4c7e97aff49a9eadd87e?pvs=4).

[![Logo](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2Fwww.notion.so%2Ffront-static%2Flogo-ios.png&width=20&dpr=3&quality=100&sign=e6712e85a03aaaf40a4c77fd8e7699ef&sv=3)Ethena Chartbook | Notionethena on Notion](https://www.notion.so/ethena/Ethena-Chartbook-c35c316346ee4c7e97aff49a9eadd87e?pvs=4)

Last updated 2 years ago

Was this helpful?