# USDe Terms and Conditions

> Source: https://docs.ethena.fi/resources/usde-terms-and-conditions

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/resources/usde-terms-and-conditions.md).CopyOn this page
1. [Resources](https://docs.ethena.fi/resources)

# USDe Terms and Conditions

These Terms and Conditions Apply To All Users

Last Updated: August 2025

Users who have completed Know-Your-Customer and Anti-Money Laundering checks, as well as other onboarding procedures, and are whitelisted with Ethena BVI Limited (“Ethena BVI”) are referred to herein as a “Mint User.” To the extent you have not completed the aforementioned checks or been whitelisted but hold USDe, these Terms still apply to your holding and use of USDe (hereinafter referred as “Holding User”). For the avoidance of doubt, Holding Users are not customers of Ethena BVI.

By obtaining and using USDe, you understand and expressly agree to these Terms, regardless of whether or not you are a customer of Ethena BVI, and you acknowledge that you have reviewed and understand each of the disclosures made in this section. Any provisions of these Terms that only apply to Mint Users or Holding Users will be specifically noted herein. Unless so noted, each Section of these Terms apply to both Mint Users and Holding Users, and any use of “you” or “your” refers to both Mint Users and Holding Users. The terms herein applicable to Mint Users are supplemental to the terms in the USDe Mint User Agreement.

By holding or using USDe, or using any of the USDe Services, you agree that you have read, understood and accept all of the terms and conditions contained in these Terms, as well as our Privacy Policy and Cookie Policy, and you acknowledge and agree that you will be bound by these terms and policies.

Section 22 of these Terms governs how these Terms may be changed over time; the date of the last update is set forth at the top of these Terms.

**1. About USDe**

USDe is a digital token issued by Ethena BVI. USDe issued by Ethena BVI is a form of stored value or prepaid access and does not represent a claim, participation interest, economic right, voting right, or other similar right associated with Ethena BVI or any of its affiliates.

USDe is backed by an amount of spot crypto assets, such as BTC, ETH, SOL, certain liquid staking tokens, certain stablecoins (such as USDC, USDT, and USDtb), and offsetting hedging positions on derivatives contracts the (“USDe Reserves”).

Unaffiliated third parties, including the Ethena Foundation directly and via the Ethena Risk Committee, provide input on certain parameters associated with the USDe Reserves. The Ethena Foundation does not have any members, ultimate beneficial owners, or beneficiaries, and exists with the principal objects of supporting the Ethena Protocol and its architecture. No shareholders, employees, contractors, ultimate beneficial owners, or other party affiliated with Ethena BVI or its affiliates holds a position of ownership or control with respect to the Ethena Foundation.

USDe is not designed to intrinsically create returns for holders, increase in value, or otherwise accrue financial benefit to the USDe holder.

**2. Scope of USDe and Key Terms**

The following only applies to Mint Users: As you have agreed to, and are subject to, the USDe Mint User Agreement, Ethena BVI makes available the following USDe-related Services (as defined in the USDe Mint User Agreement: (i) create USDe in exchange for accepted tokens from Ethena BVI, and (ii) redeem USDe for supported assets from Ethena BVI (collectively, the “USDe Services”). Your use of the USDe Services is subject to these Terms. Any of the USDe Services can be discontinued at any time in accordance with Section 14 of these USDe Terms.

You understand and agree that you may only utilize accepted assets to create USDe and redeem USDe directly with Ethena BVI to the extent that you are a Mint User.

The following only applies to Holding Users: You may not redeem USDe with Ethena BVI unless and until you are a Mint User who has cleared KYC/AML and other checks and have onboarded as a whitelisted customer with Ethena BVI. Eligibility for and requirements related to such process are set forth in the USDe Mint User Agreement.

The following applies to both Mint Users and Holding Users: Your use of USDe and USDe Services (as applicable), is subject to these Terms and Ethena BVI’s obligations hereunder are conditional on you complying with its provisions. You understand that any violation of these Terms may result in potential consequences, including the possible loss or forfeiture of assets tokenized for USDe.

You understand and agree that sending USDe to another address automatically transfers and assigns to the owner of that address, and any subsequent owner all rights and obligations of a Holding User to redeem USDe for approved assets so long as the Holder is or becomes a Mint User. For the avoidance of doubt, if a Holder is not a Mint User, not eligible to become a Mint User, or fails to do so, such Holding User is not entitled to redeem USDe with Ethena BVI.

Ethena BVI (or an affiliate designated by Ethena BVI) commits to redeem 1 USDe for the notional value relating to its pro rata portion of the USDe Reserves in supported digital assets, up to a maximum amount of 1 USD in notional value, subject to these Terms, applicable law, and any fees where applicable. While Ethena BVI may hold the USDe Reserves in interest-bearing accounts or other yield-generating instruments, you acknowledge that you are not entitled to any interest or other returns earned on such funds as either a Holding User or Mint User. USDe does not itself generate any interest or return for holders of USDe and only represents your right to redeem USDe as a Mint User, if you are one. If you are a Holding User, you do not have a right to redeem USDe with Ethena BVI.

**3. Applicable Laws and Regulations; AML and CTF**

Your holding and use of USDe, and any use of the USDe Services, is subject to the laws, regulations, and rules of any applicable governmental or regulatory authority, including, without limitation, all applicable tax, anti-money laundering (“AML”) and counter-terrorist financing (“CTF”) provisions and sanctions. You agree to act in compliance with and be legally bound by these Terms and all applicable laws and regulations. These Terms are conditional on your continued compliance at all times with these Terms and all applicable laws and regulations.

Ethena BVI is committed to complying with all applicable AML and CTF laws and regulations. These standards are designed to prevent the use of the USDe Services for money laundering, terrorist financing, fraudulent transactions, and any other illegal activities. Ethena BVI takes compliance very seriously and actively engages in measures to:

• Prohibit fraudulent transactions;

• Report suspicious activities;

• Prevent money laundering, terrorist financing, and any related acts that facilitate financial crimes.Applicable laws require us to prevent Restricted Persons from holding USDe or using USDe Services. A Restricted Person means any person that is the subject or target of any sanctions, including a person that is:

- named in any Sanctions-related list maintained by the U.S. Department of State; the U.S. Department of Commerce, including the Bureau of Industry and Security’s Entity List and Denied Persons List; or the U.S. Department of the Treasury, including the OFAC Specially Designated Nationals and Blocked Persons List, the Sectoral Sanctions Identifications List, and the Foreign Sanctions Evaders List; or any similar list maintained by any other relevant governmental authority;
- located, organized or resident in a country, territory or geographical region which is itself the subject or target of any territory-wide Sanctions (a “Restricted Territory”) (currently, Cuba, Iran, Syria, North Korea, and the Ukraine regions of Crimea, Donetsk, and Luhansk); or
- owned or controlled by any such person or persons listed above.

**4. Eligibility; Limitations**

The following applies to both Mint Users and Holding Users: USDe Services and support for USDe are currently only available to individuals and institutions (as applicable) located in supported jurisdictions.

By holding or using USDe, or accessing or using the USDe Services, you further represent and warrant that:

- you are at least 18 years old, are not a Restricted Person, and are not holding USDe on behalf of a Restricted Person.
- you will not be using USDe or the USDe Services (as applicable) for any illegal activity, including, but not limited to, illegal gambling, money laundering, fraud, blackmail, extortion, ransoming data, terrorism financing, other violent activities or any prohibited market practices, including, but not limited to, those listed under Sections 16 and 17.

Additionally, users in the United States are not eligible to become a Mint User. This restriction may be revisited from time to time taking into account relevant changes in law.

You also understand that there are additional representations and warranties made by you elsewhere in (or by reference in) these Terms and that any misrepresentation by you is a violation of these Terms.

If Ethena BVI suspects or determines that you or any of your authorized users or customers, as applicable, have violated these Terms, including, but not limited to, attempting to transact or transacting with Blocked Addresses (as defined in Section 11) or attempting to engage or engaging in Restricted Activities (as defined in Section 16) or Prohibited Transactions (as defined in Section 17), then Ethena BVI may be forced to terminate your status as a Mint User and you may forfeit any assets otherwise eligible for redemption.

Notwithstanding the foregoing, Ethena BVI may determine not to make USDe or the USDe Services, in whole or in part, available in every market, either in its sole discretion or due to legal or regulatory requirements, depending on your location. We may also, without liability to you or any third party, refuse to let you register as a Mint User.

The following only applies to Mint Users: Use of certain USDe Services may have further eligibility requirements that will need to be verified prior to you using such USDe Services, or from time to time in order to continue your use of the USDe Services, and may be subject to additional terms and conditions.

**5. Support**

Please contact Support to report any violations of these Terms or to ask any questions regarding these Terms or the USDe Services, as applicable.

**6. Copies, Wrappers, and Forks Not Supported**

The following applies to both Mint Users and Holding Users: As a result of the decentralized and open source nature of USDe it is possible that a party unaffiliated with Ethena BVI could create an alternative, equivalent version of USDe either on one of the USDe supported blockchains or on an unsupported blockchain (a “copy”) that operate independently from USDe. Similarly, it is possible that a party unaffiliated with Ethena BVI may create an asset and purport that such asset is collateralized by or otherwise incorporates USDe into its design (a “wrapper”). Ethena BVI supports only USDe and is under no obligation to support any copies of USDe or wrappers and assumes no responsibility for any value that might be lost as a result of this lack of support of copies of USDe. No such copy or wrapper should be considered approved, sold, distributed, or promoted by Ethena BVI unless explicitly stated.

As a result of the decentralized and open source nature of the blockchains on which USDe is supported, it is possible that a party unaffiliated with Ethena BVI could create an alternative version of the blockchain (a “fork”). Note that in the event of a fork of one of the USDe supported blockchains, Ethena BVI may be forced to suspend all activities relating to USDe (including tokenizing assets for USDe, redeeming USDe for supported assets, or sending and receiving USDe) for an extended period of time until Ethena BVI has determined in its sole discretion that such functionality can be restored (“Downtime”). This Downtime will likely occur immediately upon a “fork”, potentially with little to no warning, and during this period of Downtime you will not be able to conduct various activities involving USDe. In the event of a fork of one of the USDe supported blockchains, Ethena BVI shall, in its sole discretion, determine which fork it will support, if any.

**7. USDe Supported Blockchains and Smart Contract Modifications**

USDe operates on USDe supported blockchains. Ethena BVI does not have any ability or obligation to prevent or mitigate attacks or resolve any other issues that might arise with any USDe supported blockchain. Any such attacks or delays on any USDe supported blockchain might materially delay or prevent you from sending or receiving USDe, and Ethena BVI shall bear no responsibility for any losses that result from such issues.

Note that in certain circumstances, including, but not limited to, a copy or fork of a USDe supported blockchain or the identification of a security issue with a USDe supported blockchain, Ethena BVI may be forced to suspend all activities relating to USDe (including tokenizing assets for USDe, redeeming USDe for assets, or sending and receiving USDe) for an extended period of time until such Downtime is over and USDe Services can be restored. This Downtime will likely occur immediately upon a copy or fork of any USDe supported blockchain, potentially with little to no warning, and during this period of Downtime you will not be able to conduct various activities involving USDe.

Ethena BVI reserves the right to migrate USDe to another blockchain or protocol in the future in its reasonable discretion. Upon Ethena BVI’s request, you agree to take any and all actions reasonably necessary to effectuate the migration of your USDe to another blockchain or protocol identified by Ethena BVI. Ethena BVI will not be responsible or liable for any damages, losses, costs, fines, penalties or expenses of whatever nature, whether or not reasonably foreseeable by the parties, which you may suffer, sustain or incur, arising out of or relating to your failure to effectuate such migration of your USDe to another blockchain or protocol identified by Ethena BVI.

**8. Privacy**

We are committed to protecting your personal information and helping you understand exactly how your personal information is being used. You should carefully read the Ethena BVI Privacy Policy, as it provides details on how your personal information is collected, stored, protected, and used.

**9. Communications**

By entering into these Terms, you agree to receive electronic communications and notifications.

These Terms are provided to you and communicated in English. We will also communicate with you in English for all matters related to USDe and your use of USDe Services. Where we have provided you with a translation of the English language version of these Terms, you agree that such translation is provided for your convenience only and that the English language version of these Terms govern your holding and use of USDe, and the USDe Services, as applicable.

**10. Limited License; IP Rights**

The following only applies to Mint Users: We grant you a limited, non-exclusive, non-sublicensable, and non-transferable license, subject to the terms and conditions of these Terms, to access and use the USDe Services solely for approved purposes as determined by Ethena BVI. Any other use of the USDe Services is expressly prohibited. Ethena BVI and its licensors reserve all rights in the USDe Services and you agree that these Terms does not grant you any rights in or licenses to the USDe Services except for the limited license set forth above. Except as expressly authorized by Ethena BVI, you agree not to modify, reverse engineer, copy, frame, scrape, rent, lease, loan, sell, distribute, or create derivative works based on the USDe Services, in whole or in part. If you violate any portion of these Terms, your permission to access and use the USDe Services may be terminated pursuant to these Terms.

"ethena.fi", "Ethena BVI", and all logos related to the USDe Services are either copyrights, trademarks, or registered marks of Ethena BVI or its licensors. Whether or not you are a Mint User, you may not copy, imitate, or use them without Ethena BVI's prior written consent. All right, title, and interest in and to the Ethena BVI website, any content thereon, the USDe Services, and all technology and any content created or derived from any of the foregoing is the exclusive property of Ethena BVI and its licensors.

**11. Risk Factors & Disclosures**

The following list of risks associated with USDe and the USDe Services is not exhaustive.

No guarantee of price stability on Third Party Platforms

Ethena BVI does not guarantee that the value of one (1) USDe will always or ever equal 1 USD ($1) on any platform. Due to a variety of factors, the value of USDe on third-party platforms such as cryptocurrency exchange platforms could fluctuate above or below 1 USD ($1), and the risk factors highlighted at docs.ethena.fi (as well as presently unknown risk factors) may result in the USDe Reserves falling to less than 1 USD ($1) of notional value per USDe in circulation. Ethena BVI cannot control how third parties quote or value USDe, and Ethena BVI is not responsible for any losses or other issues that may result from fluctuations in the value of USDe.

Third-parties

Ethena BVI does not control or endorse any products, services, or platforms offered by third parties using the USDe Services or supporting USDe. Third parties may elect to support USDe on their platforms without any authorization or approval by Ethena BVI. The availability of USDe on any third-party platform does not imply that such services are valid, legal, stable, or otherwise appropriate.

Ethena BVI is not liable for any losses, issues, or consequences that may arise from third-party transactions or the use of USDe on third-party platforms, including, but not limited to, (i) Failure to comply with applicable laws and regulations, including illegal transactions;(ii) The quality, delivery, or satisfaction of products and services facilitated by USDe Services; (iii) Technical errors, loss of access, or inability to recover USDe resulting from the use of third-party platforms.

You accept all consequences of sending USDe to third-party platforms or addresses, including the risk of loss or failure to recover your USDe. For the avoidance of doubt, Ethena BVI has no obligation to track, verify, or determine the provenance of USDe balances or transactions involving third-party platforms.

You accept all consequences of sending USDe

USDe transactions are not reversible. Once you send USDe to an address, you accept the risk that you may lose access to, and any claim on, that USDe indefinitely or permanently. For example, (i) an address may have been entered incorrectly and the true owner of the address may never be discovered, (ii) you may not have (or subsequently lose) the private key associated with such address, (iii) an address may belong to an entity that will not return the USDe, or (iv) an address belongs to an entity that may return the USDe but first requires action on your part, such as verification of your identity. For the avoidance of doubt, nothing in these Terms is intended to obligate Ethena BVI to track, verify or determine the provenance of USDe balances for Users, including any form of security interests claimed thereon.

Blocked Addresses & Forfeited Funds

Ethena BVI reserves the right to “block” certain USDe addresses of Mint Users that it determines, in its sole discretion, may be associated with illegal activity or activity that otherwise violates these Terms (“Blocked Addresses”). In certain circumstances, Ethena BVI may deem it necessary to report such suspected illegal activity to applicable law enforcement agencies and you may forfeit any rights associated with your USDe, including the ability to redeem USDe for any permitted assets. Ethena BVI may also be required to surrender associated assets held in the USDe Reserve in the event it receives a legal order from a valid government authority requiring it to do so.

Software protocols and operational challenges

You are aware of and accept the risk of operational challenges. Ethena BVI may experience sophisticated cyber-attacks, unexpected surges in activity or other operational or technical difficulties that may cause interruptions to the USDe Services. You understand that the USDe Services may experience operational issues that lead to delays, including delays in redeeming USDe. You agree to accept the risk of transaction failure resulting from unanticipated or heightened technical difficulties, including those resulting from sophisticated attacks. You agree not to hold Ethena BVI accountable for any related losses.

Compliance

You are responsible for complying with applicable law. You agree that Ethena BVI is not responsible for determining whether or which laws may apply to your transactions, including tax laws. You are solely responsible for reporting and paying any taxes arising from your use of USDe or the USDe Services, including any accurate reporting of the tax or legal status of USDe in your jurisdiction.

Legal treatment of USDe transfers

The regulatory status of USDe and blockchain technology is unclear or unsettled in many jurisdictions. It is difficult to predict how or whether regulatory agencies may apply existing regulation with respect to USDe, blockchain technology and its applications. Accordingly, it is not possible to determine whether a USDe transfer would be recognized under applicable law by a court or regulator.

Legislative and regulatory changes

Legislative and regulatory changes or actions at the international level may adversely affect the tokenization of assets into USDe, and the use, transfer, redemption and/or value of USDe.

No deposit insurance

USDe held in your wallet is not subject to deposit insurance protection, including, but not limited to, (i) where your country of residence is the United States, the Federal Deposit Insurance Corporation (FDIC) insurance or Securities Investor Protection Corporation protections (SIPC); or (ii) where your country of residence is outside of the United States, the United Kingdom Financial Services Compensation Scheme (FSCS) or equivalent scheme in your country of residence.

Claim on funds

Only Mint Users can redeem USDe directly with Ethena BVI. For Mint Users, your ability to redeem with us for each USDe is conditional on (i) your possession of a corresponding amount of USDe associated with a Mint User, (ii) no violation of these Terms or your USDe Mint User Agreement, and (iii) no action, pending or otherwise, by a regulator, law enforcement or a court of competent jurisdiction that would restrict redemption.

Sending USDe to another address automatically transfers and assigns to that Holding User, and any subsequent Holding User, the right to redeem USDe with us so long as the Holding User is eligible to, and does, register as a Mint User (and thereby becomes a Mint User).

Encumbrances

Depending on the actions of the owners of USDe addresses before your receipt of USDe from another USDe address, it is possible that the transfer of USDe between USDe addresses could result in the USDe in your whitelisted wallet becoming subject to a lien or other form of security interest before redemption.

On-chain transactions irreversible

When USDe is sent to a third-party USDe address, such transaction is completed on USDe supported blockchains. This means that such a transaction is irreversible and Ethena BVI does not have the ability to reverse or recall any transaction once initiated. You bear all responsibility for any losses that might be incurred as a result of sending USDe to an incorrect or unintended USDe address.

Affiliate Activities

You understand and agree that individuals or entities affiliated with Ethena BVI may hold, purchase, sell, or otherwise engage in transactions using or involving USDe. You further understand and agree that such persons may engage in this activity for any reason, including but not limited to engaging in commercial transactions, promoting transaction activity that utilizes USDe, or otherwise supporting the use or adoption of USDe. This activity may involve selling USDe to other entities for provision to their end users. You understand and agree that no individual or entity, whether affiliated with Ethena BVI or otherwise, is under any obligation to engage in these activities, and they may be discontinued at any time.

**12. Fees; Authorization**

The following only applies to Mint Users: Except as disclosed to you prior to completing a transaction as a Mint User, Ethena BVI will not charge you any fees for tokenizing assets for USDe, or receiving USDe. Any cost of executing a mint or redemption transaction is a cost reimbursement to cover friction such as blockchain gas fees or execution fees paid by Ethena BVI.

**13. Currency Conversion**

The following only applies to Mint Users: All tokenizations of assets will be credited in USDe to your whitelisted wallet(s) based on a rate of one (1) USDe per 1 USD ($1) of notional value (measured in stablecoin value, i.e., 1 USDC, 1 USDT, or 1 USDtb, as the case may be, depending on the asset exchanged to mint USDe), less applicable fees and transaction costs associated with the transaction, including, for the avoidance of doubt, fees paid associated with the applicable blockchain consensus mechanism. Such value shall be calculated by Ethena BVI based on the asset in its sole discretion, with any transaction fees associated with the blockchain consensus mechanism determined by requirements of the underlying blockchain at the time the transaction is submitted by the Mint User.

**14. Right to Change/Remove Features or Suspend/Delay Transactions**

The following only applies to Mint Users: We reserve the right to (i) change, suspend, or discontinue any aspect of the USDe Services at any time, including hours of operation or availability of any feature, without notice and without liability and (ii) decline to process any issuance or redemption without prior notice and may limit or suspend your use of one or more USDe Services at any time, in our sole discretion. Our rights under this paragraph are subject to our obligations under applicable law and licenses, including but not limited to our reasonable suspicion of inappropriate or illegal conduct. Suspension of your use of any of the USDe Services will not affect your rights and obligations pursuant to these Terms. We may, in our sole discretion, delay issuances or redemptions if we reasonably believe the transaction is suspicious, may involve fraud or misconduct, violates applicable laws, or violates the terms of these Terms.

**15. Transactions Irreversible**

The following only applies to Mint Users: Once a transaction has been initiated, it cannot be reversed, as further described in Section 11 above and pursuant to the underlying blockchain consensus mechanism. Except as set forth in these Terms, all transactions processed through the USDe Services are nonrefundable.

**16. Restricted Activities**

In connection with your holding or use of USDe, or the USDe Services (as applicable), you hereby agree that you will not:

- violate (or assist any other party in violating) any applicable law, statute, ordinance, or regulation;
- intentionally try to defraud (or assist in the defrauding of) Ethena BVI or other Mint Users or Holding Users;
- provide false, inaccurate, or misleading information;
- take any action that interferes with, intercepts, or expropriates any system, data, or information;
- partake in any transaction involving the proceeds of illegal activity;
- transmit or upload any virus, worm, or other malicious software or program;
- attempt to gain unauthorized access to the Ethena BVI website, or any related networks or systems;
- use the USDe Services on behalf of any third party or otherwise act as an intermediary between Ethena BVI and any third parties;
- collect any information from other Mint Users or Holding Users, including, without limitation, email addresses;
- defame, harass, or violate the privacy or intellectual property rights of Ethena BVI or any Holding Users or Mint Users; or
- upload, display or transmit any messages, photos, videos or other media that contain illegal goods, violent, obscene or copyrighted images or materials (such activities, “Restricted Activities”).

**17. Prohibited Transactions**

Using USDe or the USDe Services for transactions related to the following is prohibited, and Ethena BVI reserves the right to monitor and, if appropriate, block or otherwise prevent transactions that relate to:

- any Restricted Persons;
- weapons of any kind, including but not limited to firearms, ammunition, knives, explosives, or related accessories;
- controlled substances, including but not limited to narcotics, prescription drugs, steroids, or related paraphernalia or accessories, unless licensed and authorized by the jurisdiction in which the User is based as well as by the jurisdiction in which the transaction takes place;
- gambling activities including but not limited to sports betting, casino games, horse racing, dog racing, games that may be classified as gambling (i.e. poker), or other activities that facilitate any of the foregoing, unless licensed and authorized by the jurisdiction in which the User is based as well as by the jurisdiction in which the transaction takes place;
- money-laundering or terrorist financing;
- any sort of Ponzi scheme, pyramid scheme, or multi-level marketing program;
- goods or services that infringe or violate any copyright, trademark, or proprietary rights under the laws of any jurisdiction;
- credit repair services, or other services that may present consumer protection risks;
- court ordered payments, structured settlements, tax payments, or tax settlements;
- any unlicensed money transmitter activity;
- layaway systems, or annuities;
- counterfeit goods, including but not limited to fake or “novelty” IDs;
- wash trading, front-running, insider trading, market manipulation or other forms of market-based fraud or deceit;
- purchasing goods of any type from “Darknet” markets, or any other service or website that acts as a marketplace for illegal goods (even though such marketplace might also sell legal goods); or
- any other matters, goods, or services that from time to time we communicate to you that are unacceptable and which, for example, may be restricted by our and your bank or payment partners (such transactions, “Prohibited Transactions”).

In the event that Ethena BVI learns you are making any such Prohibited Transactions, Ethena BVI will consider you to be a violation of these Terms and may also suspend or terminate your status as a Mint User.

**18. Taxes**

The following only applies to Mint Users: Ethena BVI will maintain a record of your transaction history pursuant to the terms of the USDe Mint User Agreement. This transaction history will include all transactions you complete with Ethena BVI including tokenizing assets for USDe and redeeming USDe for assets.

**19. Indemnification; Release**

The following only applies to Mint Users: Section 22 of the USDe Mint User Agreement is hereby incorporated into these Terms by reference and shall apply in all respects to these Terms and your use of USDe Services and our products and services as contemplated herein.

The following only applies to Holding Users: You agree to indemnify and hold Ethena BVI, its affiliates, and service providers, and each of their officers, directors, agents, joint venturers, employees, and representatives harmless from any claim or demand (including attorneys’ fees and any losses, fines, fees or penalties imposed by any regulatory authority) arising out of your breach of these Terms, your violation of any law or regulation or your holding or use of USDe.

For the purpose of this Section 19, the term “losses” means all net costs reasonably incurred by us or the other persons referred to in this Section which are the result of the matters set out in this Section 19 and which may relate to any claims, demands, causes of action, debt, cost, expense or other liability, including reasonable legal fees (without duplication).

If you have a dispute with one or more Mint Users, Holding Users or third parties, you release Ethena BVI (and its affiliates and service providers, and each of their officers, directors, agents, joint ventures, employees and representatives) from all claims, demands, and damages (actual and consequential) of every kind and nature arising out of or in any way connected with such disputes.

**20. Limitation of Liability; No Warranty**

The following only applies to Mint Users: Section 23 of the USDe Mint User Agreement is hereby incorporated into these Terms by reference and shall apply in all respects to these Terms and your use of USDe Services and our products and services as contemplated herein.

The following only applies to Holding Users: YOU EXPRESSLY UNDERSTAND AND AGREE THAT ETHENA BVI AND OUR AFFILIATES AND SERVICE PROVIDERS, AND THEIR RESPECTIVE OFFICERS, DIRECTORS, AGENTS, JOINT VENTURERS, EMPLOYEES, AND REPRESENTATIVES WILL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY DAMAGES, OR DAMAGES FOR LOSS OF PROFITS INCLUDING BUT NOT LIMITED TO, DAMAGES FOR LOSS OF GOODWILL, USE, DATA, OR OTHER INTANGIBLE LOSSES (EVEN IF ETHENA BVI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES), WHETHER BASED ON CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY, OR OTHERWISE, RESULTING FROM: (I) THE USE OR THE INABILITY TO HOLD OR USE USDe; (II) THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES RESULTING FROM ANY GOODS, DATA, INFORMATION, OR SERVICES PURCHASED OR OBTAINED OR MESSAGES RECEIVED OR TRANSACTIONS ENTERED INTO INVOLVING USDe; (III) UNAUTHORIZED ACCESS TO OR ALTERATION OF YOUR TRANSMISSIONS OR DATA; OR (IV) ANY OTHER MATTER INVOLVING USDe.

SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF CERTAIN WARRANTIES OR THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES. ACCORDINGLY, SOME OF THE LIMITATIONS SET FORTH ABOVE MAY NOT APPLY TO YOU. IF YOU ARE DISSATISFIED WITH USDe, YOUR SOLE AND EXCLUSIVE REMEDY IS TO DISCONTINUE HOLDING AND USE OF USDe.

USDe IS PROVIDED "AS IS" AND WITHOUT ANY REPRESENTATION OR WARRANTY, WHETHER EXPRESS, IMPLIED OR STATUTORY. ETHENA BVI, OUR AFFILIATES, AND OUR RESPECTIVE OFFICERS, DIRECTORS, AGENTS, JOINT VENTURERS,EMPLOYEES, AND SUPPLIERS SPECIFICALLY DISCLAIM ANY IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. ETHENA BVI MAKES NO WARRANTY THAT (I) USDeWILL MEET YOUR REQUIREMENTS, (II) USDe WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE, OR (III) THE QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL PURCHASED OR OBTAINED BY YOU WILL MEET YOUR EXPECTATIONS.

**21. Force Majeure**

Ethena BVI shall have no liability for any failure or delay resulting from any condition beyond our reasonable control, including but not limited to governmental action or acts of terrorism, earthquake, fire, flood, or other acts of God, labor conditions, power failures, equipment failures, and Internet disturbances.

**22. Amendments**

Ethena BVI may amend any portion of these Terms at any time by posting the revised version of these Terms with an updated revision date. The changes will become effective, and shall be deemed accepted by you, the first time you access or use USDe or the USDe Services after the initial posting of the revised Terms and shall apply on a going-forward basis with respect to transactions initiated after the posting date. In the event that you do not agree with any such modification, your sole and exclusive remedy is to terminate your use of the USDe Services and terminate your status as a Mint User (if any). You agree that we shall not be liable to you or any third party as a result of any losses suffered by any modification or amendment of these Terms.

If the revised Terms include a material change, we will provide you with prior notice via our website and/or email before the material change becomes effective. For this purpose a “material change” means a significant change other than changes that (i) are to your benefit, (ii) are required to be made to comply with applicable laws and/or regulations or as otherwise required by one of our regulators, (iii) relates to a new product or service made available to you, or (iv) otherwise clarifies an existing term.

**23. Assignment and Third-Party Holders**

You may not transfer or assign these Terms or any rights or obligations hereunder, by operation of law or otherwise and any such attempted assignment shall be void, subject to the following exception. Sending USDe to an address will automatically transfer and assign to that Holder, and any subsequent Holder, the right to redeem USDe for USD so long as the Holder is eligible to, and does, register as a Mint User.

Each Holding User is subject to all terms of these Terms as if a user including, but not limited to, the requirements to not transact with Blocked Addresses and not engage in Restricted Activities or Prohibited Transactions.

We reserve the right to freely assign these Terms and the rights and obligations of these Terms to any third party at any time without notice or consent. If you object to such transfer or assignment, you may stop holding and using USDe; further if you are a Mint User, you may also stop using our USDe Services, and terminate these Terms by contacting Support and asking us to terminate your status as a Mint User.

**24. Survival**

Upon termination of these Terms (and termination of your status as a Mint User, if you are a Mint User), all rights and obligations of the parties that by their nature are continuing will survive such termination.

**25. Website; Third Party Content**

Ethena BVI strives to provide accurate and reliable information and content on the Ethena BVI website, but such information may not always be correct, complete, or up to date. Ethena BVI will update the information on the Ethena BVI website as necessary to provide you with the most up to date information, but you should always independently verify such information. The Ethena BVI website may also contain links to third-party websites, applications, events or other materials (“Third Party Content”). Such information is provided for your convenience and links or references to Third Party Content do not constitute an endorsement by Ethena BVI of any products or services. Ethena BVI shall have no liability for any losses incurred as a result of actions taken in reliance on the information contained on the Ethena BVI website or in any Third Party Content.

**26. Governing Law; Venue**

The laws of the British Virgin Islands shall govern these Terms. The courts of the British Virgin Islands shall have exclusive jurisdiction to settle any dispute arising out of, or connected with, these Terms.

**27. Entire Agreement**

The following applies to both Mint Users and Holding Users: The failure of Ethena BVI to exercise or enforce any right or provision of these Terms shall not constitute a waiver of such right or provision. If any provision of these Terms shall be adjudged by any court of competent jurisdiction to be unenforceable or invalid, that provision shall be limited or eliminated to the minimum extent necessary so that these Terms shall otherwise remain in full force and effect and remain enforceable between the parties, except as specified in Section 27. Furthermore, if any portion of these Terms, whether in whole, or in part, shall be adjudged by any court of competent jurisdiction to be unenforceable or invalid against certain persons or categories of persons that are purportedly bound by these Terms, such portion of these Terms shall otherwise remain in full force and effect and remain enforceable as to any other persons bound by these terms. The headings and explanatory text are for reference purposes only and in no way define, limit, construe, or describe the scope or extent of such section. These Terms, the USDe Mint User Agreement, the General Terms of Service, and Ethena BVI’s policies governing the holding or use of USDe, the use of the USDe Services referenced herein, and the Privacy Policy t constitute the entire agreement between you and Ethena BVI with respect to the holding or use of USDe, and the use of the USDe Services. These Terms are not intended and shall not be construed to create any rights or remedies in any parties other than you and Ethena BVI and other Ethena BVI affiliates which each shall be a third-party beneficiary of these Terms, and no other person shall assert any rights as a third-party beneficiary hereunder.

The following only applies to Mint Users: Notwithstanding anything to the contrary set forth in these Terms or otherwise, in the event of a conflict between any term set forth herein and any term set forth in the USDe Mint User Agreement (i) in connection with any USDe transaction, the terms of these Terms shall control, and (ii) in respect of any other Digital Currency transaction, the terms of the USDe Mint User Agreement shall control.

**28. E-Sign Consent**

Please be aware that your consent to the electronic delivery of disclosures is required to use any of the Services (as defined in the USDe Mint User Agreement). If you are unable or unwilling to provide such consent, you will not be able to become a Mint User. Once you are a Mint User you can rescind your consent to electronic delivery of disclosures at any time and receive paper communications as set forth below.

This E-Sign Consent applies to any and all communications and/or disclosures that Ethena BVI is legally required to provide to you in writing in connection with your status as a Mint User and any related products and services (“Communications”). This E-Sign Consent supplements and is to be construed in accordance with the terms and conditions contained in the USDe Mint User Agreement.

When you use the Services, you agree that we may provide you with any Communications in electronic format, and that we may discontinue sending paper Communications to you, unless and until you withdraw your consent as described below. Your consent to receive electronic communications and transactions includes, but is not limited to:

- Legal and regulatory disclosures and communications associated with your registration or the Services;
- Notices or amendments relating to the USDe Mint, User Agreement, the Privacy Policy, the Cookie Policy or this E-Sign Consent;
- Communications regarding any transactions; and
- Responses to claims filed in connection with your relationships with Ethena BVI as a Mint User.

Methods of Communication

All Communications that we provide to you in electronic form will be provided by e-mail, by posting to the Ethena BVI website (USDe.money), or through other electronic communication such as mobile push notification or text message.

Hardware Requirements

In order to access, view, and retain electronic Communications that we make available to you, you must have the following software and hardware:

- A valid e-mail address.
- A computer or other device capable of accessing the internet with a current web browser that supports at least 128 bit encryption, such as Google Chrome, Apple® Safari, Microsoft® Internet Explorer, or Mozilla Firefox®. The browser must have cookies enabled.
- The computer must also have a printer or disk drive to print or retain copies of this E-Sign Consent and any Communications.

Updating your Information

It is your responsibility to provide us with a true, accurate and complete e-mail address, your contact information, and other information related to this E-Sign Consent and your registration, keep such information up to date.

Withdrawing Consent

You may withdraw your consent to receive electronic Communications at any time by sending us a written request by email. You understand that any withdrawal of your consent to receive electronic Communications will be effective only after Ethena BVI has had a reasonable period of time to process your withdrawal. You understand that withdrawing your consent to electronic Communications will likely result in the termination of your status as a Mint User.

Communications in Writing

All electronic Communications from us to you will be considered "in writing" and shall have the same meaning and effect as a paper Communication. You should print or download for your records a copy of this E-Sign Consent and any other Communication that is important to you. You acknowledge and agree that Communications are considered received by you within 24 hours of the time posted to the Ethena BVI website (USDe.money), or within 24 hours of the time emailed to you unless Ethena BVI receives notice that the email was not delivered.

General

Ethena BVI reserves the right, in our sole discretion, to cancel this electronic Communication service, or to terminate or change the terms and conditions on which Ethena BVI provides electronic Communications. Ethena BVI will provide you with notice of any such termination or change as required by law.

Last updated 9 months ago

Was this helpful?