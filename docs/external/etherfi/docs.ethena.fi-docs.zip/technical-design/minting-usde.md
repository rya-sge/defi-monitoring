# Minting USDe

> Source: https://docs.ethena.fi/technical-design/minting-usde

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/minting-usde.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Minting USDe

The genesis of USDe

"Minting" *USDe* refers to the creation of new synthetic dollars. "Redeeming" *USDe* is the reversal process, of exchanging synthetic dollars for the assets that collateralize them.

The methods of minting vary depending on the type of stablecoin/synthetic dollar. Here we will explore the novel Ethena synthetic dollar minting process.

The Ethena synthetic dollar minting system encompasses the following design principles:

### How does it work?[](#how-does-it-work)

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252FCsYMaHx5s8vXBguYWd3b%252Fminting.png%3Falt%3Dmedia%26token%3Dbfc2d305-95bd-4736-84f4-80fd75620e1c&width=768&dpr=3&quality=100&sign=c20d84a5e74b8fcbfa47e7f2378402af&sv=3)
1. Users request a price from the Ethena Pricing API.
2. Users can generate a signed [EIP712](https://eips.ethereum.org/EIPS/eip-712) order and optionally submit it to Ethena's minting server.

  - **Note**: at this stage, users have complete control over their assets - they have the freedom to create, hold, and sign the price at their discretion. The approval to transfer assets only happens when the user willingly signs the order.
3. Once the signed order is received, Ethena's server checks that the user has the required asset balance and signed approvals and that the dynamic hedging server can currently handle the order. Part of this involves communicating with the OES solution to prepare for the incoming mint or redemption request.

  - **Note**: Ethena does have the ability to reject an order based on these conditions. However, even in this centralized part of the process, the protocol could never alter the contents of the signed order due to the immutability of blockchain cryptographic signatures. This design ensures that the user's order - the backing asset, its size, any included slippage, and the synthetic dollars to be minted - remains as the user intended.
4. The order is sent to the blockchain with the atomic mint function called when these checks are passed. As above both the transfer of the user's assets and the minted synthetic dollars happen in a single transaction.
5. Upon success the hedging system actions the mint events to ensure the delta neutrality of the protocol's overall backing. Read more about these concepts in the [Hedging System](https://docs.ethena.fi/technical-design/hedging-system)and[Backing Asset Custody](https://docs.ethena.fi/backing-custody-and-security/backing-asset-custody)sections.

By blending centralized and decentralized elements in this way, Ethena achieves a relatively high level of trustlessness. Users always retain control over their assets prior to mint and their orders will be processed exactly as specified. And while Ethena has some control over order acceptance, the blockchain's transparency and cryptographic guarantees mean users can confidently engage with the protocol, knowing their transactions are secure and unalterable.

### Slippage [](#slippage)

Slippage occurs when the price at which a trade is executed differs from the expected price, usually due to market volatility or trade size.

Ethena has designed its minting process to minimize slippage for users. Before submitting a minting transaction, users receive a "price" from the Ethena Pricing API that includes a predefined slippage range. The user then signs this price, confirming their acceptance of the potential variation within the specified range.

When the transaction is executed, the smart contract logic ensures that the final minting settlement price falls within the signed slippage range. This approach provides users with a level of certainty about the price they will receive and makes the transaction predictable.

Slippage management is a key part of Ethena's minting design strategy, aiming to provide users with a more stable and transparent transaction experience.

### Audit[](#audit)

The Ethena Minting Contracts are regularly audited. See the section for up-to-date information.

---

### Quick Answers[](#quick-answers)

***Q: Am I only able to get USDe via minting USDe with Ethena?***

No, you can acquire *USDe *initially via decentralized protocols such as Curve and Uniswap as well as buy & sell USDe on Centralized Exchanges such as Binance, OKX and Bybit.

Last updated 1 year ago

Was this helpful?