# Matrix of Multisig and Timelocks

> Source: https://docs.ethena.fi/technical-design/key-trust-assumptions/matrix-of-multisig-and-timelocks

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/key-trust-assumptions/matrix-of-multisig-and-timelocks.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Key Trust Assumptions](https://docs.ethena.fi/technical-design/key-trust-assumptions)

# Matrix of Multisig and Timelocks

Transparency on the role of the multisig

> Ethena is required to implement safeguards in order to provide connective tissue between DeFi and centralized liquidity venues. The multisig is used to minimize these trust assumptions for core onchain functions.

**Roles**

**Multi sig**

**Number of role**

**Functions**

**Notes**

**Owner**

Yes, Ethena org

1

transferOwnership, add/remove supported collateral asset, add/remove custodian addresses, setUSDe address

If desired, owner and admin can be different multi sigs

setUSDe address is redundant, to be removed

**Admin**

Yes, Ethena org

1

grant/revoke Minter, Redeemer, Gatekeeper roles

**Gatekeepers**

No, EOA controlled by Ethena plus external trusted organisations

At least 3

Disable mint/redeem functionality, remove Minter, Redeemer roles

Will include external trusted organisations to be gatekeepers. Limits damage on mint/redeem roles compromise. Disables mint/redeems when they execute at incorrect prices on chain.

**Minter**

No, EOA controlled by Ethena

20

- `mint()`
- `transferToCustody`

Mint/Redeemer roles to be the same set of 20 addresses. This is to ensure the system can handle a high load of mint transaction concurrently.

**Redeemer**

No, EOA controlled by Ethena

20

- `redeem()`

Mint/Redeemer roles to be the same set of 20 addresses. This is to ensure the system can handle a high load of mint transaction concurrently.

Last updated 2 years ago

Was this helpful?