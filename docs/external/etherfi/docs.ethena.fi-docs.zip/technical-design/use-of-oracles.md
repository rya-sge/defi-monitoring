# Use of Oracles

> Source: https://docs.ethena.fi/technical-design/use-of-oracles

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/use-of-oracles.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Use of Oracles

## Overview[](#overview)

"Oracles" typically refer to price feeds a protocol utilizes to perform key business logic and functions. Ethena utilizes price feeds from various sources given the importance of real-time data to trading & risk workflows which exist offchain.

The system is split between onchain and offchain components.

### Price Feeds & Ethena's Offchain Systems[](#price-feeds-and-ethenas-offchain-systems)

Ethena  relies on price feeds in order to price the **mint** and **redeem** *USDe* requests per the available derivatives market liquidity as well as manage the risk of derivatives positions. Real-time data feeds indicate not only where the system delegates protocol assets, but the various risk profiles between the exchanges.

With this in mind, it's critically important that Ethena has access to & is constantly consuming real-time price feeds, especially from where it matters most; the exchanges where the system holds derivatives positions due to their margin requirements.

Ethena consumes real-time pricing information from three primary sources:

1. CeFi Exchanges such as Binance, Bybit, Okx, Deribit, Bitmex and Bitget.
2. [Pyth](https://pyth.network/).
3. [Redstone](https://redstone.finance/)

This real-time data is used extensively throughout the system to apply business logic, but to also ensure the integrity of all actions.

In that way, the system relies heavily upon CeFi Exchange price feeds, given the volume-weighted importance of their traded instruments, and also upon Pyth and Redstone to validate internal pricing throughout the system and before every single **mint** and **redeem** *USDe* request is accepted by Ethena. This ensures thorough checks for any inconsistency and protect the protocol from manipulation that might be occurring from one/multiple sources.

Ethena is constantly working to provide the resilience and integrity of price sources and evaluating other low latency offchain pricing services.

Last updated 1 year ago

Was this helpful?