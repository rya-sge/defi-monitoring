# Staking Key Functions

> Source: https://docs.ethena.fi/technical-design/staking-usde/staking-key-functions

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/staking-usde/staking-key-functions.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Staking USDe](https://docs.ethena.fi/technical-design/staking-usde)

# Staking Key Functions

Important functions of the staking smart contract

## Overview[](#overview)

The Ethena Staking contract is an extension of the [ERC4626 Token Vault standard](https://ethereum.org/en/developers/docs/standards/tokens/erc-4626/) with the added ability for a cooldown period upon unstaking as well as a legally required ability to freeze funds for sanctioned addresses.

## Roles in the Ethena Staking contract[](#roles-in-the-ethena-staking-contract)

There are three roles in the Ethena Staking contract:

- `DEFAULT_ADMIN_ROLE`
- `Rewarder`
- `Blacklister`

You are able to view the deployed Ethena Staking contract on the Ethereum blockchain **here.**

`DEFAULT_ADMIN_ROLE`

The `DEFAULT_ADMIN_ROLE` is able to perform a number of operations:

- It can set `setCooldownDuration`, up to a maximum value of 90 days from the unstaking request. The cooldown period is the time period from the unstaking request until the user is able to withdraw *USDe*.
- It can rescue tokens using `rescueTokens` to move any ERC20 tokens (**except** ***USDe***) to an address Ethena Labs controls. This has been implemented in case a user accidentally sends non-*USDe *assets to the Ethena Staking contract.
- It can redistribute *sUSDe *tokens that have been locked using `resdistributeLockedAmounts.` Locks on *sUSDe *held in specific wallets have been implemented due to legal requirements to ensure sanctioned, criminal, and other high-risk actors are not able to interact with the staking contract, in the interest of complying with Sanctions, Anti-Money Laundering, and Combating the Financing of Terrorism regimes. This is extremely similar functionality to what Circle implements for *USDC*. Ethena is able to redistribute funds to Ethena Labs addresses (in segregated wallets/vaults from other protocol assets) from fully restricted addresses. Note that this ability is limited to *sUSDe*.

`Rewarder`

The `Rewarder` role is able to transfer in `USDe` rewards, growing the balance of `USDe` in the Ethena Staking contract.

`Blacklister`

The `Blacklister` role is able to grant and remove `Soft_restricted_staking_role` or `Full_restricted_staking_role` assigned to an address. In practice, only `Full_restricted_staking_role`  has been utilized. "Fully Restricted Stakers" cannot receive sUSDe.

The user of the `Blacklister` role is only intended to ensure high-risk actors, such as sanctioned individuals, wallets associated with criminal activity/terrorism, and other similar individuals covered under relevant laws and regulations cannot access protocol yield. The blacklist will never be invoked at the discretion of Ethena Labs for any user absent those conditions or unless required by law enforcement pursuant to a court order, injunction, or similar official action we are required by law to comply with.

As noted above, this function is limited to *sUSDe*.

Last updated 1 year ago

Was this helpful?