# User Security Measures

> Source: https://docs.ethena.fi/technical-design/staking-usde/user-security-measures

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/staking-usde/user-security-measures.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Staking USDe](https://docs.ethena.fi/technical-design/staking-usde)

# User Security Measures

## Overview[](#overview)

A number of measures have been taken to ensure the integrity and resilience of the deployed smart contracts. These measures are designed principally to ensure the safety of protocol assets, but also to ensure reasonable governance occurs.

Below is a list of some, but not all, of the user security measures Ethena Labs has implemented across the deployed smart contracts.

## Measures[](#measures)

1. Inherited from the OpenZeppelin implementation of the battle-tested [ERC4626 Token Vault standard](https://ethereum.org/en/developers/docs/standards/tokens/erc-4626/). This enables users to have comfort that the protocol is inheriting audited & thoroughly used code throughout the space.
2. An unstake cooldown period where *sUSDe *tokens are immediately settled for *USDe*, but the staker cannot withdraw the *USDe *until the cooldown period has elapsed to prevent attacks in a single block.
3. Linear vesting of reward payments over 8 hours to prevent sandwich attacks where a user stakes immediately before and unstakes immediately after a reward payment at the expense of other stakers.
4. A minimum non-zero total *sUSDe *supply of 1 ether ($1 to start) to further prevent donation attacks beyond the protections the OpenZeppelin implementation provides.

Last updated 2 years ago

Was this helpful?