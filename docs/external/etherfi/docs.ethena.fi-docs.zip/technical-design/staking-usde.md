# Staking USDe

> Source: https://docs.ethena.fi/technical-design/staking-usde

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/staking-usde.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Staking USDe

Staking is controlled by the StakedUSDe smart contract. Stakers can interact with it directly or through the Ethena dApp UI.

- When **staking**, a user transfers *USDe *into the contract and receives *sUSDE *(staked *USDe*) in return, another ERC20 token.
- Over time, additional *USDe is* transferred in as rewards.
- When **unstaking**, staked *USDe *is burned in exchange for a proportionate *USDe *amount based on the total amount of sUSDe outstanding vis-a-vis total USDe in the smart contract.

Users will receive the principal amount of *USDe *staked as well as their proportionate share of the deposited rewards upon **unstaking**.

The acquisition of sUSDe is not offered to persons with their habitual residence or registered office in the European Union or the European Economic Area.

The StakedUSDe smart contract implements the [ERC4626 Token Vault standard](https://ethereum.org/en/developers/docs/standards/tokens/erc-4626/) for composability.  This popular standard is widely used for onchain reward-accruing; thus, it is expected that other user interfaces beyond the Ethena dApp may likely support *USDe *staking in the future. Various deposit and redeem functions are exposed, enabling staking with or without a slippage threshold, and with or without an ERC2612 Permit signature authorizing the transfer of USDe.

There is no minimum staking period. If a user **stakes **and **unstakes** in consecutive blocks, they would receive their share of any increase in vested *USDe *value in the contract that has occurred in that ~12-second period. Because reward payments into the contract occur every 8 hours and linearly vest over 8 hours, there are never any sudden spikes in the vested *USDe *value, which prevents sandwich attacks where an informed staker stakes before and unstakes after payment at the expense of all other stakers.

Stakers should never lose *USDe *by **staking**. *USDe *transfers of rewards can only be positive or flat into the StakedUSDe contract. As such, the *USDe *value of *stUSDe *can only increase or stay flat over time.

Staking rewards accrual is related to the protocol's generated revenue from staking Ethereum & earning the funding and basis spread from the delta hedging derivatives position. While protocol generated revenue should remain fairly stable unless there is a slashing event, the funding and basis spread income from delta hedging derivatives will vary considerably (even day to day). In some periods, no rewards may be paid to stakers if the funding + basis spread yield is negative and it is greater than or equal to the income generated via the staked Ethereum. In this situation, when no rewards are transferred to the StakedUSDe smart contract, the Ethena reserve fund will support the underlying protocol backing.

---

### Quick Answers[](#quick-answers)

***Q: Do I have to stake USDe to receive rewards?***

Yes. You have to stake your *USDe *with Ethena to receive incentive rewards. USDe is a synthetic dollar that does not earn rewards.

***Q: Why is there a cooldown period during launch?***

There is a cooldown from requesting to unstake *sUSDe *to receiving *USDe *in return. Users must first request their *USDe *be unstaked wherein their *USDe *will be placed in the [USDeSilo](https://etherscan.io/address/0x7FC7c91D556B400AFa565013E3F32055a0713425#tokentxns) smart contract. Once the cooldown period has elapsed, users will be able to withdraw their *USDe *from the USDeSilo smart contract.

***Q: Am I able to sell the sUSDe prior to the cooldown?***

Yes, you are able to do so if external markets exist. Note, however, that neither the Ethena Foundation nor Ethena Labs is planning to actively procure or facilitate creation of any such markets, and there can therefore be no guarantee that such market will exist.

***Q: Is it possible that I owe the protocol while staked?***

No. Rewards can only be positive or zero.

***Q: What are staking rewards paid in?***

The rewards are transferred to the staking contract in the form of USDe.

Last updated 2 months ago

Was this helpful?