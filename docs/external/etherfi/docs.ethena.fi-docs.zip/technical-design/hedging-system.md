# Hedging System

> Source: https://docs.ethena.fi/technical-design/hedging-system

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/hedging-system.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Hedging System

Risk Management, Pricing, Trading, and Backing Orchestration

Ethena's "Hedging System" is composed of a number of offchain application services that enable many critical aspects of the user experience, including:

- Calculating & publishing indicative prices for **minting** & **redeeming** *USDe*.
- Returning pricing to **mint **& **redeem ***USDe* requests.
- Ensuring the integrity of the system in real time.

The "Hedging System" ingests & interacts directly with the protocol's onchain smart contracts as well as the Ethereum blockchain.

The "Hedging System" is extremely risk-aware and has been designed in a manner wherein the preservation of protocol collateral is the most important consideration.

![image](https://docs.ethena.fi/~gitbook/image?url=https%3A%2F%2F596495599-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FsBsPyff5ft3inFy9jyjt%252Fuploads%252F6WCCypi2WpCW54LlU7IN%252FHedging%2520System.png%3Falt%3Dmedia%26token%3D34b46704-ac3c-493f-a688-443721807b53&width=768&dpr=3&quality=100&sign=17083ff274f858f425ee9867ec51479f&sv=3)
### Responsibilities[](#responsibilities)

At a level lower of detail, the "Hedging System" performs the following functions (but is not limited to):

- Ingests market data from CeFi Exchanges, "Off-Exchange Settlement" providers, Pyth and Redstone. This data includes order book updates, public trade information, as well as private portfolio, positions, orders, and trade information.
- Normalizes and validates the integrity of market data.
- Calculates the risk exposure of the portfolio relative to defined risk limits and goals.
- Reconciles internal system information relating to the protocol's portfolio, positions, orders, and trade information with CeFi Exchanges & "Off-Exchange Settlement" providers.
- Calculates & publishes indicative prices for **minting **& **redeeming ***USDe*.
- Ingests, validates, and publishes pricing for **mint **& **redeem ***USDe *requests.
- Determines where to route & execute orders upon a successful **mint **& **redeem ***USDe *request. This incorporates information about fees, depth of liquidity, existing positions, and other funding + basis opportunities.
- In real-time, validates all information & operations to ensure integrity relative to internal & external expectations.
- Monitors and alerts in regards to the availability of internal & external dependencies such as other internal services or CeFi Exchanges.
- Orchestrates the movement of backing assets between "Off-Exchange Settlement" providers and CeFi Exchanges.
- Publishes & alerts Ethena team members to real-time developments. Enabling immediate manual intervention in the event of inconsistency.
- Publishes & logs system data to different data stores. An example being the publication of trade data to a database.

---

### Hedging FAQ[](#hedging-faq)

[Notion FAQ Link](https://ethena.notion.site/Ethena-FAQs-3ccc1437e13343f8b74c0d005e4f5128)

Last updated 1 year ago

Was this helpful?