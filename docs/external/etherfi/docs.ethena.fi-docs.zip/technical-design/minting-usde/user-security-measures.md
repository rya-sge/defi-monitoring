# User Security Measures

> Source: https://docs.ethena.fi/technical-design/minting-usde/user-security-measures

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/minting-usde/user-security-measures.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Minting USDe](https://docs.ethena.fi/technical-design/minting-usde)

# User Security Measures

## Overview[](#overview)

Several measures have been taken to ensure the integrity and resilience of the deployed smart contracts. These measures are designed principally to ensure the safety of protocol assets, but also to ensure reasonable governance occurs.

Below is a list of some, but not all, of the user security measures Ethena has implemented across the deployed smart contracts.

## Measures[](#measures)

1. Only whitelisted user wallet addresses are able to successfully **mint** & **redeem** *USDe*. This seeks to ensure that only non-malicious actors are able to call the aforementioned functions.
2. Provided backing assets are only able to be sent from the Ethena Minting contract to whitelisted wallet addresses of our OES provider partners. This ensures protocol backing is not able to be diverted to improper wallets and protocol funds enjoy the legal and governance protections without interruption.

  - Updating the whitelisted addresses in the Ethena Minting contract requires a multi-sig transaction by members of both Ethena & external responsible parties.
3. Mint/Redeem Smart contract keys are generated in an air-gapped secure manner whereby a single person is not able to access these keys.
4. A small proportion of the protocol's total assets are kept in EOA wallets. Secure multi-sig approval process is required for major fund transfers.
5. Internal pricing sourced from multiple centralized exchanges is constantly validated with external sources such as Pyth and Redstone to ensure integrity.
6. Numerous [Order Validity checks](https://docs.ethena.fi/technical-design/minting-usde/order-validity-checks) are performed throughout the system + workflow to ensure the integrity of the system.
7. Separate `GATEKEEPER_ROLE` roles across the smart contract exist to detect unusual **mint**/**redeem **transactions and immediately disable the mint/redeem functionality upon unexpected behavior.
8. The `DEFAULT_ADMIN_ROLE` and `owner` smart contract roles are all multi-sig keys and are securely stored in cold wallets.

**Security Measure**

**Action Taken by Ethena**

**Purpose & Benefit**

**Handling of Mint/Redeem Keys**

Ethena securely generated mint/redeem keys are stored safely in AWS secrets manager. Exist on production machines upon deployment only which has critically restricted access.

Ensures no unauthorized access, safeguarding users and the protocol from potential mint/redeem key compromises.

**Address Validity**

Only whitelisted addresses can receive backing assets. Withdrawals restricted to whitelisted custodian addresses.

Minimises risk of sending funds to incorrect addresses, ensuring targeted and secure end to end mint/redeem flows.

**On-Chain Fund Management**

Avoid keeping large sums in EOA wallets. Secure multi-sig approval process for major fund transfers.

Safeguards protocol assets and protects from unintended fund movements.

**Ensuring Correct Pricing**

Validate internal pricing consistently against third-party sources. Real-time checks and balance measures.

Accurate pricing is essential, ensuring users get the best value and protocol remains stable.

**Hedging Processes**

Robust checks and balances for hedging, including block number validations and system health checks.

Ensures orders are handled correctly and reliably, minimising potential order execution errors.

**Protecting against Adverse Selection**

Employ a last-look architecture, whitelist market makers, and set tight windows for quote validity.

Priorities giving users the best pricing and protects against potential manipulations or unfair play.

**Gas Estimation**

Maintain a limited ETH balance for transactions and monitor gas fees to prevent overpayment.

Ensures users are not overcharged due to gas estimation errors, preserving user funds.

**Strict Order Submission**

Only whitelisted users can submit orders, which must meet Ethena’s validation criteria.

Protects the system against malicious public internet orders, only genuine requests are processed.

**Robust Role Management**

Distinct gatekeeper roles for monitoring and managing unusual mint/redeem transactions.

Specialised roles allow for targeted oversight and faster response to potential security threats.

**Cold Storage of Multi-Sig Keys**

Admin and owner multi-sig keys of all contracts are securely stored in cold wallets.

Enhances security by reducing exposure of essential keys to online threats.

Last updated 2 years ago

Was this helpful?