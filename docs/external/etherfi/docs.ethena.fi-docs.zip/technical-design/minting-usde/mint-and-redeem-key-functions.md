# Mint & Redeem Key Functions

> Source: https://docs.ethena.fi/technical-design/minting-usde/mint-and-redeem-key-functions

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/minting-usde/mint-and-redeem-key-functions.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Minting USDe](https://docs.ethena.fi/technical-design/minting-usde)

# Mint & Redeem Key Functions

Important functions of the mint and redeem smart contract

## Roles in EthenaMinting contract[](#roles-in-ethenaminting-contract)

### Overview[](#overview)

The Ethena minting contract has been designed to offer a safe and secure platform for the creation of *USDe*. Its atomic operations ensure that tasks are either fully completed or reverted, leaving no room for partial executions. Its immutable nature guarantees that its critical rules and operations cannot be easily altered, ensuring consistency and trust in the process. It has these key pieces of functionality:

1. **Minting**: Minters can mint *USDe *by providing assets and receiving *USDe *tokens in return. The backing assets are transferred to "Off-Exchange Settlement" providers based on a predefined route. The minting process is subject to a maximum limit set by the contract.
2. **Redemption**: Redeemers can redeem their *USDe *by providing them as input and receiving the underlying assets back *USDe* in return. The redeemed *USDe *tokens are burned from the user's balance. The redemption process is subject to a maximum limit set by the contract.
3. **Signature Verification**: The contract cryptographically verifies the signature provided by the user to ensure the authenticity of the minting or redemption order.
4. **Supported Assets:** The contract maintains a strict list of supported assets that can be used as backing assets for minting and redemption.
5. **Custodian Addresses: **The contract maintains a strict list of custodian addresses to which backing assets can be transferred during the minting process.
6. **Max Mint/Redeem Per Block:** The contract sets a maximum limit for the number of *USDe *tokens that can be minted or redeemed per block.

Roles in smart contracts are what control lower level operations and function calls. It's a security feature, like AWS IAM, that allows the authors of smart contracts, and the users using them once deployed to the blockchain, to be certain of how they can operate.

Despite being named the "Ethena Minting contract", it is responsible for both the **minting **& **redeeming **functionality of *USDe*.

## Roles in the Ethena Minting contract[](#roles-in-the-ethena-minting-contract)

There are five roles in the Ethena Minting contract. You can view the deployed Ethena Minting contract on the Ethereum blockchain **here**.

RoleTypeControllerRole CountFunctions / Notes`ADMIN`

Multi-Sig

Ethena Labs

1

- Transfer Ownership
- Add/remove supported collateral asset
- Add/remove custodian addresses
- Grant/revoke Minter, Redeemer, Gatekeeper roles
- Set max/mint mint/redeem per block
- Reenable mint/redeem

`GATEKEEPER`

EOA

Shared between

- Ethena Labs
- External Security Firms

3+ internal 3+ external

- Disable mint/redeem

  - Disables when they execute at incorrect prices on chain
  - Limits damage on mint/redeem roles compromise

`MINTER`

EOA

Ethena Labs

20

- Mint
- Transfer to approved "Off-Exchange Settlement" providers

`REDEEMER`

EOA

Ethena Labs

20

- Redeem

Last updated 1 year ago

Was this helpful?