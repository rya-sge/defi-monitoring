# Order Validity Checks

> Source: https://docs.ethena.fi/technical-design/minting-usde/order-validity-checks

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/minting-usde/order-validity-checks.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Minting USDe](https://docs.ethena.fi/technical-design/minting-usde)

# Order Validity Checks

Ensures only orders at fair prices are submitted on chain

## Context[](#context)

Ethena conducts several validations to ensure both the user and the protocol can honour the signed order before it is submitted to the blockchain.

When users **mint **or **redeem ***USDe*, after the user has signed the order with their wallet, Ethena retains "last-look" ability. This enables Ethena to be sure the price agreed between Ethena & the user wouldn't impose a loss on the protocol.* This is principally motivated to ensure neither Ethena nor the user is adversely affected in highly volatile markets.*

Ethena cannot change the user-signed EIP712 order as a result of the blockchain.

## Validations[](#validations)

ValidationDescriptionPurpose
1. Cryptographically Valid Signature

The user-provided signature is cryptographically valid.

This ensures the user has the necessary ability & permissions to request this operation.

1. System health check

A health check of Ethena hedging & pricing internal systems

This is to ensure Ethena can manage the delta of the operation.

1. Whitelisted trader

The user's Ethereum address is whitelisted.

Only KYC/KYB'd users are able to directly **mint **& **redeem ***USDe* with Ethena.

1. Approved beneficiary

If the beneficiary of the mint is different than the benefactor, the benefactor must have approved this beneficiary onchain.

Ensures benefactors or their delegates do not accidentally or maliciously redirect proceeds to another wallet.  Benefactors can approve beneficiaries by calling `setApprovedBeneficiary` once.  [Etherscan offers a UI for doing this.](https://etherscan.io/address/0xe3490297a08d6fC8Da46Edb7B6142E4F461b62D3#writeContract#F20)

1. Sufficient balances and approvals

The user has provided sufficient approvals and has sufficient funds to honour the request.

Prevents time and gas wastage and ensures transaction success at the smart contract.

1. Timeliness of order return

The user has returned a signed order within an acceptable time period of Ethena sending a response to their initial RFQ request.

Keeps prices relevant by ensuring prompt order response.

1. Order expiration check

The user's signed order expiry attribute is at least 30 seconds in the future

The user's signed order expiry attribute is at least 30 seconds in the future to ensure the transaction is able to reach finality in almost all gas environments.

1. RFQ and order match

The user's signed order `collateral_amount` and `usde_amount` attributes are an exact match to the RFQ payload Ethena returned to them.

This ensures users and protocol positively affirm the terms of the agreement.

1. Last look

The present system price compared to the signed order's price is within the acceptable tolerance the user and Ethena have agreed to.

This ensures that the price hasn't moved outside of tolerance bands adversely against the protocol.

1. External price check

That the signed price is within a specific tolerance of another external pricing source, such as [Pyth](https://pyth.network/) and Redstone.

This operates as one of many sources of redundancy and fail-safes to ensure the system is functioning correctly at all times.

1. $N per block limit check

The order will not exceed the defined maximum capacity that is available per block for **mint **and **redeem ***USDe *requests.

Contributes to protocol stability.

1. Multiple orders check

The user does not have another order to be processed in this block.

Users are only allowed to successfully submit one **mint **/ **redeem ***USDe *request per block.

Last updated 1 year ago

Was this helpful?