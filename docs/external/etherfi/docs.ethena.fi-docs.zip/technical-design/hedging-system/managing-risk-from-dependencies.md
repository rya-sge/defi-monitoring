# Managing Risk from dependencies

> Source: https://docs.ethena.fi/technical-design/hedging-system/managing-risk-from-dependencies

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/hedging-system/managing-risk-from-dependencies.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Hedging System](https://docs.ethena.fi/technical-design/hedging-system)

# Managing Risk from dependencies

Ethena Labs' "Hedging System" has three notable external dependencies (aside from AWS):

1. CeFi Exchanges, such as Bybit.
2. "Off-Exchange Settlement" (OES) providers, such as Copper.
3. Price Feeds, such as Pyth and Redstone.

It is important to note that Ethena Labs has team members available 24/7 across different timezones & countries who are able to manage and address any issues that might occur.

If any of the system checks performed both internally and externally by market making entities with gatekeeper roles can disable the ability to **mint **& **redeem ***USDe *until they are satisfied the system is functioning correctly without discrepancies.

### Possible Negative Events[](#possible-negative-events)

The following is a list of negative events that might occur, what the issue to the system would be, how it is mitigated/ameliorated, and the maximum potential impact to the protocol.

> Note: This is not an exhaustive list, but the most common & likely (in the unlikely event they occur).

#### CeFi Exchange / OES Partner suffers technical issues[](#cefi-exchange-oes-partner-suffers-technical-issues)

Where a CeFi Exchange or OES partner suffers technical issues such as failing to send real-time updates or perhaps inconsistent information per their specification across multiple objects; this would cause internal objects to not match the system's expectations.

As a result, the system would immediately identify this inconsistency and determine if it is isolated to a single partner. If it's possible to continue **minting **and **redeeming ***USDe *while quarantining the affected partner(s), the system will; if not, **minting **and **redeeming ***USDe *will be paused until the issue can be addressed.

The system identifies these inconsistencies by performing a large number of validations upon data in real-time, with constant reconciliation with partners, and alerting.

#### CeFi Exchange(s) becomes temporarily inaccessible[](#cefi-exchange-s-becomes-temporarily-inaccessible)

In the event a CeFi Exchange partner(s) were to become temporarily inaccessible, Ethena would no longer be able to submit or edit existing orders on exchanges. This would result in Ethena losing control of any existing orders & possibly being able to reconcile the exact state of that exchange's portfolio.

The system would immediately identify this issue and attempt to cancel all outstanding open orders on the exchange. The system would attempt to identify the latest portfolio update and would no longer attempt to submit new orders. The system would distribute hedging orders to other exchange partners and only include the affected partner(s) again when service had been satisfactorily restored.

Availability and integrity are considered in a wide range & number of validations that are constantly performed throughout the system.

#### Market Data prices lack integrity[](#market-data-prices-lack-integrity)

In the event some or all market data price feeds begin to lack integrity, Ethena would immediately cancel all affected open orders and identify the affected partners. The lack of market data would prevent Ethena from being able to submit orders to exchange partners.

It's important to keep in mind that Ethena is integrated with multiple market data feeds & exchange prices as to ensure the affected partner(s) can be quarantined without damaging the integrity of operations.

The "Hedging System" monitors for integrity in real-time and actively alerts in the event of any concerns.

#### Internal System component fails[](#internal-system-component-fails)

In the event that an internal system service fails, becomes unresponsive, or begins to behave in an inconsistent manner, the system identifies and quarantines the issue in real-time.

The system has been designed to self-heal in the event of any failures or degradations as well as there is a large focus throughout the system upon ensuring each interaction & data stored makes "sense".

The system is actively tested end to end, in addition to unit/component/integration tests, as well as ensuring there is alerting throughout the system that readily notifies the appropriate parties.

In the event a service fails and is unable to self-heal, **minting **and **redeeming ***USDe* is automatically temporarily paused while the outstanding issue is investigated & resolved.

Last updated 1 year ago

Was this helpful?