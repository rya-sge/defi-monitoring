# Internal Services

> Source: https://docs.ethena.fi/technical-design/hedging-system/internal-services

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/hedging-system/internal-services.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)
2. [Hedging System](https://docs.ethena.fi/technical-design/hedging-system)

# Internal Services

At a high level, the "Hedging System" is composed of broadly five services:

1. **Portfolio Management System**
2. **Market Data Parser Service**
3. **Reference Data Service**
4. **Reconciliation Service**
5. **Persistor Service**

### **Services**[](#services)

#### **Portfolio Management System**[](#portfolio-management-system)

The "Portfolio Management System" manages a number of key functions including:

- Calculating and publishing indicative prices if users were to **mint **& **redeem ***USDe*.
- Calculating and publishing prices for users' **mint **& **redeem ***USDe* requests.
- Calculating portfolio exposure in real time & requesting operations as a result.
- Orchestrating the delegation/undelegate between "Off-Exchange Settlement" providers and CeFi exchanges as well as coordinating the movement of backing assets between "Off-Exchange Settlement" providers & Minting + Staking smart contracts.
- Routing and managing the execution of orders to manage risk.
- Altering in the event of system degradation or inconsistency present in the system.

#### **Market Data Parser Service **[](#market-data-parser-service)

The "Market Data Parser Service" connects & ingests market data updates from CeFi Exchanges, "Off-Exchange Settlement" providers, as well as Pyth and Redstone. This information includes order book updates, public trades, and private orders, positions & trade information.

The application is designed, built, and deployed in a manner wherein it is resilient and functional even in high-volatility environments.

*When does Ethena consider external market data invalid?*

We capture invalid data in two dimensions:

- Wrong/invalid
- Outdated

Data directly from exchanges gets compared against Pyth and has to fall within a tight tolerance, which is manually set but wide enough to allow even rapid moves. It's mainly trade-through events; one large order walks 50 levels into the order book, which we would like to avoid reacting on.

During volatile moments, the exchanges tend to fall behind on their updates. We have spent extensive engineering resources to deal with such situations (efficient data reading from network card, batch processing, update filtering etc.) to avoid being the bottleneck.

We have continuous time synchronisation between our system and the connected exchanges. Once we detect a time drift of the updates published (set either by the exchange gateway or matching engine, depending on the exchange), we update our RFQ look-back period to reflect this. This means that we only give the final acceptance of the RFQ once we have the up-to-date market data. This mechanism is vital to protect the protocol against adverse selection by market makers with faster infrastructure.

In case the market data falls further behind our suspend threshold, we put the instrument into suspend mode. The latency has to improve significantly for the instrument to be enabled again, as it requires passing a hysteresis -this avoids on/off flickering.

#### **Reference Data Service**[](#reference-data-service)

The "Reference Data Service" normalizes & validates the integrity of all ingested data.

#### **Reconciliation Service **[](#reconciliation-service)

The "Reconciliation Service" periodically verifies information throughout the system is consistent with that from external sources. This includes, but not is not limited to position & market data information. This service is one of many layers throughout the system to validate & ensure the integrity of the operation of the system.

#### **Persistor Service**[](#persistor-service)

The "Persistor Service" publishes internal events to data stores, such as databases. This enables recovery in a wide range of instances without losing data & enables Ethena to rapidly heal and continue operations without interruption or user detriment.

Last updated 1 year ago

Was this helpful?