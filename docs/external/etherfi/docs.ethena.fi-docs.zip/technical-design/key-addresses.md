# Key Addresses

> Source: https://docs.ethena.fi/technical-design/key-addresses

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/technical-design/key-addresses.md).CopyOn this page
1. [Technical Design](https://docs.ethena.fi/technical-design)

# Key Addresses

### Core Contracts[](#core-contracts)

Mint and Redeem Contract V1: [https://etherscan.io/address/0x2cc440b721d2cafd6d64908d6d8c4acc57f8afc3](https://etherscan.io/address/0x2cc440b721d2cafd6d64908d6d8c4acc57f8afc3)

Mint and Redeem Contract V2: [https://etherscan.io/address/0xe3490297a08d6fC8Da46Edb7B6142E4F461b62D3](https://etherscan.io/address/0xe3490297a08d6fC8Da46Edb7B6142E4F461b62D3)

Staking Contract: [https://etherscan.io/address/0x9d39a5de30e57443bff2a8307a4256c8797a3497](https://etherscan.io/address/0x9d39a5de30e57443bff2a8307a4256c8797a3497)

USDe Token Contract: [https://etherscan.io/address/0x4c9edd5852cd905f086c759e8383e09bff1e68b3](https://etherscan.io/address/0x4c9edd5852cd905f086c759e8383e09bff1e68b3)

sUSDe Token Contract: [https://etherscan.io/address/0x9d39a5de30e57443bff2a8307a4256c8797a3497](https://etherscan.io/address/0x9d39a5de30e57443bff2a8307a4256c8797a3497)

sUSDe Rewards Distributions:
[https://etherscan.io/advanced-filter?fadd=0x71e4f98e8f20c88112489de3dded4489802a3a87&tadd=0x9D39A5DE30e57443BfF2A8307A4256c8797A3497&qt=1](https://etherscan.io/advanced-filter?fadd=0x71e4f98e8f20c88112489de3dded4489802a3a87&tadd=0x9D39A5DE30e57443BfF2A8307A4256c8797A3497&qt=1)

USDe to sUSDe Staking Rewards Distributor Contract: [https://etherscan.io/address/0xf2fa332bd83149c66b09b45670bce64746c6b439#tokentxns](https://etherscan.io/address/0xf2fa332bd83149c66b09b45670bce64746c6b439#tokentxns)

ENA Token Contract:
[https://etherscan.io/address/0x57e114B691Db790C35207b2e685D4A43181e6061](https://etherscan.io/address/0x57e114B691Db790C35207b2e685D4A43181e6061)

sENA Token Contract:

[https://etherscan.io/token/0x8bE3460A480c80728a8C4D7a5D5303c85ba7B3b9](https://etherscan.io/token/0x8bE3460A480c80728a8C4D7a5D5303c85ba7B3b9)

sENA Token Contract:
[https://etherscan.io/address/0x8be3460a480c80728a8c4d7a5d5303c85ba7b3b9](https://etherscan.io/address/0x8be3460a480c80728a8c4d7a5d5303c85ba7b3b9)

rsENA Token Contract:
[https://etherscan.io/address/0xc65433845ecd16688eda196497fa9130d6c47bd8](https://etherscan.io/address/0xc65433845ecd16688eda196497fa9130d6c47bd8)

USDtb PSM Contract: [https://etherscan.io/address/0x73E35C5c35A274E34AdE6EB13cC7f62aEE323728](https://etherscan.io/address/0x73E35C5c35A274E34AdE6EB13cC7f62aEE323728)

### Token Contracts on Other Chains[](#token-contracts-on-other-chains)

Beyond Ethereum mainnet, Ethena tokens are available on the following chains:

- TON
- Aptos
- Berachain
- Solana
- Mantle
- Blast
- Arbitrum
- Optimism
- Base
- Zircuit
- ZKSync
- BNB
- Linea
- Manta
- Scroll
- Fraxtal
- Mode
- XLayer
- Metis
- Kava
- Morph
- Swell

With the exceptions of Solana, ZKSync, and Zircuit, token addresses on all chains are identical, as summarized below:

ChainENAUSDesUSDeMost L2s (Other Than As Indicated Below)

0x58538e6A46E07434d7E7375Bc268D3cb839C0133

0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34

0x211Cc4DD073734dA055fbF44a2b4667d5E5fE5d2

Solana

72QvBVwpxqmheEPfaCwWSWqEFsUy3rhWt6JhQBMNTwD1

DEkqHyPN7GMRJ5cArtQFAWefqbZb33Hyf6s5iCwjEonT

Eh6XEPhSwoLv5wFApukmnaVSHQ6sAnoD9BmgmwQoN2sN

TON

EQAFhZFZYye0llsl785OzOJG9QT6PXyYUdmiC4U95lBuHh1S

EQAIb6KmdfdDR7CN1GBqVJuP25iCnLKCvBlJ07Evuu2dzP5f

EQDQ5UUyPHrLcQJlPAczd_fjxn8SLrlNQwolBznxCdSlfQwr

(*tsUSDe on TON)*

Tempo

0x20c0000000000000000000002F52D5CC21A3207B

OFT: 0xf8b6aa0cee4e1ad87ee259dab5e556eb62297d7f

0x20C000000000000000000000Bd95bFB69fBE6Ce3

OFT: 0x100c123770be9015321a9fcfa4ae3e77dcb2cf1a

Aptos

0xf37a8864fe737eb8ec2c2931047047cbaed1beed3fb0e5b7c5526dafd3b9c2e9

0xb30a694a344edee467d9f82330bbe7c3b89f440a1ecd2da1f3bca266560fce69

ZKSync

0x686b311F82b407f0be842652a98e5619F64cC25F

0x39Fe7a0DACcE31Bd90418e3e659fb0b5f0B3Db0d

0xAD17Da2f6Ac76746EF261E835C50b2651ce36DA8

Zircuit

0x813635891aA06bd55036bbd8f7d1A34aB3de9a0F

0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34

0x211Cc4DD073734dA055fbF44a2b4667d5E5fE5d2

ChainEthena LP StakingMultisigSolana

[https://app.squads.so/squads/EWZCJs2JRo3tMKgDt8FGx7MccD8sKv4QEcdsY9ZhVKZA](https://app.squads.so/squads/EWZCJs2JRo3tMKgDt8FGx7MccD8sKv4QEcdsY9ZhVKZA)

Aptos

[https://app.rimosafe.com/home?safe=0x84c7ac376914733149586b28acf837f3ef20eee7fe8e28a19e1a135ffca676b9](https://app.rimosafe.com/home?safe=0x84c7ac376914733149586b28acf837f3ef20eee7fe8e28a19e1a135ffca676b9)

Berachain

[https://safe.berachain.com/home?safe=berachain:0x093d3F4785149A3d2600cb10D63aFa14f9b09364](https://safe.berachain.com/home?safe=berachain:0x093d3F4785149A3d2600cb10D63aFa14f9b09364)

Mantle

[https://etherscan.io/address/0x8707f238936c12c309bfc2b9959c35828acfc512#code](https://etherscan.io/address/0x8707f238936c12c309bfc2b9959c35828acfc512#code)

[https://multisig.mantle.xyz/home?safe=mantle:0x799a2Cd46CBc7FB53949072257e6331054A060Bb](https://multisig.mantle.xyz/home?safe=mantle:0x799a2Cd46CBc7FB53949072257e6331054A060Bb)

Blast

[https://blast-safe.io/home?safe=blast:0x689272B1D2B2F37a0B3fe1f5Af0420C64f6cc9E3](https://blast-safe.io/home?safe=blast:0x689272B1D2B2F37a0B3fe1f5Af0420C64f6cc9E3)

Arbitrum

[https://app.safe.global/home?safe=arb1:0xc9647361742Eb964965B461C44Bdf5c4Bc3c406d](https://app.safe.global/home?safe=arb1:0xc9647361742Eb964965B461C44Bdf5c4Bc3c406d)

Optimism

[https://app.safe.global/home?safe=oeth:0xc66bbBf821f2cfB3a85683acF0326EAC92C160Bd](https://app.safe.global/home?safe=oeth:0xc66bbBf821f2cfB3a85683acF0326EAC92C160Bd)

Base

[https://app.safe.global/home?safe=base:0xbC89D10EB486b6591583F218acB9545087dBF293](https://app.safe.global/home?safe=base:0xbC89D10EB486b6591583F218acB9545087dBF293)

ZKSync

[https://app.safe.global/home?safe=zksync:0xa026e9a5e54E16349D7b594449f32901E02C609a](https://app.safe.global/home?safe=zksync:0xa026e9a5e54E16349D7b594449f32901E02C609a)

BNB

[https://app.safe.global/home?safe=bnb%3A0xc9647361742Eb964965B461C44Bdf5c4Bc3c406d](https://app.safe.global/home?safe=bnb%3A0xc9647361742Eb964965B461C44Bdf5c4Bc3c406d)

Linea

[https://safe.linea.build/home?safe=linea%3A0xE1B9B4c7D664126Bf4B6724deb59Eb5F8Aab9192](https://safe.linea.build/home?safe=linea%3A0xE1B9B4c7D664126Bf4B6724deb59Eb5F8Aab9192)

Manta

[https://safe.manta.network/home?safe=manta%3A0xA408Fd6724341B27F2e348faf9eCCEc04A2299EA](https://safe.manta.network/home?safe=manta%3A0xA408Fd6724341B27F2e348faf9eCCEc04A2299EA)

Scroll

[https://safe.scroll.xyz/settings/setup?safe=scr:0xAFAFc5D0DF6830052988c76DD8d0DfA7f5B8FfD6](https://safe.scroll.xyz/settings/setup?safe=scr:0xAFAFc5D0DF6830052988c76DD8d0DfA7f5B8FfD6)

Fraxtal

[https://safe.mainnet.frax.com/home?safe=fraxtal:0xc66bbBf821f2cfB3a85683acF0326EAC92C160Bd](https://safe.mainnet.frax.com/home?safe=fraxtal:0xc66bbBf821f2cfB3a85683acF0326EAC92C160Bd)

Mode

[https://safe.optimism.io/home?safe=mode:0x273ceD5b9da8F5ba6E40C82c126898cB5307B2ea](https://safe.optimism.io/home?safe=mode:0x273ceD5b9da8F5ba6E40C82c126898cB5307B2ea)

XLayer

[https://app.safe.global/home?safe=xlayer:0xce2f77841A8B974CE8e79157BccBECf17599f0E8](https://app.safe.global/home?safe=xlayer:0xce2f77841A8B974CE8e79157BccBECf17599f0E8)

Metis

[https://metissafe.tech/home?safe=metis-andromeda:0x795dB361ED5727F3f27dccde15b7D0d975fC94e0](https://metissafe.tech/home?safe=metis-andromeda:0x795dB361ED5727F3f27dccde15b7D0d975fC94e0)

Kava

[https://app.oryy.io/home?safe=kava:0x10E9219dD188D0f3af30824469Dc874A539733B6](https://app.oryy.io/home?safe=kava:0x10E9219dD188D0f3af30824469Dc874A539733B6)

Zircuit

[https://safe.zircuit.com/home?safe=zircuit-mainnet:0x07762C592e243D4aDD1648A7Ab4916D898780bae](https://safe.zircuit.com/home?safe=zircuit-mainnet:0x07762C592e243D4aDD1648A7Ab4916D898780bae)

### Liquidity Pool Contracts[](#liquidity-pool-contracts)

USDC x USDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-12/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-12/deposit)

crvUSD x USDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-11/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-11/deposit)

FRAX x USDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-35/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-35/deposit)

mkUSD x USDe Curve Pool:
[https://curve.fi/#/ethereum/pools/factory-stable-ng-68/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-68/deposit)

DAI x USDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-100/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-100/deposit)

FDUSD x USDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-166/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-166/deposit)

sDAI x sUSDe Curve Pool:

[https://curve.fi/#/ethereum/pools/factory-stable-ng-102/deposit](https://curve.fi/#/ethereum/pools/factory-stable-ng-102/deposit)

USDT x USDe Uniswap v3 Pool:

[https://info.uniswap.org/#/pools/0x435664008f38b0650fbc1c9fc971d0a3bc2f1e47](https://info.uniswap.org/#/pools/0x435664008f38b0650fbc1c9fc971d0a3bc2f1e47)

### Multisig Wallets[](#multisig-wallets)

#### Dev[](#dev)

[https://etherscan.io/address/0x3b0aaf6e6fcd4a7ceef8c92c32dfea9e64dc1862](https://etherscan.io/address/0x3b0aaf6e6fcd4a7ceef8c92c32dfea9e64dc1862)

- 5/11 signers.
- Owner of Ethena's deployed mainnet smart contracts & able to modify contract parameters.

#### sUSDe Payout Fund[](#susde-payout-fund)

[https://etherscan.io/address/0x71e4f98e8f20c88112489de3dded4489802a3a87](https://etherscan.io/address/0x71e4f98e8f20c88112489de3dded4489802a3a87)

- 3/11 signers.
- Distributes USDe to Staking Rewards Distributor.

#### Reserve Fund[](#reserve-fund)

[https://etherscan.io/address/0x2b5ab59163a6e93b4486f6055d33ca4a115dd4d5](https://etherscan.io/address/0x2b5ab59163a6e93b4486f6055d33ca4a115dd4d5)

- 4/10 signers.
- Protocol's funds to be disbursed when net negative funding (or other impairment to USDe's backing) occurs.

#### USDe PSM Custodian[](#usde-psm-custodian)

[https://etherscan.io/address/0xD7fCaDe52aFb60FbF0E1E5F72A683F43820f56A0](https://etherscan.io/address/0xD7fCaDe52aFb60FbF0E1E5F72A683F43820f56A0)

- Coinbase MPC custody. The same address is used on each chain where a PSM is deployed.
- Holds pre-minted USDe inventory supporting Peg Stability Module (PSM) contracts on chains beyond Ethereum mainnet, enabling 1:1 swaps between USDe and supported stablecoins.
- USDe held at this address is not in circulation and is excluded from circulating supply. It enters circulation only when swapped out against an equivalent value of backing assets received.
- Backing assets held at this address are included in the protocol's backing, as they already back circulating USDe (i.e., USDe not held in the PSM).

Last updated 22 days ago

Was this helpful?