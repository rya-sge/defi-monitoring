# How to \[Un\]lock positions

> Source: https://docs.ethena.fi/video-guides/how-to-un-lock-positions

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/video-guides/how-to-un-lock-positions.md).CopyOn this page
1. [Video Guides](https://docs.ethena.fi/video-guides)

# How to [Un]lock positions

Locking tokens and positions enables holders to receive the protocol's generated rewards

Users in permitted jurisdictions can [**lock **& **unlock**](https://app.ethena.fi/overview)positionswith Ethena via the UI.

Using the UI, the **locking & unlocking **positionsuser workflow is:

1. The user requests to **lock/unlock **positionsvia the dApp interface by clicking "Lock"/"Unlock", which pops up their selected wallet to sign the requested transaction.
2. After the user signs the transaction with their wallet, the transaction is submit to the blockchain, if successful, the cooldown period starts.
3. Once the cooldown period ends, the user now needs to click on "Withdraw" and sign a second transaction.
4. Upon successful confirmation of the transaction, the user receives unlocked tokens.

#### Important to Note[](#important-to-note)

- There is a cooldown period of 7 days after unlocking *USDe, USDe* will be available to withdraw after  that period.
- There is a cooldown period of 7 days after unlocking *sENA, sENA* will be available to withdraw after  that period. This is in addition to the 7 day sENA unstaking cooldown.
- There is a cooldown period of 21 days after unlocking LP tokens, these LP tokens will be available to withdraw after  that period.  Some LP tokens have no cooldown and can be withdrawn immediately.

Last updated 2 months ago

Was this helpful?