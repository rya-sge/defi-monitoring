# How to Stake ENA

> Source: https://docs.ethena.fi/video-guides/how-to-stake-ena

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/video-guides/how-to-stake-ena.md).CopyOn this page
1. [Video Guides](https://docs.ethena.fi/video-guides)

# How to Stake ENA

Staking ENA enables holders to receive the protocol's generated rewards

Users in permitted jurisdictions can **stake **& **unstake ***ENA*/*sENA *with Ethena via the UI.

Using the UI, the **staking & unstaking ***ENA*/*sENA *user workflow is:

1. The user requests to **stake/unstake ***ENA*/*sENA *via the dApp interface by clicking "Stake"/"Unstake", which pops up their selected wallet to sign the requested transaction.
2. After the user signs the transaction with their wallet, the transaction is submit to the blockchain.
3. Upon successful confirmation of the transaction, the user receives *sENA*/*ENA *as their *ENA*/*sENA* is atomically swapped.

#### Important to Note[](#important-to-note)

- Users do NOT need to do anything but hold *sENA *to receive incentive rewards.
- Rewards aren’t earned directly by *sENA* holders; rather, it accumulates within the staking contract, which results in the "value" of *sENA *rising over time in *ENA* terms. Users are able to unstake their *sENA *at any time, at which point they receive an amount *sENA* reflecting the staked amount plus any increase in value of *sENA* in ENA terms from the time the user staked until unstaking.
- The amount of *sENA *a user will receive when staking *sENA *will depend on the current value of *sENA.* At launch the value was 1 *sENA* = 1 *ENA*, but *sENA* is expected to slowly increase in value as distributions are transferred into the staking smart contract.

  - This is because *sENA *was implemented using a token vault mechanism to provide protocol level rewards to permitted users. This mechanic is similar to [Rocketpool's rETH](https://docs.rocketpool.net/guides/staking/overview.html#the-reth-token).
  - Therefore, while a staker might receive less *sENA *than *ENA *staked, the value of the *sENA *will always be equal to or greater than the *ENA *youstaked in *ENA* terms.
- There is a cooldown period of 7 days after unstaking *sENA, ENA* will be available to withdraw after  that period.
- Distributions of ENA to the sENA contract are purely discretionary.  In late 2024 and early 2025, unclaimed ENA grants from Ethena's Season 1 airdrop were distributed to sENA.  As of September 2025, however, no distributions are in effect or announced.

Last updated 2 months ago

Was this helpful?