# How to Stake USDe

> Source: https://docs.ethena.fi/video-guides/how-to-stake-usde

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/video-guides/how-to-stake-usde.md).CopyOn this page
1. [Video Guides](https://docs.ethena.fi/video-guides)

# How to Stake USDe

Staking USDe enables holders to receive the protocol's generated rewards

*The information contained in the following video or on this website is not directed at persons with their habitual residence or registered office in the European Union, European Economic Area, or United Kingdom.*

Users in permitted jurisdictions can [**stake **& **unstake**](https://app.ethena.fi/)*USDe*/*sUSDe *via the UI.

Using the UI, the **staking & unstaking ***USDe*/*sUSDe *user workflow is:

1. The user requests to **stake/unstake ***USDe*/*sUSDe *via the dApp interface by clicking "Stake"/"Unstake", which pops up their selected wallet to sign the requested transaction.
2. After the user signs the transaction with their wallet, the transaction is submit to the blockchain.
3. Upon successful confirmation of the transaction, the user receives *sUSDe*/*USDe *as their *USDe*/*sUSDe* is atomically swapped via autonomous smart contract.

#### Important to Note[](#important-to-note)

- Users do NOT need to do anything but hold *sUSDe *to accrue rewards.
- Rewards aren’t earned directly by *sUSDe* holders; rather, they accumulate within the staking contract, which results in the "value" of *sUSDe *rising over time in USDe terms. Users are able to unstake their s*USDe *at any time, at which point they receive an amount *USDe* reflecting the staked amount plus any increase from the time the user staked until unstaking.
- The amount of *sUSDe *a user will receive when staking *USDe *will depend on the current value of *sUSDe.* At launch the value was 1 *sUSDe* = 1 *USDe*, and *sUSDe* is expected to slowly increase in value in USDe terms as protocol discretionary rewards are transferred into the Staking smart contract.

  - This is because *sUSDe *was implemented using a token vault mechanism to provide protocol level incentive rewards to permitted users. This mechanic is similar to [Rocketpool's rETH](https://docs.rocketpool.net/guides/staking/overview.html#the-reth-token).
  - Therefore, while a staker might receive less *sUSDe *than *USDe *staked, the value of the *sUSDe *in USDe terms will always be equal to or greater than the *USDe *staked.
- sUSDe is subject to a cooldown period before USDe can be withdrawn. The cooldown is dynamic (currently between 1 and 7 days) depending on reserve conditions; the current parameters are set by governance.

Users can only receive a positive or zero rewards holding *sUSDe*. The value of *sUSDe* will NOT decline, even in periods where the protocol is earning negative income, as the protocol does not and cannot remove assets from the staking contract. Such periods are expected to be covered by the Reserve Fund, to be discussed later.

Last updated 2 months ago

Was this helpful?