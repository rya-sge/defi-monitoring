# Overview

> Source: https://docs.ethena.fi/api-documentation

---

For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). This page is also available as [Markdown](https://docs.ethena.fi/api-documentation/overview.md).CopyOn this page
1. [API Documentation](https://docs.ethena.fi/api-documentation)

# Overview

Ethena Minting Documentation

Ethena’s API is used to mint and redeem USDe.  In addition to the information on this page, interactive documentation is available [here.](https://public.api.ethena.fi/docs/)

We offer the ability to stream indicative quotes, perform a formal RFQ and finally submitting of signed orders.

Only whitelisted users are able to successfully interact with the API interface. We recommend reaching out in our discord if you would like to be whitelisted.

**Addresses on Ethereum mainnet**

USDe: 0x4c9EDD5852cd905f086C759E8383e09bff1E68B3

Ethena Mint and Redeem Smart Contract: 0xe3490297a08d6fC8Da46Edb7B6142E4F461b62D3

These addresses are the production USDe and minting contract. Care should be taken using them as real value will be transferred.

[Mint & Redeem Smart Contract ABI](https://gist.github.com/mcevoyinit/0660818e968a6a46603e06fa80b20d40)

### **Server location**[](#server-location)

Ethena's infrastructure is hosted on AWS Asia Pacific (Hong Kong) region, ap-east-1. Low latency with our infrastructure is necessary to algorithmically mint or redeem with Ethena as quotes are valid for limited time.

### Connection URLs[](#connection-urls)

Whitelisted users are able to use either https://public.api.ethena.fi

### SDKs[](#sdks)

There are both [Python and TypeScript SDKs available](https://github.com/ethena-labs/ethena-minting-client).

### Approvals Added to Whitelisted Addresses[](#approvals-added-to-whitelisted-addresses)

Ensure you have approved the [Mint & Redeem Smart Contract](https://etherscan.io/address/0xe3490297a08d6fC8Da46Edb7B6142E4F461b62D3) for your whitelisted wallet addresses.

### Pair Availability Endpoint[](#pair-availability-endpoint)

This endpoint returns the pairs available to directly mint & redeem with.

**No parameters required**

**Our response**

key

keyPossible valuesDescriptionmint

["USDT/USDE", "USDC/USDE"]

The available pairs to directly mint with.

redeem

["USDT/USDE", "USDC/USDE"]

**Example request**

[https://public.api.ethena.fi/asset-availability](https://public.api.ethena.fi/asset-availability)

**Example response**

### RFQ Request Endpoint[](#rfq-request-endpoint)

Call the RFQ endpoint to receive a formal mint/redeem quote. Quotes are valid for 15 minutes upon us sending our response.

**Your request**

Key

KeyRequiredPossible ValuesDescriptionpair

true

USDT/USDe, USDC/USDe

collateral/usde pairs we support

side

true

mint,redeem

size

true

21.2918

size of asset you will send us. USDT for mint, USDe for redeem

benefactor

true

{benefactor_address}

String of the ETH wallet address

**Our response**

KeyPossible valuesDescriptionrfq_id

RFQ-B7MT6QD2JKFFC

Unique ID to be sent back to us when submitting order

pair

USDT/USDe, USDC/USDe

collateral/usde pairs we support

side

mint, redeem

size

true1

size of asset you will send us. USDT for mint, USDe for redeem.

amount

1552.2695

amount of asset you will receive, before gas. USDe for mint, USDT for redeem.

collateral_asset_address

0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84

The non-USDe asset in the transaction

usde_address

0x8191DC3053Fe4564c17694cB203663d3C07B8960

Address of USDe

collateral_amount

1000000000000000000

Use this value for EIP712 signature. For mints, this is the same as size but in 18 decimals. For redeems, this is amount minus gas converted to USDT in 18 decimals

usde_amount

1550198770000000000000

Use this value for EIP712 signature. For redeems, this is the same as size but in 18 decimals. For mint, this is amount minus gas in 18 decimals

gas

2.070727513

the gas price of this tx in USD.

**Example mint RFQ request**

[https://public.api.ethena.fi/rfq?pair=USDT%2FUSDe&side=MINT&size=100000&benefactor=0x0000000000000000000000000000000000000020](https://public.api.ethena.fi/rfq?pair=USDT%2FUSDe&side=MINT&size=100000&benefactor=0x0000000000000000000000000000000000000020)

**Response**

**Example redeem RFQ request**

[https://public.api.ethena.fi/rfq?pair=USDT%2FUSDe&side=REDEEM&size=100000&benefactor=0x0000000000000000000000000000000000000020](https://public.api.ethena.fi/rfq?pair=USDT%2FUSDe&side=REDEEM&size=100000&benefactor=0x0000000000000000000000000000000000000020)

**Response**

#### Error Codes[](#error-codes)

Error CodeHTTP Status CodeMessage0

400

Invalid RFQ payload. Missing required fields.

1

400

Temporarily unavailable

2

400

Collateral asset not supported.

3

400

Pair is not supported.

4

400

Side value is not supported.

5

400

Too many significant figures for size value.

6

400

Size can only include numbers.

7

400

Size must be non zero and positive.

8

400

Size must be enough to cover the incurred gas cost.

9

400

Size exceeds Ethena set capacity per block.

10

400

Wallet address not whitelisted. Please contact Ethena.

11

400

Insufficient collateral asset in wallet.

12

400

Insufficient collateral asset approval for Ethena to transfer.

13

400

Insufficient USDe balance in wallet.

14

400

Insufficient USDe approval for Ethena to transfer.

15

400

Asset currently not active

16

400

Type_ value is not supported.

## Fees Endpoint[](#fees-endpoint)

Call the Fees endpoint to retrieve the fee schedule. The endpoint returns the applicable fees (in basis points) for each supported token.

### Your Request[](#your-request)

KeyTypeRequiredDescription`benefactor`

string

Yes

The Ethereum wallet address to check fees for. Must be a valid checksummed address.

### Our Response[](#our-response)

KeyTypeDescription`benefactor`

string

The checksummed Ethereum address that was queried.

`fees`

array

Array of fee objects for each supported token.

`fees[].token`

string

The token symbol (e.g., "USDT", "USDC").

`fees[].fee_bps`

float

The fee in basis points (1 bps = 0.01%). NOTE: this field is deprecated and will be removed in a future release.

`fees[].mint_fee_bps`

float

The fee in basis points (1 bps = 0.01%).

`fees[].redeem_fee_bps`

float

The fee in basis points (1 bps = 0.01%).

### Example Request[](#example-request)

### Example Response[](#example-response)

### Fee Calculation[](#fee-calculation)

- Fees are expressed in **basis points (bps)**, where 1 bps = 0.01%
- For example, a fee of `10` bps means a 0.10% fee will be applied
- Different tokens may have different fee rates

### Error Codes[](#error-codes-1)

Error CodeError NameHTTP StatusDescription`1`

Temporarily unavailable, please try again.

400

No fee data is currently available, or there was an error retrieving fees. Please retry your request.

`29`

Invalid payload

400

The `benefactor` parameter is missing or the provided address is not a valid Ethereum address.

### Orders Submission Endpoint[](#orders-submission-endpoint)

After receiving the RFQ response, if you wish to execute the order as quoted, sign an EIP-712 signature using the usde_amount and collateral_amount values. Our system only accepts orders with matching values for the 2 fields, and if the order is submitted and received within 15 minutes of our previous RFQ response.

The order process has no interaction with the smart contracts as Ethena receives your orders, passes them through checks, then submits the order onchain.

For EIP-1271 users, you must add the signature_type parameter with the value EIP1271 to the request. The default is EIP712 so the former is only required if you're using EIP-1271.

`url = {ethena_url}order?signature={signature_hex}&signature_type=EIP1271`

**Example payload**

key

value

Description

signature

0xf80a44c799d13f257fa25459a9e2d36dadfea48a78f699de3f09fc3009a0e92d63b51ce85003c95cd7f4b80c271659092b898192d83fcd0dc1e3aae7483d59931b

Resulting signature from signing the order

order

See EIP712 signature ORDER_TYPE below

The order in plain json that they used to sign and create the signature

**Response**

**The tx that went onchain**

`https://etherscan.io/tx/0xbf4d5dce0e482b7cfd3e0ac714a0bb1b67d2c777668048e257b7fd3e9fb68980`

**EIP712 signature ORDER_TYPE**

`bytes32 private constant ORDER_TYPE = keccak256( "Order(string order_id, uint8 order_type, uint256 expiry, uint256 nonce, address benefactor, address beneficiary, address collateral_asset, uint256 collateral_amount, uint256 usde_amount)" );`

**Comment**

order key

values

Notes

order_id

RFQ-N9Y9T2Z6MXFNS

Unique identifier returned in the RFQ endpoint response. This ID must be included when submitting the order.

order_type

0 or 1

0 for mint, 1 for redeem

expiry

1764067729

Use an expiry of current time + 45s

nonce

256

Use a unique int for each order. eg timestamp

benefactor

0x0000000000000000000000000000000000000020

Address of signer. address where the asset is taken from (USDT for mint, USDe for redeem)

beneficiary

0x0000000000000000000000000000000000000020

Address that receives funds. (USDe for mint, USDT for redeem).

collateral_asset

0xdAC17F958D2ee523a2206206994597C13D831ec7

USDT address

collateral_amount

8995495840000

Amount of USDT in 18 decimals. Use the exact value provided in RFQ

usde_amount

8999996000000000000000000

Amount of USDe in 18 decimals. Use the exact value provided in RFQ

**Example raw order (before signing)**

**Our response**

We will either respond with a tx hash, where your order passed our checks and is sent to the blockchain or a failure message with a reason for failure.

The most common failure reasons include an invalid EIP-712 signature, submitting an order after the quote has expired or not having sufficient assets in your address for the mint or redeem.

**One Order per RFQ**

Each RFQ is **single-use**. Once an RFQ id has been used to execute an order, it is consumed and cannot be reused — even if you re-sign the quote with a new nonce or expiry. Submitting a second order against a consumed RFQ is rejected with **409 Conflict** (error code 37).

#### Error Codes[](#error-codes-2)

Error CodeHTTP Status CodeMessage1

400

Temporarily unavailable

10

400

Wallet address not whitelisted. Please contact Ethena.

11

400

Insufficient collateral asset in wallet.

12

400

Insufficient collateral asset approval for Ethena to transfer.

13

400

Insufficient usde balance in wallet.

14

400

Insufficient usde approval for Ethena to transfer.

15

400

Invalid signature.

16

400

Order payload invalid or does not match RFQ.

17

400

Size greater than available capacity for this block.

18

400

RFQ expired.

19

400

Invalid RFQ.

20

400

Please try again. The market moved too much.

21

400

Execution request already being processed.

22

400

Already successfully executed this block.

23

400

Present time greater than order expiry. Execution not submitted to blockchain.

24

400

Duplicate nonce

25

400

Benefactor not whitelisted

26

400

Beneficiary not whitelisted. User on-chain transaction required.

27

400

Incorrect USDe minter. Switch Minting API

28

429

Benefactor has reached throttle limit. Please wait until the limit resets or contact support for assistance.

29

400

Invalid payload

30

400

Invalid address

31

400

Fees not applicable

32

400

Slippage is too high for delegate-signed order

33

400

No pricing source found for validating asset price with alternative source

34

400

Insufficient minting contract balance

35

404

Order not found. Please verify the order ID is correct.

36

202

Order submitted but transaction not yet mined. Please wait and try again.

37

409

This RFQ has already been used to execute an order. Each RFQ is single-use — please request a new quote.

### Order Confirmation Endpoint[](#order-confirmation-endpoint)

After submitting an order, you can check its execution status using the order confirmation endpoint. This is useful for:

- Confirming your order was executed on-chain
- Checking if a transaction is still pending
- Understanding why an order was rejected before execution

**Your request**

KeyRequiredPossible ValuesDescriptionorder_id

true

RFQ-ABC123XYZ4567

The RFQ ID returned from the RFQ endpoint. Case-insensitive.

**Note:** The `order_id` can be provided with or without the `RFQ-` prefix. Both `RFQ-ABC123XYZ4567` and `ABC123XYZ4567` are accepted and normalized to uppercase.

**Example request**

[https://public.api.ethena.fi/order-confirmation?order_id=RFQ-ABC123XYZ4567](https://public.api.ethena.fi/order-confirmation?order_id=RFQ-ABC123XYZ4567)

**Our response**

The response varies based on the order status:

StatusHTTP CodeDescriptionexecuted

200

Order was successfully executed on-chain

reverted

200

Order was submitted but reverted on-chain

pending

202

Order submitted but transaction not yet mined

rejected

400

Order failed validation and was not submitted to blockchain

not_found

404

No order found with this ID

**Example response: Executed order**

**Example response: Pending order**

**Example response: Rejected order (failed validation)**

**Example response: Order not found**

**Example response: Invalid order_id format**

HTTP Status: 400

**Error Codes**

Error CodeHTTP Status CodeMessage1

400

Temporarily unavailable

29

400

Invalid payload (missing order_id)

35

404

Order not found. Please verify the order ID is correct.

36

202

Order submitted but transaction not yet mined. Please wait and try again.

**Recommended Polling Strategy**

For programmatic usage, we recommend:

1. After submitting an order, wait 5-10 seconds before first poll
2. Poll the endpoint every 5 seconds
3. Stop polling when status is `executed`, `reverted`, or `rejected`
4. Timeout after 5 minutes if order remains `pending`

Last updated 3 months ago

Was this helpful?